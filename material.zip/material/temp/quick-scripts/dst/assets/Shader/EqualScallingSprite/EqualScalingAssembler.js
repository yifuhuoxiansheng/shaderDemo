
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/EqualScallingSprite/EqualScalingAssembler.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e54e38Lmk1LtatjNGNMggDD', 'EqualScalingAssembler');
// Shader/EqualScallingSprite/EqualScalingAssembler.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-21 16:23:10
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:00:52
*/
var GTSimpleSpriteAssembler2D_1 = require("../GTSimpleSpriteAssembler2D");
var EqualScalingAssembler = /** @class */ (function (_super) {
    __extends(EqualScalingAssembler, _super);
    function EqualScalingAssembler() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._uv = [];
        return _this;
    }
    EqualScalingAssembler.prototype.updateUVs = function (sprite) {
        var rect = sprite._spriteFrame.getRect();
        var node = sprite.node;
        if (!rect.width || !rect.height || !node.width || !node.height) {
            _super.prototype.updateUVs.call(this, sprite);
            return;
        }
        Object.assign(this._uv, sprite._spriteFrame.uv);
        var uv = this._uv;
        var wscale = rect.width / node.width;
        var hscale = rect.height / node.height;
        var ratio = 1.0;
        if (wscale > hscale) {
            // fit height
            ratio = hscale / wscale;
            var ro = sprite._spriteFrame.isRotated() ? 1 : 0;
            var l = uv[0 + ro], r = uv[2 + ro];
            var c = (l + r) * 0.5;
            var half = (r - l) * 0.5 * ratio;
            uv[0 + ro] = uv[4 + ro] = c - half;
            uv[2 + ro] = uv[6 + ro] = c + half;
        }
        else {
            // fit width
            ratio = wscale / hscale;
            var ro = sprite._spriteFrame.isRotated() ? -1 : 0;
            var b = uv[1 + ro], t = uv[5 + ro];
            var c = (b + t) * 0.5;
            var half = (b - t) * 0.5 * ratio;
            uv[1 + ro] = uv[3 + ro] = c + half;
            uv[5 + ro] = uv[7 + ro] = c - half;
        }
        var uvOffset = this.uvOffset;
        var floatsPerVert = this.floatsPerVert;
        var verts = this._renderData.vDatas[0];
        for (var i = 0; i < 4; i++) {
            var srcOffset = i * 2;
            var dstOffset = floatsPerVert * i + uvOffset;
            verts[dstOffset] = uv[srcOffset];
            verts[dstOffset + 1] = uv[srcOffset + 1];
        }
    };
    return EqualScalingAssembler;
}(GTSimpleSpriteAssembler2D_1.default));
exports.default = EqualScalingAssembler;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvRXF1YWxTY2FsbGluZ1Nwcml0ZS9FcXVhbFNjYWxpbmdBc3NlbWJsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLGdEQUFnRDtBQUNoRCw0QkFBNEI7QUFDNUIsK0NBQStDO0FBQy9DLGdFQUFnRTs7Ozs7Ozs7Ozs7Ozs7O0FBRWhFOzs7O0VBSUU7QUFFRiwwRUFBcUU7QUFFckU7SUFBbUQseUNBQXlCO0lBQTVFO1FBQUEscUVBK0NDO1FBOUNXLFNBQUcsR0FBRyxFQUFFLENBQUM7O0lBOENyQixDQUFDO0lBNUNHLHlDQUFTLEdBQVQsVUFBVSxNQUFNO1FBQ1osSUFBSSxJQUFJLEdBQVksTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUNsRCxJQUFJLElBQUksR0FBWSxNQUFNLENBQUMsSUFBSSxDQUFDO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQzVELGlCQUFNLFNBQVMsWUFBQyxNQUFNLENBQUMsQ0FBQztZQUN4QixPQUFPO1NBQ1Y7UUFFRCxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUVoRCxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDO1FBQ2xCLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUNyQyxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7UUFDdkMsSUFBSSxLQUFLLEdBQVcsR0FBRyxDQUFDO1FBQ3hCLElBQUksTUFBTSxHQUFHLE1BQU0sRUFBRTtZQUNqQixhQUFhO1lBQ2IsS0FBSyxHQUFHLE1BQU0sR0FBRyxNQUFNLENBQUM7WUFDeEIsSUFBSSxFQUFFLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDakQsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsR0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsR0FBQyxFQUFFLENBQUMsQ0FBQztZQUMvQixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7WUFDcEIsSUFBSSxJQUFJLEdBQUcsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLEtBQUssQ0FBQztZQUMvQixFQUFFLENBQUMsQ0FBQyxHQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQztZQUMvQixFQUFFLENBQUMsQ0FBQyxHQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQztTQUNsQzthQUFNO1lBQ0gsWUFBWTtZQUNaLEtBQUssR0FBRyxNQUFNLEdBQUcsTUFBTSxDQUFDO1lBQ3hCLElBQUksRUFBRSxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbEQsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsR0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsR0FBQyxFQUFFLENBQUMsQ0FBQztZQUMvQixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7WUFDcEIsSUFBSSxJQUFJLEdBQUcsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLEtBQUssQ0FBQztZQUMvQixFQUFFLENBQUMsQ0FBQyxHQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQztZQUMvQixFQUFFLENBQUMsQ0FBQyxHQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQztTQUNsQztRQUVELElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7UUFDN0IsSUFBSSxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUN2QyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2QyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3hCLElBQUksU0FBUyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDdEIsSUFBSSxTQUFTLEdBQUcsYUFBYSxHQUFHLENBQUMsR0FBRyxRQUFRLENBQUM7WUFDN0MsS0FBSyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNqQyxLQUFLLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDNUM7SUFDTCxDQUFDO0lBQ0wsNEJBQUM7QUFBRCxDQS9DQSxBQStDQyxDQS9Da0QsbUNBQXlCLEdBK0MzRSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIENvcHlyaWdodCAyMDIwIENhbyBHYW90aW5nPGNhb2d0YWFAZ21haWwuY29tPlxuLy8gaHR0cHM6Ly9jYW9ndGFhLmdpdGh1Yi5pb1xuLy8gVGhpcyBmaWxlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS5cbi8vIExpY2Vuc2UgdGV4dCBhdmFpbGFibGUgYXQgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVRcblxuLypcbiAqIERhdGU6IDIwMjAtMDctMjEgMTY6MjM6MTBcbiAqIExhc3RFZGl0b3JzOiBHVDxjYW9ndGFhQGdtYWlsLmNvbT5cbiAqIExhc3RFZGl0VGltZTogMjAyMC0wNy0yMiAxNDowMDo1MlxuKi8gXG5cbmltcG9ydCBHVFNpbXBsZVNwcml0ZUFzc2VtYmxlcjJEIGZyb20gXCIuLi9HVFNpbXBsZVNwcml0ZUFzc2VtYmxlcjJEXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEVxdWFsU2NhbGluZ0Fzc2VtYmxlciBleHRlbmRzIEdUU2ltcGxlU3ByaXRlQXNzZW1ibGVyMkQge1xuICAgIHByaXZhdGUgX3V2ID0gW107XG5cbiAgICB1cGRhdGVVVnMoc3ByaXRlKSB7XG4gICAgICAgIGxldCByZWN0OiBjYy5SZWN0ID0gc3ByaXRlLl9zcHJpdGVGcmFtZS5nZXRSZWN0KCk7XG4gICAgICAgIGxldCBub2RlOiBjYy5Ob2RlID0gc3ByaXRlLm5vZGU7XG4gICAgICAgIGlmICghcmVjdC53aWR0aCB8fCAhcmVjdC5oZWlnaHQgfHwgIW5vZGUud2lkdGggfHwgIW5vZGUuaGVpZ2h0KSB7XG4gICAgICAgICAgICBzdXBlci51cGRhdGVVVnMoc3ByaXRlKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIE9iamVjdC5hc3NpZ24odGhpcy5fdXYsIHNwcml0ZS5fc3ByaXRlRnJhbWUudXYpO1xuXG4gICAgICAgIGxldCB1diA9IHRoaXMuX3V2O1xuICAgICAgICBsZXQgd3NjYWxlID0gcmVjdC53aWR0aCAvIG5vZGUud2lkdGg7XG4gICAgICAgIGxldCBoc2NhbGUgPSByZWN0LmhlaWdodCAvIG5vZGUuaGVpZ2h0O1xuICAgICAgICBsZXQgcmF0aW86IG51bWJlciA9IDEuMDtcbiAgICAgICAgaWYgKHdzY2FsZSA+IGhzY2FsZSkge1xuICAgICAgICAgICAgLy8gZml0IGhlaWdodFxuICAgICAgICAgICAgcmF0aW8gPSBoc2NhbGUgLyB3c2NhbGU7XG4gICAgICAgICAgICBsZXQgcm8gPSBzcHJpdGUuX3Nwcml0ZUZyYW1lLmlzUm90YXRlZCgpID8gMSA6IDA7XG4gICAgICAgICAgICBsZXQgbCA9IHV2WzArcm9dLCByID0gdXZbMityb107XG4gICAgICAgICAgICBsZXQgYyA9IChsK3IpICogMC41O1xuICAgICAgICAgICAgbGV0IGhhbGYgPSAoci1sKSAqIDAuNSAqIHJhdGlvO1xuICAgICAgICAgICAgdXZbMCtyb10gPSB1dls0K3JvXSA9IGMgLSBoYWxmO1xuICAgICAgICAgICAgdXZbMityb10gPSB1dls2K3JvXSA9IGMgKyBoYWxmO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gZml0IHdpZHRoXG4gICAgICAgICAgICByYXRpbyA9IHdzY2FsZSAvIGhzY2FsZTtcbiAgICAgICAgICAgIGxldCBybyA9IHNwcml0ZS5fc3ByaXRlRnJhbWUuaXNSb3RhdGVkKCkgPyAtMSA6IDA7XG4gICAgICAgICAgICBsZXQgYiA9IHV2WzErcm9dLCB0ID0gdXZbNStyb107XG4gICAgICAgICAgICBsZXQgYyA9IChiK3QpICogMC41O1xuICAgICAgICAgICAgbGV0IGhhbGYgPSAoYi10KSAqIDAuNSAqIHJhdGlvO1xuICAgICAgICAgICAgdXZbMStyb10gPSB1dlszK3JvXSA9IGMgKyBoYWxmO1xuICAgICAgICAgICAgdXZbNStyb10gPSB1dls3K3JvXSA9IGMgLSBoYWxmO1xuICAgICAgICB9XG5cbiAgICAgICAgbGV0IHV2T2Zmc2V0ID0gdGhpcy51dk9mZnNldDtcbiAgICAgICAgbGV0IGZsb2F0c1BlclZlcnQgPSB0aGlzLmZsb2F0c1BlclZlcnQ7XG4gICAgICAgIGxldCB2ZXJ0cyA9IHRoaXMuX3JlbmRlckRhdGEudkRhdGFzWzBdO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IDQ7IGkrKykge1xuICAgICAgICAgICAgbGV0IHNyY09mZnNldCA9IGkgKiAyO1xuICAgICAgICAgICAgbGV0IGRzdE9mZnNldCA9IGZsb2F0c1BlclZlcnQgKiBpICsgdXZPZmZzZXQ7XG4gICAgICAgICAgICB2ZXJ0c1tkc3RPZmZzZXRdID0gdXZbc3JjT2Zmc2V0XTtcbiAgICAgICAgICAgIHZlcnRzW2RzdE9mZnNldCArIDFdID0gdXZbc3JjT2Zmc2V0ICsgMV07XG4gICAgICAgIH1cbiAgICB9XG59XG4iXX0=