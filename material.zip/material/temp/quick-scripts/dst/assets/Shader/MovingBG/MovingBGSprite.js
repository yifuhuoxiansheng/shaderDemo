
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/MovingBG/MovingBGSprite.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd6bb3Z+1ARGDapKZIvBpCUs', 'MovingBGSprite');
// Shader/MovingBG/MovingBGSprite.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-13 02:44:17
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:03:32
*/
var MovingBGAssembler_1 = require("./MovingBGAssembler");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var MovingBGSprite = /** @class */ (function (_super) {
    __extends(MovingBGSprite, _super);
    function MovingBGSprite() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._moveSpeed = cc.Vec2.ZERO;
        return _this;
    }
    Object.defineProperty(MovingBGSprite.prototype, "moveSpeed", {
        get: function () {
            return this._moveSpeed;
        },
        set: function (value) {
            this._moveSpeed = value;
            this.FlushProperties();
        },
        enumerable: false,
        configurable: true
    });
    MovingBGSprite.prototype.FlushProperties = function () {
        //@ts-ignore
        var assembler = this._assembler;
        if (!assembler)
            return;
        assembler.moveSpeed = this._moveSpeed;
        this.setVertsDirty();
    };
    MovingBGSprite.prototype.onEnable = function () {
        _super.prototype.onEnable.call(this);
    };
    // // 使用cc.Sprite默认逻辑
    MovingBGSprite.prototype._resetAssembler = function () {
        this.setVertsDirty();
        var assembler = this._assembler = new MovingBGAssembler_1.default();
        this.FlushProperties();
        assembler.init(this);
        //@ts-ignore
        this._updateColor(); // may be no need
    };
    __decorate([
        property(cc.Vec2)
    ], MovingBGSprite.prototype, "moveSpeed", null);
    __decorate([
        property(cc.Vec2)
    ], MovingBGSprite.prototype, "_moveSpeed", void 0);
    MovingBGSprite = __decorate([
        ccclass
    ], MovingBGSprite);
    return MovingBGSprite;
}(cc.Sprite));
exports.default = MovingBGSprite;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvTW92aW5nQkcvTW92aW5nQkdTcHJpdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLGdEQUFnRDtBQUNoRCw0QkFBNEI7QUFDNUIsK0NBQStDO0FBQy9DLGdFQUFnRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRWhFOzs7O0VBSUU7QUFFRix5REFBb0Q7QUFFOUMsSUFBQSxLQUFzQixFQUFFLENBQUMsVUFBVSxFQUFsQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWlCLENBQUM7QUFHMUM7SUFBNEMsa0NBQVM7SUFBckQ7UUFBQSxxRUFzQ0M7UUEzQkcsZ0JBQVUsR0FBWSxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQzs7SUEyQnZDLENBQUM7SUFwQ0csc0JBQUkscUNBQVM7YUFJYjtZQUNJLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQztRQUMzQixDQUFDO2FBTkQsVUFBYyxLQUFjO1lBQ3hCLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO1lBQ3hCLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUMzQixDQUFDOzs7T0FBQTtJQVFNLHdDQUFlLEdBQXRCO1FBQ0ksWUFBWTtRQUNaLElBQUksU0FBUyxHQUFzQixJQUFJLENBQUMsVUFBVSxDQUFDO1FBQ25ELElBQUksQ0FBQyxTQUFTO1lBQ1YsT0FBTztRQUVYLFNBQVMsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQztRQUN0QyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDekIsQ0FBQztJQUVELGlDQUFRLEdBQVI7UUFDSSxpQkFBTSxRQUFRLFdBQUUsQ0FBQztJQUNyQixDQUFDO0lBRUQscUJBQXFCO0lBQ3JCLHdDQUFlLEdBQWY7UUFDSSxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDckIsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLDJCQUFpQixFQUFFLENBQUM7UUFDMUQsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBRXZCLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFckIsWUFBWTtRQUNaLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFRLGlCQUFpQjtJQUNqRCxDQUFDO0lBbkNEO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7bURBSWpCO0lBTUQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQztzREFDaUI7SUFYbEIsY0FBYztRQURsQyxPQUFPO09BQ2EsY0FBYyxDQXNDbEM7SUFBRCxxQkFBQztDQXRDRCxBQXNDQyxDQXRDMkMsRUFBRSxDQUFDLE1BQU0sR0FzQ3BEO2tCQXRDb0IsY0FBYyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIENvcHlyaWdodCAyMDIwIENhbyBHYW90aW5nPGNhb2d0YWFAZ21haWwuY29tPlxuLy8gaHR0cHM6Ly9jYW9ndGFhLmdpdGh1Yi5pb1xuLy8gVGhpcyBmaWxlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS5cbi8vIExpY2Vuc2UgdGV4dCBhdmFpbGFibGUgYXQgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVRcblxuLypcbiAqIERhdGU6IDIwMjAtMDctMTMgMDI6NDQ6MTdcbiAqIExhc3RFZGl0b3JzOiBHVDxjYW9ndGFhQGdtYWlsLmNvbT5cbiAqIExhc3RFZGl0VGltZTogMjAyMC0wNy0yMiAxNDowMzozMlxuKi8gXG5cbmltcG9ydCBNb3ZpbmdCR0Fzc2VtYmxlciBmcm9tIFwiLi9Nb3ZpbmdCR0Fzc2VtYmxlclwiO1xuXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE1vdmluZ0JHU3ByaXRlIGV4dGVuZHMgY2MuU3ByaXRlIHtcbiAgICBAcHJvcGVydHkoY2MuVmVjMilcbiAgICBzZXQgbW92ZVNwZWVkKHZhbHVlOiBjYy5WZWMyKSB7XG4gICAgICAgIHRoaXMuX21vdmVTcGVlZCA9IHZhbHVlO1xuICAgICAgICB0aGlzLkZsdXNoUHJvcGVydGllcygpO1xuICAgIH1cbiAgICBnZXQgbW92ZVNwZWVkKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fbW92ZVNwZWVkO1xuICAgIH1cblxuICAgIEBwcm9wZXJ0eShjYy5WZWMyKVxuICAgIF9tb3ZlU3BlZWQ6IGNjLlZlYzIgPSBjYy5WZWMyLlpFUk87XG5cbiAgICBwdWJsaWMgRmx1c2hQcm9wZXJ0aWVzKCkge1xuICAgICAgICAvL0B0cy1pZ25vcmVcbiAgICAgICAgbGV0IGFzc2VtYmxlcjogTW92aW5nQkdBc3NlbWJsZXIgPSB0aGlzLl9hc3NlbWJsZXI7XG4gICAgICAgIGlmICghYXNzZW1ibGVyKVxuICAgICAgICAgICAgcmV0dXJuO1xuXG4gICAgICAgIGFzc2VtYmxlci5tb3ZlU3BlZWQgPSB0aGlzLl9tb3ZlU3BlZWQ7XG4gICAgICAgIHRoaXMuc2V0VmVydHNEaXJ0eSgpO1xuICAgIH1cblxuICAgIG9uRW5hYmxlICgpIHtcbiAgICAgICAgc3VwZXIub25FbmFibGUoKTtcbiAgICB9XG5cbiAgICAvLyAvLyDkvb/nlKhjYy5TcHJpdGXpu5jorqTpgLvovpFcbiAgICBfcmVzZXRBc3NlbWJsZXIoKSB7XG4gICAgICAgIHRoaXMuc2V0VmVydHNEaXJ0eSgpO1xuICAgICAgICBsZXQgYXNzZW1ibGVyID0gdGhpcy5fYXNzZW1ibGVyID0gbmV3IE1vdmluZ0JHQXNzZW1ibGVyKCk7XG4gICAgICAgIHRoaXMuRmx1c2hQcm9wZXJ0aWVzKCk7XG5cbiAgICAgICAgYXNzZW1ibGVyLmluaXQodGhpcyk7XG5cbiAgICAgICAgLy9AdHMtaWdub3JlXG4gICAgICAgIHRoaXMuX3VwZGF0ZUNvbG9yKCk7ICAgICAgICAvLyBtYXkgYmUgbm8gbmVlZFxuICAgIH1cbn1cbiJdfQ==