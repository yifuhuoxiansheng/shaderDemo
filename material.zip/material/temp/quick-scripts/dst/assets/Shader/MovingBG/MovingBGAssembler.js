
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/MovingBG/MovingBGAssembler.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e1c35wY/WtDI4NVp88fW7Kq', 'MovingBGAssembler');
// Shader/MovingBG/MovingBGAssembler.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-13 02:44:17
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:03:25
*/
var GTSimpleSpriteAssembler2D_1 = require("../GTSimpleSpriteAssembler2D");
// 自定义顶点格式，在vfmtPosUvColor基础上，加入gfx.ATTR_UV1，去掉gfx.ATTR_COLOR
// 20200703 增加了uv2, uv3用于处理uv在图集里的映射
//@ts-ignore
var gfx = cc.gfx;
var vfmtCustom = new gfx.VertexFormat([
    { name: gfx.ATTR_POSITION, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: gfx.ATTR_UV0, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: gfx.ATTR_UV1, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: "a_p", type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: "a_q", type: gfx.ATTR_TYPE_FLOAT32, num: 2 } // 同上
]);
var VEC2_ZERO = cc.Vec2.ZERO;
var MovingBGAssembler = /** @class */ (function (_super) {
    __extends(MovingBGAssembler, _super);
    function MovingBGAssembler() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // 根据自定义顶点格式，调整下述常量
        _this.verticesCount = 4;
        _this.indicesCount = 6;
        _this.uvOffset = 2;
        _this.uv1Offset = 4;
        _this.uv2Offset = 6;
        _this.uv3Offset = 8;
        _this.floatsPerVert = 10;
        // 自定义数据，将被写入uv1的位置
        _this.moveSpeed = VEC2_ZERO;
        return _this;
    }
    MovingBGAssembler.prototype.initData = function () {
        var data = this._renderData;
        // createFlexData支持创建指定格式的renderData
        data.createFlexData(0, this.verticesCount, this.indicesCount, this.getVfmt());
        // createFlexData不会填充顶点索引信息，手动补充一下
        var indices = data.iDatas[0];
        var count = indices.length / 6;
        for (var i = 0, idx = 0; i < count; i++) {
            var vertextID = i * 4;
            indices[idx++] = vertextID;
            indices[idx++] = vertextID + 1;
            indices[idx++] = vertextID + 2;
            indices[idx++] = vertextID + 1;
            indices[idx++] = vertextID + 3;
            indices[idx++] = vertextID + 2;
        }
    };
    // 自定义格式以getVfmt()方式提供出去，除了当前assembler，render-flow的其他地方也会用到
    MovingBGAssembler.prototype.getVfmt = function () {
        return vfmtCustom;
    };
    // 重载getBuffer(), 返回一个能容纳自定义顶点数据的buffer
    // 默认fillBuffers()方法中会调用到
    MovingBGAssembler.prototype.getBuffer = function () {
        //@ts-ignore
        return cc.renderer._handle.getBuffer("mesh", this.getVfmt());
    };
    // pos数据没有变化，不用重载
    // updateVerts(sprite) {
    // }
    MovingBGAssembler.prototype.updateColor = function (sprite, color) {
        // 由于已经去掉了color字段，这里重载原方法，并且不做任何事
    };
    MovingBGAssembler.prototype.updateUVs = function (sprite) {
        _super.prototype.updateUVs.call(this, sprite);
        var uv = sprite._spriteFrame.uv;
        var uvOffset = this.uvOffset;
        var floatsPerVert = this.floatsPerVert;
        var verts = this._renderData.vDatas[0];
        var dstOffset;
        var l = uv[0], r = uv[2], t = uv[5], b = uv[1];
        // px, qx用于x轴的uv映射
        // py, qy同理，公式推导过程略...
        var px = 1.0 / (r - l), qx = -l * px; // l / (l-r);
        var py = 1.0 / (b - t), qy = -t * py; // t / (t-b);
        var sx = this.moveSpeed.x;
        var sy = this.moveSpeed.y;
        for (var i = 0; i < 4; ++i) {
            dstOffset = floatsPerVert * i + uvOffset;
            // fill uv1
            verts[dstOffset + 2] = sx;
            verts[dstOffset + 3] = sy;
            // fill uv2
            verts[dstOffset + 4] = px;
            verts[dstOffset + 5] = py;
            // fill uv3
            verts[dstOffset + 6] = qx;
            verts[dstOffset + 7] = qy;
        }
    };
    return MovingBGAssembler;
}(GTSimpleSpriteAssembler2D_1.default));
exports.default = MovingBGAssembler;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvTW92aW5nQkcvTW92aW5nQkdBc3NlbWJsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLGdEQUFnRDtBQUNoRCw0QkFBNEI7QUFDNUIsK0NBQStDO0FBQy9DLGdFQUFnRTs7Ozs7Ozs7Ozs7Ozs7O0FBRWhFOzs7O0VBSUU7QUFHRiwwRUFBcUU7QUFFckUsNkRBQTZEO0FBQzdELG9DQUFvQztBQUNwQyxZQUFZO0FBQ1osSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQztBQUNqQixJQUFJLFVBQVUsR0FBRyxJQUFJLEdBQUcsQ0FBQyxZQUFZLENBQUM7SUFDbEMsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLGFBQWEsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLGlCQUFpQixFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQUU7SUFDaEUsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLGlCQUFpQixFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQUU7SUFDM0QsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLGlCQUFpQixFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQUU7SUFDM0QsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsaUJBQWlCLEVBQUUsR0FBRyxFQUFFLENBQUMsRUFBRTtJQUNwRCxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQWdCLEtBQUs7Q0FDNUUsQ0FBQyxDQUFDO0FBRUgsSUFBTSxTQUFTLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7QUFFL0I7SUFBK0MscUNBQXlCO0lBQXhFO1FBQUEscUVBMEZDO1FBekZHLG1CQUFtQjtRQUNuQixtQkFBYSxHQUFHLENBQUMsQ0FBQztRQUNsQixrQkFBWSxHQUFHLENBQUMsQ0FBQztRQUNqQixjQUFRLEdBQUcsQ0FBQyxDQUFDO1FBQ2IsZUFBUyxHQUFHLENBQUMsQ0FBQztRQUNkLGVBQVMsR0FBRyxDQUFDLENBQUM7UUFDZCxlQUFTLEdBQUcsQ0FBQyxDQUFDO1FBQ2QsbUJBQWEsR0FBRyxFQUFFLENBQUM7UUFFbkIsbUJBQW1CO1FBQ1osZUFBUyxHQUFZLFNBQVMsQ0FBQzs7SUErRTFDLENBQUM7SUE5RUcsb0NBQVEsR0FBUjtRQUNJLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7UUFDNUIsb0NBQW9DO1FBQ3BDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztRQUU5RSxrQ0FBa0M7UUFDbEMsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM3QixJQUFJLEtBQUssR0FBRyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztRQUMvQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxHQUFHLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDckMsSUFBSSxTQUFTLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN0QixPQUFPLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxTQUFTLENBQUM7WUFDM0IsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsU0FBUyxHQUFDLENBQUMsQ0FBQztZQUM3QixPQUFPLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxTQUFTLEdBQUMsQ0FBQyxDQUFDO1lBQzdCLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLFNBQVMsR0FBQyxDQUFDLENBQUM7WUFDN0IsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsU0FBUyxHQUFDLENBQUMsQ0FBQztZQUM3QixPQUFPLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxTQUFTLEdBQUMsQ0FBQyxDQUFDO1NBQ2hDO0lBQ0wsQ0FBQztJQUVELDJEQUEyRDtJQUMzRCxtQ0FBTyxHQUFQO1FBQ0ksT0FBTyxVQUFVLENBQUM7SUFDdEIsQ0FBQztJQUVELHVDQUF1QztJQUN2Qyx5QkFBeUI7SUFDekIscUNBQVMsR0FBVDtRQUNJLFlBQVk7UUFDWixPQUFPLEVBQUUsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7SUFDakUsQ0FBQztJQUVELGlCQUFpQjtJQUNqQix3QkFBd0I7SUFDeEIsSUFBSTtJQUVKLHVDQUFXLEdBQVgsVUFBWSxNQUFNLEVBQUUsS0FBSztRQUNyQixpQ0FBaUM7SUFDckMsQ0FBQztJQUdELHFDQUFTLEdBQVQsVUFBVSxNQUFNO1FBQ1osaUJBQU0sU0FBUyxZQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3hCLElBQUksRUFBRSxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1FBQ2hDLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7UUFDN0IsSUFBSSxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUN2QyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2QyxJQUFJLFNBQVMsQ0FBQztRQUVkLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFDVCxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUNULENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQ1QsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVkLGtCQUFrQjtRQUNsQixzQkFBc0I7UUFDdEIsSUFBSSxFQUFFLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUNoQixFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUcsYUFBYTtRQUVqQyxJQUFJLEVBQUUsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQ2hCLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBRyxhQUFhO1FBRWpDLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO1FBQzFCLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO1FBQzFCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDeEIsU0FBUyxHQUFHLGFBQWEsR0FBRyxDQUFDLEdBQUcsUUFBUSxDQUFDO1lBQ3pDLFdBQVc7WUFDWCxLQUFLLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUMxQixLQUFLLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUUxQixXQUFXO1lBQ1gsS0FBSyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDMUIsS0FBSyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7WUFFMUIsV0FBVztZQUNYLEtBQUssQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQzFCLEtBQUssQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO1NBQzdCO0lBQ0wsQ0FBQztJQUNMLHdCQUFDO0FBQUQsQ0ExRkEsQUEwRkMsQ0ExRjhDLG1DQUF5QixHQTBGdkUiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDb3B5cmlnaHQgMjAyMCBDYW8gR2FvdGluZzxjYW9ndGFhQGdtYWlsLmNvbT5cbi8vIGh0dHBzOi8vY2FvZ3RhYS5naXRodWIuaW9cbi8vIFRoaXMgZmlsZSBpcyBsaWNlbnNlZCB1bmRlciB0aGUgTUlUIExpY2Vuc2UuXG4vLyBMaWNlbnNlIHRleHQgYXZhaWxhYmxlIGF0IGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlUXG5cbi8qXG4gKiBEYXRlOiAyMDIwLTA3LTEzIDAyOjQ0OjE3XG4gKiBMYXN0RWRpdG9yczogR1Q8Y2FvZ3RhYUBnbWFpbC5jb20+XG4gKiBMYXN0RWRpdFRpbWU6IDIwMjAtMDctMjIgMTQ6MDM6MjVcbiovIFxuXG5cbmltcG9ydCBHVFNpbXBsZVNwcml0ZUFzc2VtYmxlcjJEIGZyb20gXCIuLi9HVFNpbXBsZVNwcml0ZUFzc2VtYmxlcjJEXCI7XG5cbi8vIOiHquWumuS5iemhtueCueagvOW8j++8jOWcqHZmbXRQb3NVdkNvbG9y5Z+656GA5LiK77yM5Yqg5YWlZ2Z4LkFUVFJfVVYx77yM5Y675o6JZ2Z4LkFUVFJfQ09MT1Jcbi8vIDIwMjAwNzAzIOWinuWKoOS6hnV2MiwgdXYz55So5LqO5aSE55CGdXblnKjlm77pm4bph4znmoTmmKDlsIRcbi8vQHRzLWlnbm9yZVxubGV0IGdmeCA9IGNjLmdmeDtcbnZhciB2Zm10Q3VzdG9tID0gbmV3IGdmeC5WZXJ0ZXhGb3JtYXQoW1xuICAgIHsgbmFtZTogZ2Z4LkFUVFJfUE9TSVRJT04sIHR5cGU6IGdmeC5BVFRSX1RZUEVfRkxPQVQzMiwgbnVtOiAyIH0sXG4gICAgeyBuYW1lOiBnZnguQVRUUl9VVjAsIHR5cGU6IGdmeC5BVFRSX1RZUEVfRkxPQVQzMiwgbnVtOiAyIH0sICAgICAgICAvLyB0ZXh0dXJl57q555CGdXZcbiAgICB7IG5hbWU6IGdmeC5BVFRSX1VWMSwgdHlwZTogZ2Z4LkFUVFJfVFlQRV9GTE9BVDMyLCBudW06IDIgfSwgICAgICAgIC8vIHV2Me+8jOaOp+WItuWbvueJh+a7muWKqOaWueWQkSAmIOmAn+W6plxuICAgIHsgbmFtZTogXCJhX3BcIiwgdHlwZTogZ2Z4LkFUVFJfVFlQRV9GTE9BVDMyLCBudW06IDIgfSwgICAgICAgICAgICAgICAvLyB1diByZW1hcOWIsCBbMCwgMV3ljLrpl7TnlKjnmoTkuK3pl7Tlj5jph49cbiAgICB7IG5hbWU6IFwiYV9xXCIsIHR5cGU6IGdmeC5BVFRSX1RZUEVfRkxPQVQzMiwgbnVtOiAyIH0gICAgICAgICAgICAgICAgLy8g5ZCM5LiKXG5dKTtcblxuY29uc3QgVkVDMl9aRVJPID0gY2MuVmVjMi5aRVJPO1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNb3ZpbmdCR0Fzc2VtYmxlciBleHRlbmRzIEdUU2ltcGxlU3ByaXRlQXNzZW1ibGVyMkQge1xuICAgIC8vIOagueaNruiHquWumuS5iemhtueCueagvOW8j++8jOiwg+aVtOS4i+i/sOW4uOmHj1xuICAgIHZlcnRpY2VzQ291bnQgPSA0O1xuICAgIGluZGljZXNDb3VudCA9IDY7XG4gICAgdXZPZmZzZXQgPSAyO1xuICAgIHV2MU9mZnNldCA9IDQ7XG4gICAgdXYyT2Zmc2V0ID0gNjtcbiAgICB1djNPZmZzZXQgPSA4O1xuICAgIGZsb2F0c1BlclZlcnQgPSAxMDtcblxuICAgIC8vIOiHquWumuS5ieaVsOaNru+8jOWwhuiiq+WGmeWFpXV2MeeahOS9jee9rlxuICAgIHB1YmxpYyBtb3ZlU3BlZWQ6IGNjLlZlYzIgPSBWRUMyX1pFUk87XG4gICAgaW5pdERhdGEoKSB7XG4gICAgICAgIGxldCBkYXRhID0gdGhpcy5fcmVuZGVyRGF0YTtcbiAgICAgICAgLy8gY3JlYXRlRmxleERhdGHmlK/mjIHliJvlu7rmjIflrprmoLzlvI/nmoRyZW5kZXJEYXRhXG4gICAgICAgIGRhdGEuY3JlYXRlRmxleERhdGEoMCwgdGhpcy52ZXJ0aWNlc0NvdW50LCB0aGlzLmluZGljZXNDb3VudCwgdGhpcy5nZXRWZm10KCkpO1xuXG4gICAgICAgIC8vIGNyZWF0ZUZsZXhEYXRh5LiN5Lya5aGr5YWF6aG254K557Si5byV5L+h5oGv77yM5omL5Yqo6KGl5YWF5LiA5LiLXG4gICAgICAgIGxldCBpbmRpY2VzID0gZGF0YS5pRGF0YXNbMF07XG4gICAgICAgIGxldCBjb3VudCA9IGluZGljZXMubGVuZ3RoIC8gNjtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIGlkeCA9IDA7IGkgPCBjb3VudDsgaSsrKSB7XG4gICAgICAgICAgICBsZXQgdmVydGV4dElEID0gaSAqIDQ7XG4gICAgICAgICAgICBpbmRpY2VzW2lkeCsrXSA9IHZlcnRleHRJRDtcbiAgICAgICAgICAgIGluZGljZXNbaWR4KytdID0gdmVydGV4dElEKzE7XG4gICAgICAgICAgICBpbmRpY2VzW2lkeCsrXSA9IHZlcnRleHRJRCsyO1xuICAgICAgICAgICAgaW5kaWNlc1tpZHgrK10gPSB2ZXJ0ZXh0SUQrMTtcbiAgICAgICAgICAgIGluZGljZXNbaWR4KytdID0gdmVydGV4dElEKzM7XG4gICAgICAgICAgICBpbmRpY2VzW2lkeCsrXSA9IHZlcnRleHRJRCsyO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLy8g6Ieq5a6a5LmJ5qC85byP5LulZ2V0VmZtdCgp5pa55byP5o+Q5L6b5Ye65Y6777yM6Zmk5LqG5b2T5YmNYXNzZW1ibGVy77yMcmVuZGVyLWZsb3fnmoTlhbbku5blnLDmlrnkuZ/kvJrnlKjliLBcbiAgICBnZXRWZm10KCkge1xuICAgICAgICByZXR1cm4gdmZtdEN1c3RvbTtcbiAgICB9XG5cbiAgICAvLyDph43ovb1nZXRCdWZmZXIoKSwg6L+U5Zue5LiA5Liq6IO95a6557qz6Ieq5a6a5LmJ6aG254K55pWw5o2u55qEYnVmZmVyXG4gICAgLy8g6buY6K6kZmlsbEJ1ZmZlcnMoKeaWueazleS4reS8muiwg+eUqOWIsFxuICAgIGdldEJ1ZmZlcigpIHtcbiAgICAgICAgLy9AdHMtaWdub3JlXG4gICAgICAgIHJldHVybiBjYy5yZW5kZXJlci5faGFuZGxlLmdldEJ1ZmZlcihcIm1lc2hcIiwgdGhpcy5nZXRWZm10KCkpO1xuICAgIH1cblxuICAgIC8vIHBvc+aVsOaNruayoeacieWPmOWMlu+8jOS4jeeUqOmHjei9vVxuICAgIC8vIHVwZGF0ZVZlcnRzKHNwcml0ZSkge1xuICAgIC8vIH1cblxuICAgIHVwZGF0ZUNvbG9yKHNwcml0ZSwgY29sb3IpIHtcbiAgICAgICAgLy8g55Sx5LqO5bey57uP5Y675o6J5LqGY29sb3LlrZfmrrXvvIzov5nph4zph43ovb3ljp/mlrnms5XvvIzlubbkuJTkuI3lgZrku7vkvZXkuotcbiAgICB9XG5cblxuICAgIHVwZGF0ZVVWcyhzcHJpdGUpIHtcbiAgICAgICAgc3VwZXIudXBkYXRlVVZzKHNwcml0ZSk7XG4gICAgICAgIGxldCB1diA9IHNwcml0ZS5fc3ByaXRlRnJhbWUudXY7XG4gICAgICAgIGxldCB1dk9mZnNldCA9IHRoaXMudXZPZmZzZXQ7XG4gICAgICAgIGxldCBmbG9hdHNQZXJWZXJ0ID0gdGhpcy5mbG9hdHNQZXJWZXJ0O1xuICAgICAgICBsZXQgdmVydHMgPSB0aGlzLl9yZW5kZXJEYXRhLnZEYXRhc1swXTtcbiAgICAgICAgbGV0IGRzdE9mZnNldDtcblxuICAgICAgICBsZXQgbCA9IHV2WzBdLFxuICAgICAgICAgICAgciA9IHV2WzJdLFxuICAgICAgICAgICAgdCA9IHV2WzVdLFxuICAgICAgICAgICAgYiA9IHV2WzFdO1xuXG4gICAgICAgIC8vIHB4LCBxeOeUqOS6jnjovbTnmoR1duaYoOWwhFxuICAgICAgICAvLyBweSwgcXnlkIznkIbvvIzlhazlvI/mjqjlr7zov4fnqIvnlaUuLi5cbiAgICAgICAgbGV0IHB4ID0gMS4wIC8gKHItbCksXG4gICAgICAgICAgICBxeCA9IC1sICogcHg7ICAgLy8gbCAvIChsLXIpO1xuXG4gICAgICAgIGxldCBweSA9IDEuMCAvIChiLXQpLFxuICAgICAgICAgICAgcXkgPSAtdCAqIHB5OyAgIC8vIHQgLyAodC1iKTtcblxuICAgICAgICBsZXQgc3ggPSB0aGlzLm1vdmVTcGVlZC54O1xuICAgICAgICBsZXQgc3kgPSB0aGlzLm1vdmVTcGVlZC55O1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IDQ7ICsraSkge1xuICAgICAgICAgICAgZHN0T2Zmc2V0ID0gZmxvYXRzUGVyVmVydCAqIGkgKyB1dk9mZnNldDtcbiAgICAgICAgICAgIC8vIGZpbGwgdXYxXG4gICAgICAgICAgICB2ZXJ0c1tkc3RPZmZzZXQgKyAyXSA9IHN4O1xuICAgICAgICAgICAgdmVydHNbZHN0T2Zmc2V0ICsgM10gPSBzeTtcblxuICAgICAgICAgICAgLy8gZmlsbCB1djJcbiAgICAgICAgICAgIHZlcnRzW2RzdE9mZnNldCArIDRdID0gcHg7XG4gICAgICAgICAgICB2ZXJ0c1tkc3RPZmZzZXQgKyA1XSA9IHB5O1xuXG4gICAgICAgICAgICAvLyBmaWxsIHV2M1xuICAgICAgICAgICAgdmVydHNbZHN0T2Zmc2V0ICsgNl0gPSBxeDtcbiAgICAgICAgICAgIHZlcnRzW2RzdE9mZnNldCArIDddID0gcXk7XG4gICAgICAgIH1cbiAgICB9XG59XG4iXX0=