
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/LayeredBatching/LayeredBatchingAssembler.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '9b7db/QlVpNR6BkHD3PCH0u', 'LayeredBatchingAssembler');
// Shader/LayeredBatching/LayeredBatchingAssembler.ts

"use strict";
/****************************************************************************
 Author: GT <caogtaa@gmail.com>
 https://caogtaa.github.io
****************************************************************************/
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var GTSimpleSpriteAssembler2D_1 = require("../GTSimpleSpriteAssembler2D");
// RenderFlow遍历过程中，需要防止子节点进入的函数
var RENDER_MASK = cc.RenderFlow.FLAG_RENDER | cc.RenderFlow.FLAG_POST_RENDER;
var PROP_DIRTY_MASK = cc.RenderFlow.FLAG_OPACITY | cc.RenderFlow.FLAG_WORLD_TRANSFORM;
// 通过开关控制仅在拥有该Assembler的根节点开启合批优化
// 用于避免该Assembler被嵌套使用
var BATCH_OPTIMIZE_SWITCH = true;
var LayeredBatchingAssembler = /** @class */ (function (_super) {
    __extends(LayeredBatchingAssembler, _super);
    function LayeredBatchingAssembler() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    LayeredBatchingAssembler.prototype.fillBuffers = function (comp, renderer) {
        _super.prototype.fillBuffers.call(this, comp, renderer);
        if (CC_EDITOR || CC_NATIVERENDERER)
            return;
        if (!BATCH_OPTIMIZE_SWITCH)
            return;
        var layer = [];
        this._layers = [layer];
        // 当前节点是自定义渲染的根节点，worldDirtyFlag属性将被逐层传递
        // 此处的dirtyFlag包含世界坐标变化、透明度变化。（参考render-flow.js的_children函数）
        var worldTransformFlag = renderer.worldMatDirty ? cc.RenderFlow.FLAG_WORLD_TRANSFORM : 0;
        var worldOpacityFlag = renderer.parentOpacityDirty ? cc.RenderFlow.FLAG_OPACITY_COLOR : 0;
        var dirtyFlag = worldTransformFlag | worldOpacityFlag;
        comp.node["__gtDirtyFlag"] = dirtyFlag;
        // BFS过程
        var queue = [];
        queue.push(comp.node);
        var depth = 0;
        var end = 1;
        var iter = 0;
        var gtRenderFlag;
        while (iter < queue.length) {
            var node = queue[iter++];
            dirtyFlag = node["__gtDirtyFlag"];
            for (var _i = 0, _a = node.children; _i < _a.length; _i++) {
                var c = _a[_i];
                if (!c._activeInHierarchy || c._opacity === 0)
                    continue;
                gtRenderFlag = c._renderFlag & RENDER_MASK;
                if (gtRenderFlag > 0) {
                    // 移除子节点的renderFlag，使renderFlow不执行它的RENDER函数
                    c["__gtRenderFlag"] = gtRenderFlag;
                    c._renderFlag &= ~gtRenderFlag;
                    layer.push(c);
                }
                // 逐层传递父节点的dirtyFlag
                c["__gtDirtyFlag"] = dirtyFlag | (c._renderFlag & PROP_DIRTY_MASK);
                queue.push(c);
            }
            if (iter == end) {
                // 完成当前层遍历，开始下一层遍历
                ++depth;
                end = queue.length;
                layer = [];
                this._layers.push(layer);
            }
        }
    };
    LayeredBatchingAssembler.prototype.postFillBuffers = function (comp, renderer) {
        // 记录worldMatDirty，函数退出时重置回去
        var originWorldMatDirty = renderer.worldMatDirty;
        if (!BATCH_OPTIMIZE_SWITCH || !this._layers)
            return;
        // off优化开关，避免嵌套
        BATCH_OPTIMIZE_SWITCH = false;
        var gtRenderFlag;
        var gtDirtyFlag;
        // 按层级遍历所有子节点
        for (var _i = 0, _a = this._layers; _i < _a.length; _i++) {
            var layer = _a[_i];
            if (layer.length == 0)
                continue;
            for (var _b = 0, layer_1 = layer; _b < layer_1.length; _b++) {
                var c = layer_1[_b];
                gtRenderFlag = c["__gtRenderFlag"];
                gtDirtyFlag = c["__gtDirtyFlag"];
                // 设置worldMatDirty，在引擎默认fillBuffers()中该变量用于判断是否更新世界坐标
                renderer.worldMatDirty = gtDirtyFlag > 0 ? 1 : 0;
                c._renderFlag |= gtRenderFlag;
                // 调用子节点RenderFlow的剩余部分
                cc.RenderFlow.flows[gtRenderFlag]._func(c);
            }
        }
        this._layers = null;
        BATCH_OPTIMIZE_SWITCH = true;
        renderer.worldMatDirty = originWorldMatDirty;
    };
    return LayeredBatchingAssembler;
}(GTSimpleSpriteAssembler2D_1.default));
exports.default = LayeredBatchingAssembler;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvTGF5ZXJlZEJhdGNoaW5nL0xheWVyZWRCYXRjaGluZ0Fzc2VtYmxlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7Ozs2RUFHNkU7Ozs7Ozs7Ozs7Ozs7OztBQUU3RSwwRUFBcUU7QUFFckUsK0JBQStCO0FBQy9CLElBQU0sV0FBVyxHQUFHLEVBQUUsQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUM7QUFDL0UsSUFBTSxlQUFlLEdBQUcsRUFBRSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQztBQUV4RixpQ0FBaUM7QUFDakMsc0JBQXNCO0FBQ3RCLElBQUkscUJBQXFCLEdBQVksSUFBSSxDQUFDO0FBRTFDO0lBQXNELDRDQUF5QjtJQUEvRTs7SUE4RkEsQ0FBQztJQTNGRyw4Q0FBVyxHQUFYLFVBQVksSUFBSSxFQUFFLFFBQVE7UUFDdEIsaUJBQU0sV0FBVyxZQUFDLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQztRQUVsQyxJQUFJLFNBQVMsSUFBSSxpQkFBaUI7WUFDOUIsT0FBTztRQUVYLElBQUksQ0FBQyxxQkFBcUI7WUFDdEIsT0FBTztRQUVYLElBQUksS0FBSyxHQUFHLEVBQUUsQ0FBQztRQUNmLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUV2Qix3Q0FBd0M7UUFDeEMsNERBQTREO1FBQzVELElBQUksa0JBQWtCLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3pGLElBQUksZ0JBQWdCLEdBQUcsUUFBUSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDMUYsSUFBSSxTQUFTLEdBQUcsa0JBQWtCLEdBQUcsZ0JBQWdCLENBQUM7UUFDdEQsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxTQUFTLENBQUM7UUFFdkMsUUFBUTtRQUNSLElBQUksS0FBSyxHQUFHLEVBQUUsQ0FBQztRQUNmLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRXRCLElBQUksS0FBSyxHQUFXLENBQUMsQ0FBQztRQUN0QixJQUFJLEdBQUcsR0FBVyxDQUFDLENBQUM7UUFDcEIsSUFBSSxJQUFJLEdBQVcsQ0FBQyxDQUFDO1FBQ3JCLElBQUksWUFBWSxDQUFDO1FBQ2pCLE9BQU8sSUFBSSxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUU7WUFDeEIsSUFBSSxJQUFJLEdBQUcsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7WUFDekIsU0FBUyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztZQUVsQyxLQUFjLFVBQWEsRUFBYixLQUFBLElBQUksQ0FBQyxRQUFRLEVBQWIsY0FBYSxFQUFiLElBQWEsRUFBRTtnQkFBeEIsSUFBSSxDQUFDLFNBQUE7Z0JBQ04sSUFBSSxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsSUFBSSxDQUFDLENBQUMsUUFBUSxLQUFLLENBQUM7b0JBQ3pDLFNBQVM7Z0JBRWIsWUFBWSxHQUFHLENBQUMsQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDO2dCQUMzQyxJQUFJLFlBQVksR0FBRyxDQUFDLEVBQUU7b0JBQ2xCLDRDQUE0QztvQkFDNUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsWUFBWSxDQUFDO29CQUNuQyxDQUFDLENBQUMsV0FBVyxJQUFJLENBQUMsWUFBWSxDQUFDO29CQUMvQixLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNqQjtnQkFFRCxvQkFBb0I7Z0JBQ3BCLENBQUMsQ0FBQyxlQUFlLENBQUMsR0FBRyxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUMsV0FBVyxHQUFHLGVBQWUsQ0FBQyxDQUFDO2dCQUNuRSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ2pCO1lBRUQsSUFBSSxJQUFJLElBQUksR0FBRyxFQUFFO2dCQUNiLGtCQUFrQjtnQkFDbEIsRUFBRyxLQUFLLENBQUM7Z0JBQ1QsR0FBRyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUM7Z0JBQ25CLEtBQUssR0FBRyxFQUFFLENBQUM7Z0JBQ1gsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDNUI7U0FDSjtJQUNMLENBQUM7SUFFRCxrREFBZSxHQUFmLFVBQWdCLElBQUksRUFBRSxRQUFRO1FBQzFCLDRCQUE0QjtRQUM1QixJQUFJLG1CQUFtQixHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUM7UUFDakQsSUFBSSxDQUFDLHFCQUFxQixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU87WUFDdkMsT0FBTztRQUVYLGVBQWU7UUFDZixxQkFBcUIsR0FBRyxLQUFLLENBQUM7UUFDOUIsSUFBSSxZQUFZLENBQUM7UUFDakIsSUFBSSxXQUFXLENBQUM7UUFFaEIsYUFBYTtRQUNiLEtBQWtCLFVBQVksRUFBWixLQUFBLElBQUksQ0FBQyxPQUFPLEVBQVosY0FBWSxFQUFaLElBQVksRUFBRTtZQUEzQixJQUFJLEtBQUssU0FBQTtZQUNWLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxDQUFDO2dCQUNqQixTQUFTO1lBRWIsS0FBYyxVQUFLLEVBQUwsZUFBSyxFQUFMLG1CQUFLLEVBQUwsSUFBSyxFQUFFO2dCQUFoQixJQUFJLENBQUMsY0FBQTtnQkFDTixZQUFZLEdBQUcsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUM7Z0JBQ25DLFdBQVcsR0FBRyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUM7Z0JBRWpDLHFEQUFxRDtnQkFDckQsUUFBUSxDQUFDLGFBQWEsR0FBRyxXQUFXLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDakQsQ0FBQyxDQUFDLFdBQVcsSUFBSSxZQUFZLENBQUM7Z0JBRTlCLHVCQUF1QjtnQkFDdkIsRUFBRSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzlDO1NBQ0o7UUFFRCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztRQUNwQixxQkFBcUIsR0FBRyxJQUFJLENBQUM7UUFDN0IsUUFBUSxDQUFDLGFBQWEsR0FBRyxtQkFBbUIsQ0FBQztJQUNqRCxDQUFDO0lBQ0wsK0JBQUM7QUFBRCxDQTlGQSxBQThGQyxDQTlGcUQsbUNBQXlCLEdBOEY5RSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gQXV0aG9yOiBHVCA8Y2FvZ3RhYUBnbWFpbC5jb20+XG4gaHR0cHM6Ly9jYW9ndGFhLmdpdGh1Yi5pb1xuKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cblxuaW1wb3J0IEdUU2ltcGxlU3ByaXRlQXNzZW1ibGVyMkQgZnJvbSBcIi4uL0dUU2ltcGxlU3ByaXRlQXNzZW1ibGVyMkRcIjtcblxuLy8gUmVuZGVyRmxvd+mBjeWOhui/h+eoi+S4re+8jOmcgOimgemYsuatouWtkOiKgueCuei/m+WFpeeahOWHveaVsFxuY29uc3QgUkVOREVSX01BU0sgPSBjYy5SZW5kZXJGbG93LkZMQUdfUkVOREVSIHwgY2MuUmVuZGVyRmxvdy5GTEFHX1BPU1RfUkVOREVSO1xuY29uc3QgUFJPUF9ESVJUWV9NQVNLID0gY2MuUmVuZGVyRmxvdy5GTEFHX09QQUNJVFkgfCBjYy5SZW5kZXJGbG93LkZMQUdfV09STERfVFJBTlNGT1JNO1xuXG4vLyDpgJrov4flvIDlhbPmjqfliLbku4XlnKjmi6XmnInor6VBc3NlbWJsZXLnmoTmoLnoioLngrnlvIDlkK/lkIjmibnkvJjljJZcbi8vIOeUqOS6jumBv+WFjeivpUFzc2VtYmxlcuiiq+W1jOWll+S9v+eUqFxubGV0IEJBVENIX09QVElNSVpFX1NXSVRDSDogYm9vbGVhbiA9IHRydWU7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIExheWVyZWRCYXRjaGluZ0Fzc2VtYmxlciBleHRlbmRzIEdUU2ltcGxlU3ByaXRlQXNzZW1ibGVyMkQge1xuICAgIHByb3RlY3RlZCBfbGF5ZXJzOiBBcnJheTxBcnJheTxjYy5Ob2RlPj47XG5cbiAgICBmaWxsQnVmZmVycyhjb21wLCByZW5kZXJlcikge1xuICAgICAgICBzdXBlci5maWxsQnVmZmVycyhjb21wLCByZW5kZXJlcik7XG5cbiAgICAgICAgaWYgKENDX0VESVRPUiB8fCBDQ19OQVRJVkVSRU5ERVJFUilcbiAgICAgICAgICAgIHJldHVybjtcblxuICAgICAgICBpZiAoIUJBVENIX09QVElNSVpFX1NXSVRDSClcbiAgICAgICAgICAgIHJldHVybjtcblxuICAgICAgICBsZXQgbGF5ZXIgPSBbXTtcbiAgICAgICAgdGhpcy5fbGF5ZXJzID0gW2xheWVyXTtcblxuICAgICAgICAvLyDlvZPliY3oioLngrnmmK/oh6rlrprkuYnmuLLmn5PnmoTmoLnoioLngrnvvIx3b3JsZERpcnR5RmxhZ+WxnuaAp+Wwhuiiq+mAkOWxguS8oOmAklxuICAgICAgICAvLyDmraTlpITnmoRkaXJ0eUZsYWfljIXlkKvkuJbnlYzlnZDmoIflj5jljJbjgIHpgI/mmI7luqblj5jljJbjgILvvIjlj4LogINyZW5kZXItZmxvdy5qc+eahF9jaGlsZHJlbuWHveaVsO+8iVxuICAgICAgICBsZXQgd29ybGRUcmFuc2Zvcm1GbGFnID0gcmVuZGVyZXIud29ybGRNYXREaXJ0eSA/IGNjLlJlbmRlckZsb3cuRkxBR19XT1JMRF9UUkFOU0ZPUk0gOiAwO1xuICAgICAgICBsZXQgd29ybGRPcGFjaXR5RmxhZyA9IHJlbmRlcmVyLnBhcmVudE9wYWNpdHlEaXJ0eSA/IGNjLlJlbmRlckZsb3cuRkxBR19PUEFDSVRZX0NPTE9SIDogMDtcbiAgICAgICAgbGV0IGRpcnR5RmxhZyA9IHdvcmxkVHJhbnNmb3JtRmxhZyB8IHdvcmxkT3BhY2l0eUZsYWc7XG4gICAgICAgIGNvbXAubm9kZVtcIl9fZ3REaXJ0eUZsYWdcIl0gPSBkaXJ0eUZsYWc7XG5cbiAgICAgICAgLy8gQkZT6L+H56iLXG4gICAgICAgIGxldCBxdWV1ZSA9IFtdO1xuICAgICAgICBxdWV1ZS5wdXNoKGNvbXAubm9kZSk7XG5cbiAgICAgICAgbGV0IGRlcHRoOiBudW1iZXIgPSAwO1xuICAgICAgICBsZXQgZW5kOiBudW1iZXIgPSAxO1xuICAgICAgICBsZXQgaXRlcjogbnVtYmVyID0gMDtcbiAgICAgICAgbGV0IGd0UmVuZGVyRmxhZztcbiAgICAgICAgd2hpbGUgKGl0ZXIgPCBxdWV1ZS5sZW5ndGgpIHtcbiAgICAgICAgICAgIGxldCBub2RlID0gcXVldWVbaXRlcisrXTtcbiAgICAgICAgICAgIGRpcnR5RmxhZyA9IG5vZGVbXCJfX2d0RGlydHlGbGFnXCJdO1xuXG4gICAgICAgICAgICBmb3IgKGxldCBjIG9mIG5vZGUuY2hpbGRyZW4pIHtcbiAgICAgICAgICAgICAgICBpZiAoIWMuX2FjdGl2ZUluSGllcmFyY2h5IHx8IGMuX29wYWNpdHkgPT09IDApXG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuXG4gICAgICAgICAgICAgICAgZ3RSZW5kZXJGbGFnID0gYy5fcmVuZGVyRmxhZyAmIFJFTkRFUl9NQVNLO1xuICAgICAgICAgICAgICAgIGlmIChndFJlbmRlckZsYWcgPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIOenu+mZpOWtkOiKgueCueeahHJlbmRlckZsYWfvvIzkvb9yZW5kZXJGbG935LiN5omn6KGM5a6D55qEUkVOREVS5Ye95pWwXG4gICAgICAgICAgICAgICAgICAgIGNbXCJfX2d0UmVuZGVyRmxhZ1wiXSA9IGd0UmVuZGVyRmxhZztcbiAgICAgICAgICAgICAgICAgICAgYy5fcmVuZGVyRmxhZyAmPSB+Z3RSZW5kZXJGbGFnO1xuICAgICAgICAgICAgICAgICAgICBsYXllci5wdXNoKGMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAvLyDpgJDlsYLkvKDpgJLniLboioLngrnnmoRkaXJ0eUZsYWdcbiAgICAgICAgICAgICAgICBjW1wiX19ndERpcnR5RmxhZ1wiXSA9IGRpcnR5RmxhZyB8IChjLl9yZW5kZXJGbGFnICYgUFJPUF9ESVJUWV9NQVNLKTtcbiAgICAgICAgICAgICAgICBxdWV1ZS5wdXNoKGMpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoaXRlciA9PSBlbmQpIHtcbiAgICAgICAgICAgICAgICAvLyDlrozmiJDlvZPliY3lsYLpgY3ljobvvIzlvIDlp4vkuIvkuIDlsYLpgY3ljoZcbiAgICAgICAgICAgICAgICArKyBkZXB0aDtcbiAgICAgICAgICAgICAgICBlbmQgPSBxdWV1ZS5sZW5ndGg7XG4gICAgICAgICAgICAgICAgbGF5ZXIgPSBbXTtcbiAgICAgICAgICAgICAgICB0aGlzLl9sYXllcnMucHVzaChsYXllcik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwb3N0RmlsbEJ1ZmZlcnMoY29tcCwgcmVuZGVyZXIpIHtcbiAgICAgICAgLy8g6K6w5b2Vd29ybGRNYXREaXJ0ee+8jOWHveaVsOmAgOWHuuaXtumHjee9ruWbnuWOu1xuICAgICAgICBsZXQgb3JpZ2luV29ybGRNYXREaXJ0eSA9IHJlbmRlcmVyLndvcmxkTWF0RGlydHk7XG4gICAgICAgIGlmICghQkFUQ0hfT1BUSU1JWkVfU1dJVENIIHx8ICF0aGlzLl9sYXllcnMpXG4gICAgICAgICAgICByZXR1cm47XG5cbiAgICAgICAgLy8gb2Zm5LyY5YyW5byA5YWz77yM6YG/5YWN5bWM5aWXXG4gICAgICAgIEJBVENIX09QVElNSVpFX1NXSVRDSCA9IGZhbHNlO1xuICAgICAgICBsZXQgZ3RSZW5kZXJGbGFnO1xuICAgICAgICBsZXQgZ3REaXJ0eUZsYWc7XG5cbiAgICAgICAgLy8g5oyJ5bGC57qn6YGN5Y6G5omA5pyJ5a2Q6IqC54K5XG4gICAgICAgIGZvciAobGV0IGxheWVyIG9mIHRoaXMuX2xheWVycykge1xuICAgICAgICAgICAgaWYgKGxheWVyLmxlbmd0aCA9PSAwKVxuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuXG4gICAgICAgICAgICBmb3IgKGxldCBjIG9mIGxheWVyKSB7XG4gICAgICAgICAgICAgICAgZ3RSZW5kZXJGbGFnID0gY1tcIl9fZ3RSZW5kZXJGbGFnXCJdO1xuICAgICAgICAgICAgICAgIGd0RGlydHlGbGFnID0gY1tcIl9fZ3REaXJ0eUZsYWdcIl07XG5cbiAgICAgICAgICAgICAgICAvLyDorr7nva53b3JsZE1hdERpcnR577yM5Zyo5byV5pOO6buY6K6kZmlsbEJ1ZmZlcnMoKeS4reivpeWPmOmHj+eUqOS6juWIpOaWreaYr+WQpuabtOaWsOS4lueVjOWdkOagh1xuICAgICAgICAgICAgICAgIHJlbmRlcmVyLndvcmxkTWF0RGlydHkgPSBndERpcnR5RmxhZyA+IDAgPyAxIDogMDtcbiAgICAgICAgICAgICAgICBjLl9yZW5kZXJGbGFnIHw9IGd0UmVuZGVyRmxhZztcblxuICAgICAgICAgICAgICAgIC8vIOiwg+eUqOWtkOiKgueCuVJlbmRlckZsb3fnmoTliankvZnpg6jliIZcbiAgICAgICAgICAgICAgICBjYy5SZW5kZXJGbG93LmZsb3dzW2d0UmVuZGVyRmxhZ10uX2Z1bmMoYyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLl9sYXllcnMgPSBudWxsO1xuICAgICAgICBCQVRDSF9PUFRJTUlaRV9TV0lUQ0ggPSB0cnVlO1xuICAgICAgICByZW5kZXJlci53b3JsZE1hdERpcnR5ID0gb3JpZ2luV29ybGRNYXREaXJ0eTtcbiAgICB9XG59XG4iXX0=