
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/LayeredBatching/LayeredBatchingRootRenderer.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '7e264FDcplMY5rNb2sCjRtf', 'LayeredBatchingRootRenderer');
// Shader/LayeredBatching/LayeredBatchingRootRenderer.ts

"use strict";
/****************************************************************************
 Author: GT <caogtaa@gmail.com>
 https://caogtaa.github.io
****************************************************************************/
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var LayeredBatchingAssembler_1 = require("./LayeredBatchingAssembler");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var LayeredBatchingRootRenderer = /** @class */ (function (_super) {
    __extends(LayeredBatchingRootRenderer, _super);
    function LayeredBatchingRootRenderer() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    LayeredBatchingRootRenderer.prototype.onEnable = function () {
        _super.prototype.onEnable.call(this);
        if (!CC_EDITOR && !CC_NATIVERENDERER)
            this.node._renderFlag |= cc.RenderFlow.FLAG_POST_RENDER;
        // this.node._renderFlag |= cc.RenderFlow.FLAG_RENDER;
    };
    LayeredBatchingRootRenderer.prototype._resetAssembler = function () {
        this.setVertsDirty();
        var assembler = this._assembler = new LayeredBatchingAssembler_1.default();
        assembler.init(this);
    };
    LayeredBatchingRootRenderer = __decorate([
        ccclass
    ], LayeredBatchingRootRenderer);
    return LayeredBatchingRootRenderer;
}(cc.Sprite));
exports.default = LayeredBatchingRootRenderer;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvTGF5ZXJlZEJhdGNoaW5nL0xheWVyZWRCYXRjaGluZ1Jvb3RSZW5kZXJlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7Ozs2RUFHNkU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUU3RSx1RUFBa0U7QUFHNUQsSUFBQSxLQUFzQixFQUFFLENBQUMsVUFBVSxFQUFsQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWlCLENBQUM7QUFHMUM7SUFBeUQsK0NBQVM7SUFBbEU7O0lBY0EsQ0FBQztJQWJHLDhDQUFRLEdBQVI7UUFDSSxpQkFBTSxRQUFRLFdBQUUsQ0FBQztRQUNqQixJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsaUJBQWlCO1lBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxJQUFJLEVBQUUsQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUM7UUFFNUQsc0RBQXNEO0lBQzFELENBQUM7SUFFRCxxREFBZSxHQUFmO1FBQ0ksSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3JCLElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxrQ0FBd0IsRUFBRSxDQUFDO1FBQ2pFLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDekIsQ0FBQztJQWJnQiwyQkFBMkI7UUFEL0MsT0FBTztPQUNhLDJCQUEyQixDQWMvQztJQUFELGtDQUFDO0NBZEQsQUFjQyxDQWR3RCxFQUFFLENBQUMsTUFBTSxHQWNqRTtrQkFkb0IsMkJBQTJCIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiBBdXRob3I6IEdUIDxjYW9ndGFhQGdtYWlsLmNvbT5cbiBodHRwczovL2Nhb2d0YWEuZ2l0aHViLmlvXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuXG5pbXBvcnQgTGF5ZXJlZEJhdGNoaW5nQXNzZW1ibGVyIGZyb20gXCIuL0xheWVyZWRCYXRjaGluZ0Fzc2VtYmxlclwiO1xuXG5cbmNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xuXG5AY2NjbGFzc1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTGF5ZXJlZEJhdGNoaW5nUm9vdFJlbmRlcmVyIGV4dGVuZHMgY2MuU3ByaXRlIHtcbiAgICBvbkVuYWJsZSgpIHtcbiAgICAgICAgc3VwZXIub25FbmFibGUoKTtcbiAgICAgICAgaWYgKCFDQ19FRElUT1IgJiYgIUNDX05BVElWRVJFTkRFUkVSKVxuICAgICAgICAgICAgdGhpcy5ub2RlLl9yZW5kZXJGbGFnIHw9IGNjLlJlbmRlckZsb3cuRkxBR19QT1NUX1JFTkRFUjtcblxuICAgICAgICAvLyB0aGlzLm5vZGUuX3JlbmRlckZsYWcgfD0gY2MuUmVuZGVyRmxvdy5GTEFHX1JFTkRFUjtcbiAgICB9XG5cbiAgICBfcmVzZXRBc3NlbWJsZXIoKSB7XG4gICAgICAgIHRoaXMuc2V0VmVydHNEaXJ0eSgpO1xuICAgICAgICBsZXQgYXNzZW1ibGVyID0gdGhpcy5fYXNzZW1ibGVyID0gbmV3IExheWVyZWRCYXRjaGluZ0Fzc2VtYmxlcigpO1xuICAgICAgICBhc3NlbWJsZXIuaW5pdCh0aGlzKTtcbiAgICB9XG59XG4iXX0=