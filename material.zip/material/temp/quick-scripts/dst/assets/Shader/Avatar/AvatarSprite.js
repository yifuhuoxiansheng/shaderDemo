
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/Avatar/AvatarSprite.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b1649Wc9Q1OSLLcuayZnPTw', 'AvatarSprite');
// Shader/Avatar/AvatarSprite.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-21 17:27:48
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:14:18
*/
var AvatarAssembler_1 = require("./AvatarAssembler");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var AvatarSprite = /** @class */ (function (_super) {
    __extends(AvatarSprite, _super);
    function AvatarSprite() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    AvatarSprite.prototype._resetAssembler = function () {
        this.setVertsDirty();
        var assembler = this._assembler = new AvatarAssembler_1.default();
        assembler.init(this);
    };
    AvatarSprite = __decorate([
        ccclass
    ], AvatarSprite);
    return AvatarSprite;
}(cc.Sprite));
exports.default = AvatarSprite;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvQXZhdGFyL0F2YXRhclNwcml0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsZ0RBQWdEO0FBQ2hELDRCQUE0QjtBQUM1QiwrQ0FBK0M7QUFDL0MsZ0VBQWdFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFaEU7Ozs7RUFJRTtBQUdGLHFEQUFnRDtBQUUxQyxJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUcxQztJQUEwQyxnQ0FBUztJQUFuRDs7SUFNQSxDQUFDO0lBTEcsc0NBQWUsR0FBZjtRQUNJLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNyQixJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUkseUJBQWUsRUFBRSxDQUFDO1FBQ3hELFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDekIsQ0FBQztJQUxnQixZQUFZO1FBRGhDLE9BQU87T0FDYSxZQUFZLENBTWhDO0lBQUQsbUJBQUM7Q0FORCxBQU1DLENBTnlDLEVBQUUsQ0FBQyxNQUFNLEdBTWxEO2tCQU5vQixZQUFZIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gQ29weXJpZ2h0IDIwMjAgQ2FvIEdhb3Rpbmc8Y2FvZ3RhYUBnbWFpbC5jb20+XG4vLyBodHRwczovL2Nhb2d0YWEuZ2l0aHViLmlvXG4vLyBUaGlzIGZpbGUgaXMgbGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLlxuLy8gTGljZW5zZSB0ZXh0IGF2YWlsYWJsZSBhdCBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVFxuXG4vKlxuICogRGF0ZTogMjAyMC0wNy0yMSAxNzoyNzo0OFxuICogTGFzdEVkaXRvcnM6IEdUPGNhb2d0YWFAZ21haWwuY29tPlxuICogTGFzdEVkaXRUaW1lOiAyMDIwLTA3LTIyIDE0OjE0OjE4XG4qLyBcblxuXG5pbXBvcnQgQXZhdGFyQXNzZW1ibGVyIGZyb20gXCIuL0F2YXRhckFzc2VtYmxlclwiO1xuXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEF2YXRhclNwcml0ZSBleHRlbmRzIGNjLlNwcml0ZSB7XG4gICAgX3Jlc2V0QXNzZW1ibGVyKCkge1xuICAgICAgICB0aGlzLnNldFZlcnRzRGlydHkoKTtcbiAgICAgICAgbGV0IGFzc2VtYmxlciA9IHRoaXMuX2Fzc2VtYmxlciA9IG5ldyBBdmF0YXJBc3NlbWJsZXIoKTtcbiAgICAgICAgYXNzZW1ibGVyLmluaXQodGhpcyk7XG4gICAgfVxufVxuIl19