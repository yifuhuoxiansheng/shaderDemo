
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/Avatar/AvatarAssembler.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '45279iUvaxDYLwEzo4OPRTm', 'AvatarAssembler');
// Shader/Avatar/AvatarAssembler.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-21 17:27:48
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-23 16:46:05
*/
var GTAutoFitSpriteAssembler2D_1 = require("../GTAutoFitSpriteAssembler2D");
//@ts-ignore
var gfx = cc.gfx;
var vfmtCustom = new gfx.VertexFormat([
    { name: gfx.ATTR_POSITION, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: gfx.ATTR_UV0, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: "a_p", type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: "a_q", type: gfx.ATTR_TYPE_FLOAT32, num: 2 }
]);
var AvatarAssembler = /** @class */ (function (_super) {
    __extends(AvatarAssembler, _super);
    function AvatarAssembler() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.floatsPerVert = 8;
        return _this;
    }
    // todo: mixin this part
    AvatarAssembler.prototype.initData = function () {
        var data = this._renderData;
        // createFlexData支持创建指定格式的renderData
        data.createFlexData(0, this.verticesCount, this.indicesCount, this.getVfmt());
        // createFlexData不会填充顶点索引信息，手动补充一下
        var indices = data.iDatas[0];
        var count = indices.length / 6;
        for (var i = 0, idx = 0; i < count; i++) {
            var vertextID = i * 4;
            indices[idx++] = vertextID;
            indices[idx++] = vertextID + 1;
            indices[idx++] = vertextID + 2;
            indices[idx++] = vertextID + 1;
            indices[idx++] = vertextID + 3;
            indices[idx++] = vertextID + 2;
        }
    };
    AvatarAssembler.prototype.getVfmt = function () {
        return vfmtCustom;
    };
    AvatarAssembler.prototype.getBuffer = function () {
        //@ts-ignore
        return cc.renderer._handle.getBuffer("mesh", this.getVfmt());
    };
    AvatarAssembler.prototype.updateColor = function (comp, color) {
        // do nothing
    };
    AvatarAssembler.prototype.updateUVs = function (sprite) {
        _super.prototype.updateUVs.call(this, sprite);
        // this._uv可以用sprite._spriteFrame.uv代替
        // this._uv是spriteFrame对node大小自适应缩放后的uv
        var uv = this._uv;
        var isRotated = sprite._spriteFrame.isRotated();
        var l = uv[0], r = uv[2], b = uv[1], t = uv[5];
        if (isRotated) {
            // cc图集里的旋转总是顺时针旋转90度，以原左下角为中心。（旋转后左下角变为左上角）
            l = uv[1];
            r = uv[3];
            b = uv[0];
            t = uv[4];
        }
        var px = 1.0 / (r - l), qx = -l * px; // l / (l-r);
        var py = 1.0 / (b - t), qy = -t * py; // t / (t-b);
        var uvOffset = this.uvOffset;
        var floatsPerVert = this.floatsPerVert;
        var verts = this._renderData.vDatas[0];
        for (var i = 0; i < 4; i++) {
            var dstOffset = floatsPerVert * i + uvOffset;
            if (isRotated) {
                verts[dstOffset + 2] = py;
                verts[dstOffset + 3] = px;
                verts[dstOffset + 4] = qy;
                verts[dstOffset + 5] = qx;
            }
            else {
                verts[dstOffset + 2] = px;
                verts[dstOffset + 3] = py;
                verts[dstOffset + 4] = qx;
                verts[dstOffset + 5] = qy;
            }
        }
    };
    return AvatarAssembler;
}(GTAutoFitSpriteAssembler2D_1.default));
exports.default = AvatarAssembler;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvQXZhdGFyL0F2YXRhckFzc2VtYmxlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsZ0RBQWdEO0FBQ2hELDRCQUE0QjtBQUM1QiwrQ0FBK0M7QUFDL0MsZ0VBQWdFOzs7Ozs7Ozs7Ozs7Ozs7QUFFaEU7Ozs7RUFJRTtBQUdGLDRFQUF1RTtBQUV2RSxZQUFZO0FBQ1osSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQztBQUNqQixJQUFJLFVBQVUsR0FBRyxJQUFJLEdBQUcsQ0FBQyxZQUFZLENBQUM7SUFDbEMsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLGFBQWEsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLGlCQUFpQixFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQUU7SUFDaEUsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLGlCQUFpQixFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQUU7SUFDM0QsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsaUJBQWlCLEVBQUUsR0FBRyxFQUFFLENBQUMsRUFBRTtJQUNwRCxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxHQUFHLEVBQUUsQ0FBQyxFQUFFO0NBQ3ZELENBQUMsQ0FBQztBQUVIO0lBQTZDLG1DQUEwQjtJQUF2RTtRQUFBLHFFQThFQztRQTdFRyxtQkFBYSxHQUFHLENBQUMsQ0FBQzs7SUE2RXRCLENBQUM7SUEzRUcsd0JBQXdCO0lBQ3hCLGtDQUFRLEdBQVI7UUFDSSxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDO1FBQzVCLG9DQUFvQztRQUNwQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFFOUUsa0NBQWtDO1FBQ2xDLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0IsSUFBSSxLQUFLLEdBQUcsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDL0IsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3JDLElBQUksU0FBUyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDdEIsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDO1lBQzNCLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLFNBQVMsR0FBQyxDQUFDLENBQUM7WUFDN0IsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsU0FBUyxHQUFDLENBQUMsQ0FBQztZQUM3QixPQUFPLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxTQUFTLEdBQUMsQ0FBQyxDQUFDO1lBQzdCLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLFNBQVMsR0FBQyxDQUFDLENBQUM7WUFDN0IsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsU0FBUyxHQUFDLENBQUMsQ0FBQztTQUNoQztJQUNMLENBQUM7SUFFRCxpQ0FBTyxHQUFQO1FBQ0ksT0FBTyxVQUFVLENBQUM7SUFDdEIsQ0FBQztJQUVELG1DQUFTLEdBQVQ7UUFDSSxZQUFZO1FBQ1osT0FBTyxFQUFFLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFFRCxxQ0FBVyxHQUFYLFVBQVksSUFBSSxFQUFFLEtBQUs7UUFDbkIsYUFBYTtJQUNqQixDQUFDO0lBRUQsbUNBQVMsR0FBVCxVQUFVLE1BQU07UUFDWixpQkFBTSxTQUFTLFlBQUMsTUFBTSxDQUFDLENBQUM7UUFFeEIsc0NBQXNDO1FBQ3RDLHVDQUF1QztRQUN2QyxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDO1FBQ2xCLElBQUksU0FBUyxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDaEQsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUNULENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQ1QsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFDVCxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRWQsSUFBSSxTQUFTLEVBQUU7WUFDWCw0Q0FBNEM7WUFDNUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdEIsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDekI7UUFFRCxJQUFJLEVBQUUsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQ3BCLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBRyxhQUFhO1FBRTdCLElBQUksRUFBRSxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsRUFDcEIsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFHLGFBQWE7UUFFN0IsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQztRQUM3QixJQUFJLGFBQWEsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1FBQ3ZDLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDeEIsSUFBSSxTQUFTLEdBQUcsYUFBYSxHQUFHLENBQUMsR0FBRyxRQUFRLENBQUM7WUFDN0MsSUFBSSxTQUFTLEVBQUU7Z0JBQ1gsS0FBSyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7Z0JBQzFCLEtBQUssQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO2dCQUMxQixLQUFLLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFDMUIsS0FBSyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7YUFDN0I7aUJBQU07Z0JBQ0gsS0FBSyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7Z0JBQzFCLEtBQUssQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO2dCQUMxQixLQUFLLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFDMUIsS0FBSyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7YUFDN0I7U0FDSjtJQUNMLENBQUM7SUFDTCxzQkFBQztBQUFELENBOUVBLEFBOEVDLENBOUU0QyxvQ0FBMEIsR0E4RXRFIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gQ29weXJpZ2h0IDIwMjAgQ2FvIEdhb3Rpbmc8Y2FvZ3RhYUBnbWFpbC5jb20+XG4vLyBodHRwczovL2Nhb2d0YWEuZ2l0aHViLmlvXG4vLyBUaGlzIGZpbGUgaXMgbGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLlxuLy8gTGljZW5zZSB0ZXh0IGF2YWlsYWJsZSBhdCBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVFxuXG4vKlxuICogRGF0ZTogMjAyMC0wNy0yMSAxNzoyNzo0OFxuICogTGFzdEVkaXRvcnM6IEdUPGNhb2d0YWFAZ21haWwuY29tPlxuICogTGFzdEVkaXRUaW1lOiAyMDIwLTA3LTIzIDE2OjQ2OjA1XG4qLyBcblxuXG5pbXBvcnQgR1RBdXRvRml0U3ByaXRlQXNzZW1ibGVyMkQgZnJvbSBcIi4uL0dUQXV0b0ZpdFNwcml0ZUFzc2VtYmxlcjJEXCI7XG5cbi8vQHRzLWlnbm9yZVxubGV0IGdmeCA9IGNjLmdmeDtcbnZhciB2Zm10Q3VzdG9tID0gbmV3IGdmeC5WZXJ0ZXhGb3JtYXQoW1xuICAgIHsgbmFtZTogZ2Z4LkFUVFJfUE9TSVRJT04sIHR5cGU6IGdmeC5BVFRSX1RZUEVfRkxPQVQzMiwgbnVtOiAyIH0sXG4gICAgeyBuYW1lOiBnZnguQVRUUl9VVjAsIHR5cGU6IGdmeC5BVFRSX1RZUEVfRkxPQVQzMiwgbnVtOiAyIH0sXG4gICAgeyBuYW1lOiBcImFfcFwiLCB0eXBlOiBnZnguQVRUUl9UWVBFX0ZMT0FUMzIsIG51bTogMiB9LFxuICAgIHsgbmFtZTogXCJhX3FcIiwgdHlwZTogZ2Z4LkFUVFJfVFlQRV9GTE9BVDMyLCBudW06IDIgfVxuXSk7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEF2YXRhckFzc2VtYmxlciBleHRlbmRzIEdUQXV0b0ZpdFNwcml0ZUFzc2VtYmxlcjJEIHtcbiAgICBmbG9hdHNQZXJWZXJ0ID0gODtcblxuICAgIC8vIHRvZG86IG1peGluIHRoaXMgcGFydFxuICAgIGluaXREYXRhKCkge1xuICAgICAgICBsZXQgZGF0YSA9IHRoaXMuX3JlbmRlckRhdGE7XG4gICAgICAgIC8vIGNyZWF0ZUZsZXhEYXRh5pSv5oyB5Yib5bu65oyH5a6a5qC85byP55qEcmVuZGVyRGF0YVxuICAgICAgICBkYXRhLmNyZWF0ZUZsZXhEYXRhKDAsIHRoaXMudmVydGljZXNDb3VudCwgdGhpcy5pbmRpY2VzQ291bnQsIHRoaXMuZ2V0VmZtdCgpKTtcblxuICAgICAgICAvLyBjcmVhdGVGbGV4RGF0YeS4jeS8muWhq+WFhemhtueCuee0ouW8leS/oeaBr++8jOaJi+WKqOihpeWFheS4gOS4i1xuICAgICAgICBsZXQgaW5kaWNlcyA9IGRhdGEuaURhdGFzWzBdO1xuICAgICAgICBsZXQgY291bnQgPSBpbmRpY2VzLmxlbmd0aCAvIDY7XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBpZHggPSAwOyBpIDwgY291bnQ7IGkrKykge1xuICAgICAgICAgICAgbGV0IHZlcnRleHRJRCA9IGkgKiA0O1xuICAgICAgICAgICAgaW5kaWNlc1tpZHgrK10gPSB2ZXJ0ZXh0SUQ7XG4gICAgICAgICAgICBpbmRpY2VzW2lkeCsrXSA9IHZlcnRleHRJRCsxO1xuICAgICAgICAgICAgaW5kaWNlc1tpZHgrK10gPSB2ZXJ0ZXh0SUQrMjtcbiAgICAgICAgICAgIGluZGljZXNbaWR4KytdID0gdmVydGV4dElEKzE7XG4gICAgICAgICAgICBpbmRpY2VzW2lkeCsrXSA9IHZlcnRleHRJRCszO1xuICAgICAgICAgICAgaW5kaWNlc1tpZHgrK10gPSB2ZXJ0ZXh0SUQrMjtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGdldFZmbXQoKSB7XG4gICAgICAgIHJldHVybiB2Zm10Q3VzdG9tO1xuICAgIH1cblxuICAgIGdldEJ1ZmZlcigpIHtcbiAgICAgICAgLy9AdHMtaWdub3JlXG4gICAgICAgIHJldHVybiBjYy5yZW5kZXJlci5faGFuZGxlLmdldEJ1ZmZlcihcIm1lc2hcIiwgdGhpcy5nZXRWZm10KCkpO1xuICAgIH1cblxuICAgIHVwZGF0ZUNvbG9yKGNvbXAsIGNvbG9yKSB7XG4gICAgICAgIC8vIGRvIG5vdGhpbmdcbiAgICB9XG5cbiAgICB1cGRhdGVVVnMoc3ByaXRlKSB7XG4gICAgICAgIHN1cGVyLnVwZGF0ZVVWcyhzcHJpdGUpO1xuXG4gICAgICAgIC8vIHRoaXMuX3V25Y+v5Lul55Soc3ByaXRlLl9zcHJpdGVGcmFtZS51duS7o+abv1xuICAgICAgICAvLyB0aGlzLl91duaYr3Nwcml0ZUZyYW1l5a+5bm9kZeWkp+Wwj+iHqumAguW6lOe8qeaUvuWQjueahHV2XG4gICAgICAgIGxldCB1diA9IHRoaXMuX3V2O1xuICAgICAgICBsZXQgaXNSb3RhdGVkID0gc3ByaXRlLl9zcHJpdGVGcmFtZS5pc1JvdGF0ZWQoKTtcbiAgICAgICAgbGV0IGwgPSB1dlswXSxcbiAgICAgICAgICAgIHIgPSB1dlsyXSxcbiAgICAgICAgICAgIGIgPSB1dlsxXSxcbiAgICAgICAgICAgIHQgPSB1dls1XTtcbiAgICAgICAgXG4gICAgICAgIGlmIChpc1JvdGF0ZWQpIHtcbiAgICAgICAgICAgIC8vIGNj5Zu+6ZuG6YeM55qE5peL6L2s5oC75piv6aG65pe26ZKI5peL6L2sOTDluqbvvIzku6Xljp/lt6bkuIvop5LkuLrkuK3lv4PjgILvvIjml4vovazlkI7lt6bkuIvop5Llj5jkuLrlt6bkuIrop5LvvIlcbiAgICAgICAgICAgIGwgPSB1dlsxXTsgIHIgPSB1dlszXTtcbiAgICAgICAgICAgIGIgPSB1dlswXTsgIHQgPSB1dls0XTtcbiAgICAgICAgfVxuXG4gICAgICAgIGxldCBweCA9IDEuMCAvIChyLWwpLFxuICAgICAgICBxeCA9IC1sICogcHg7ICAgLy8gbCAvIChsLXIpO1xuXG4gICAgICAgIGxldCBweSA9IDEuMCAvIChiLXQpLFxuICAgICAgICBxeSA9IC10ICogcHk7ICAgLy8gdCAvICh0LWIpO1xuXG4gICAgICAgIGxldCB1dk9mZnNldCA9IHRoaXMudXZPZmZzZXQ7XG4gICAgICAgIGxldCBmbG9hdHNQZXJWZXJ0ID0gdGhpcy5mbG9hdHNQZXJWZXJ0O1xuICAgICAgICBsZXQgdmVydHMgPSB0aGlzLl9yZW5kZXJEYXRhLnZEYXRhc1swXTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCA0OyBpKyspIHtcbiAgICAgICAgICAgIGxldCBkc3RPZmZzZXQgPSBmbG9hdHNQZXJWZXJ0ICogaSArIHV2T2Zmc2V0O1xuICAgICAgICAgICAgaWYgKGlzUm90YXRlZCkge1xuICAgICAgICAgICAgICAgIHZlcnRzW2RzdE9mZnNldCArIDJdID0gcHk7XG4gICAgICAgICAgICAgICAgdmVydHNbZHN0T2Zmc2V0ICsgM10gPSBweDtcbiAgICAgICAgICAgICAgICB2ZXJ0c1tkc3RPZmZzZXQgKyA0XSA9IHF5O1xuICAgICAgICAgICAgICAgIHZlcnRzW2RzdE9mZnNldCArIDVdID0gcXg7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHZlcnRzW2RzdE9mZnNldCArIDJdID0gcHg7XG4gICAgICAgICAgICAgICAgdmVydHNbZHN0T2Zmc2V0ICsgM10gPSBweTtcbiAgICAgICAgICAgICAgICB2ZXJ0c1tkc3RPZmZzZXQgKyA0XSA9IHF4O1xuICAgICAgICAgICAgICAgIHZlcnRzW2RzdE9mZnNldCArIDVdID0gcXk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG4iXX0=