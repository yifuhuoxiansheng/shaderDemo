
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/MetaBalls/MetaBallsRenderer.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'db62dHiyKNNZJwjNHybzvIL', 'MetaBallsRenderer');
// Shader/MetaBalls/MetaBallsRenderer.ts

"use strict";
/****************************************************************************
 Author: GT <caogtaa@gmail.com>
 https://caogtaa.github.io
****************************************************************************/
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var MetaBallsAssembler_1 = require("./MetaBallsAssembler");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var MetaBallsRenderer = /** @class */ (function (_super) {
    __extends(MetaBallsRenderer, _super);
    function MetaBallsRenderer() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.materialWeb = null;
        _this.materialNative = null;
        return _this;
    }
    MetaBallsRenderer.prototype.onLoad = function () {
        if (CC_NATIVERENDERER) {
            this.materialNative && this.setMaterial(0, this.materialNative);
        }
        else {
            this.materialWeb && this.setMaterial(0, this.materialWeb);
        }
    };
    MetaBallsRenderer.prototype.SetParticles = function (particles) {
        //@ts-ignore
        this._assembler.particles = particles;
        var material = this.getMaterial(0);
        if (particles && material) {
            var PTM_RATIO = cc.PhysicsManager.PTM_RATIO;
            if (CC_NATIVERENDERER) {
                // native渲染时以节点anchor为世界空间原点
                material.setProperty("offset", [0.5, 0.5]);
            }
            else {
                // web默认以左下为世界空间原点。两个平台内shader内通过offset实现坐标统一
                material.setProperty("offset", [0.0, 0.0]);
            }
            // particles.GetRadius() * PTM_RATIO 是相对于场景(世界空间)的大小
            // particles.GetRadius() * PTM_RATIO / this.node.width 是相对于纹理的大小(纹理和屏幕同宽)，范围[0, 1]
            material.setProperty("radius", particles.GetRadius() * PTM_RATIO / this.node.width);
            material.setProperty("yratio", this.node.height / this.node.width);
            material.setProperty("reverseRes", [1.0 / this.node.width, 1.0 / this.node.height]);
        }
        this.setVertsDirty();
    };
    MetaBallsRenderer.prototype._resetAssembler = function () {
        this.setVertsDirty();
        var assembler = this._assembler = new MetaBallsAssembler_1.default();
        assembler.init(this);
    };
    MetaBallsRenderer.prototype.update = function () {
        this.setVertsDirty();
    };
    __decorate([
        property(cc.Material)
    ], MetaBallsRenderer.prototype, "materialWeb", void 0);
    __decorate([
        property(cc.Material)
    ], MetaBallsRenderer.prototype, "materialNative", void 0);
    MetaBallsRenderer = __decorate([
        ccclass
    ], MetaBallsRenderer);
    return MetaBallsRenderer;
}(cc.Sprite));
exports.default = MetaBallsRenderer;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvTWV0YUJhbGxzL01ldGFCYWxsc1JlbmRlcmVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTs7OzZFQUc2RTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRTdFLDJEQUFzRDtBQUVoRCxJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUcxQztJQUErQyxxQ0FBUztJQUF4RDtRQUFBLHFFQWdEQztRQTlDRyxpQkFBVyxHQUFnQixJQUFJLENBQUM7UUFHaEMsb0JBQWMsR0FBZ0IsSUFBSSxDQUFDOztJQTJDdkMsQ0FBQztJQXpDRyxrQ0FBTSxHQUFOO1FBQ0ksSUFBSSxpQkFBaUIsRUFBRTtZQUNuQixJQUFJLENBQUMsY0FBYyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztTQUNuRTthQUFNO1lBQ0gsSUFBSSxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7U0FDN0Q7SUFDTCxDQUFDO0lBRU0sd0NBQVksR0FBbkIsVUFBb0IsU0FBUztRQUN6QixZQUFZO1FBQ1osSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO1FBQ3RDLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbkMsSUFBSSxTQUFTLElBQUksUUFBUSxFQUFFO1lBQ3ZCLElBQUksU0FBUyxHQUFHLEVBQUUsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDO1lBQzVDLElBQUksaUJBQWlCLEVBQUU7Z0JBQ25CLDRCQUE0QjtnQkFDNUIsUUFBUSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQzthQUM5QztpQkFBTTtnQkFDSCw2Q0FBNkM7Z0JBQzdDLFFBQVEsQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7YUFDOUM7WUFFRCxvREFBb0Q7WUFDcEQsa0ZBQWtGO1lBQ2xGLFFBQVEsQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLFNBQVMsQ0FBQyxTQUFTLEVBQUUsR0FBRyxTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNwRixRQUFRLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ25FLFFBQVEsQ0FBQyxXQUFXLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLEdBQUcsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7U0FDdkY7UUFFRCxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDekIsQ0FBQztJQUVELDJDQUFlLEdBQWY7UUFDSSxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDckIsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLDRCQUFrQixFQUFFLENBQUM7UUFDM0QsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUN6QixDQUFDO0lBRUQsa0NBQU0sR0FBTjtRQUNJLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztJQUN6QixDQUFDO0lBN0NEO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUM7MERBQ1U7SUFHaEM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQzs2REFDYTtJQUxsQixpQkFBaUI7UUFEckMsT0FBTztPQUNhLGlCQUFpQixDQWdEckM7SUFBRCx3QkFBQztDQWhERCxBQWdEQyxDQWhEOEMsRUFBRSxDQUFDLE1BQU0sR0FnRHZEO2tCQWhEb0IsaUJBQWlCIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiBBdXRob3I6IEdUIDxjYW9ndGFhQGdtYWlsLmNvbT5cbiBodHRwczovL2Nhb2d0YWEuZ2l0aHViLmlvXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuXG5pbXBvcnQgTWV0YUJhbGxzQXNzZW1ibGVyIGZyb20gXCIuL01ldGFCYWxsc0Fzc2VtYmxlclwiO1xuXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE1ldGFCYWxsc1JlbmRlcmVyIGV4dGVuZHMgY2MuU3ByaXRlIHtcbiAgICBAcHJvcGVydHkoY2MuTWF0ZXJpYWwpXG4gICAgbWF0ZXJpYWxXZWI6IGNjLk1hdGVyaWFsID0gbnVsbDtcblxuICAgIEBwcm9wZXJ0eShjYy5NYXRlcmlhbClcbiAgICBtYXRlcmlhbE5hdGl2ZTogY2MuTWF0ZXJpYWwgPSBudWxsO1xuXG4gICAgb25Mb2FkKCkge1xuICAgICAgICBpZiAoQ0NfTkFUSVZFUkVOREVSRVIpIHtcbiAgICAgICAgICAgIHRoaXMubWF0ZXJpYWxOYXRpdmUgJiYgdGhpcy5zZXRNYXRlcmlhbCgwLCB0aGlzLm1hdGVyaWFsTmF0aXZlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMubWF0ZXJpYWxXZWIgJiYgdGhpcy5zZXRNYXRlcmlhbCgwLCB0aGlzLm1hdGVyaWFsV2ViKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHB1YmxpYyBTZXRQYXJ0aWNsZXMocGFydGljbGVzKSB7XG4gICAgICAgIC8vQHRzLWlnbm9yZVxuICAgICAgICB0aGlzLl9hc3NlbWJsZXIucGFydGljbGVzID0gcGFydGljbGVzO1xuICAgICAgICBsZXQgbWF0ZXJpYWwgPSB0aGlzLmdldE1hdGVyaWFsKDApO1xuICAgICAgICBpZiAocGFydGljbGVzICYmIG1hdGVyaWFsKSB7XG4gICAgICAgICAgICBsZXQgUFRNX1JBVElPID0gY2MuUGh5c2ljc01hbmFnZXIuUFRNX1JBVElPO1xuICAgICAgICAgICAgaWYgKENDX05BVElWRVJFTkRFUkVSKSB7XG4gICAgICAgICAgICAgICAgLy8gbmF0aXZl5riy5p+T5pe25Lul6IqC54K5YW5jaG9y5Li65LiW55WM56m66Ze05Y6f54K5XG4gICAgICAgICAgICAgICAgbWF0ZXJpYWwuc2V0UHJvcGVydHkoXCJvZmZzZXRcIiwgWzAuNSwgMC41XSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIHdlYum7mOiupOS7peW3puS4i+S4uuS4lueVjOepuumXtOWOn+eCueOAguS4pOS4quW5s+WPsOWGhXNoYWRlcuWGhemAmui/h29mZnNldOWunueOsOWdkOagh+e7n+S4gFxuICAgICAgICAgICAgICAgIG1hdGVyaWFsLnNldFByb3BlcnR5KFwib2Zmc2V0XCIsIFswLjAsIDAuMF0pO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBwYXJ0aWNsZXMuR2V0UmFkaXVzKCkgKiBQVE1fUkFUSU8g5piv55u45a+55LqO5Zy65pmvKOS4lueVjOepuumXtCnnmoTlpKflsI9cbiAgICAgICAgICAgIC8vIHBhcnRpY2xlcy5HZXRSYWRpdXMoKSAqIFBUTV9SQVRJTyAvIHRoaXMubm9kZS53aWR0aCDmmK/nm7jlr7nkuo7nurnnkIbnmoTlpKflsI8o57q555CG5ZKM5bGP5bmV5ZCM5a69Ke+8jOiMg+WbtFswLCAxXVxuICAgICAgICAgICAgbWF0ZXJpYWwuc2V0UHJvcGVydHkoXCJyYWRpdXNcIiwgcGFydGljbGVzLkdldFJhZGl1cygpICogUFRNX1JBVElPIC8gdGhpcy5ub2RlLndpZHRoKTtcbiAgICAgICAgICAgIG1hdGVyaWFsLnNldFByb3BlcnR5KFwieXJhdGlvXCIsIHRoaXMubm9kZS5oZWlnaHQgLyB0aGlzLm5vZGUud2lkdGgpO1xuICAgICAgICAgICAgbWF0ZXJpYWwuc2V0UHJvcGVydHkoXCJyZXZlcnNlUmVzXCIsIFsxLjAgLyB0aGlzLm5vZGUud2lkdGgsIDEuMCAvIHRoaXMubm9kZS5oZWlnaHRdKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuc2V0VmVydHNEaXJ0eSgpO1xuICAgIH1cblxuICAgIF9yZXNldEFzc2VtYmxlcigpIHtcbiAgICAgICAgdGhpcy5zZXRWZXJ0c0RpcnR5KCk7XG4gICAgICAgIGxldCBhc3NlbWJsZXIgPSB0aGlzLl9hc3NlbWJsZXIgPSBuZXcgTWV0YUJhbGxzQXNzZW1ibGVyKCk7XG4gICAgICAgIGFzc2VtYmxlci5pbml0KHRoaXMpO1xuICAgIH1cblxuICAgIHVwZGF0ZSgpIHtcbiAgICAgICAgdGhpcy5zZXRWZXJ0c0RpcnR5KCk7XG4gICAgfVxufVxuIl19