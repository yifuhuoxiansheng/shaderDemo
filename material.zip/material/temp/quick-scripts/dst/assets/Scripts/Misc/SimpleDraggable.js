
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/Misc/SimpleDraggable.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '89871MxfkBJjJh0o236XNDC', 'SimpleDraggable');
// Scripts/Misc/SimpleDraggable.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-13 02:44:17
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:01:30
*/
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SimpleDraggable = /** @class */ (function (_super) {
    __extends(SimpleDraggable, _super);
    function SimpleDraggable() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._touchOffset = cc.Vec2.ZERO;
        _this._isDragging = false;
        _this._moveCallback = null;
        return _this;
    }
    SimpleDraggable.prototype.onLoad = function () {
        this.node.on(cc.Node.EventType.TOUCH_START, this.OnTouchStart.bind(this));
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.OnTouchMove.bind(this));
        this.node.on(cc.Node.EventType.TOUCH_END, this.OnTouchEnd.bind(this));
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.OnTouchEnd.bind(this));
    };
    SimpleDraggable.prototype.Setup = function (moveCallback) {
        this._moveCallback = moveCallback;
    };
    SimpleDraggable.prototype.OnTouchStart = function (e) {
        var touchWorldPos = e.getLocation();
        var nodeWorldPos = this.node.convertToWorldSpaceAR(cc.Vec2.ZERO);
        this._touchOffset = nodeWorldPos.sub(touchWorldPos);
        this._isDragging = true;
        this._moveCallback && this._moveCallback(this.node.position);
    };
    SimpleDraggable.prototype.OnTouchMove = function (e) {
        if (!this._isDragging)
            return;
        var touchWorldPos = e.getLocation();
        this.TraceTouchPos(touchWorldPos);
        this._moveCallback && this._moveCallback(this.node.position);
    };
    SimpleDraggable.prototype.OnTouchEnd = function (e) {
        if (!this._isDragging)
            return;
        this._isDragging = false;
    };
    SimpleDraggable.prototype.TraceTouchPos = function (worldPos) {
        var nodeWorldPos = worldPos.add(this._touchOffset);
        var localPos = this.node.parent.convertToNodeSpaceAR(nodeWorldPos);
        this.node.position = localPos;
    };
    SimpleDraggable = __decorate([
        ccclass
    ], SimpleDraggable);
    return SimpleDraggable;
}(cc.Component));
exports.default = SimpleDraggable;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHRzL01pc2MvU2ltcGxlRHJhZ2dhYmxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxnREFBZ0Q7QUFDaEQsNEJBQTRCO0FBQzVCLCtDQUErQztBQUMvQyxnRUFBZ0U7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVoRTs7OztFQUlFO0FBR0ksSUFBQSxLQUF3QixFQUFFLENBQUMsVUFBVSxFQUFuQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWtCLENBQUM7QUFHNUM7SUFBNkMsbUNBQVk7SUFBekQ7UUFBQSxxRUE2Q0M7UUE1Q2Esa0JBQVksR0FBWSxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztRQUNyQyxpQkFBVyxHQUFZLEtBQUssQ0FBQztRQUM3QixtQkFBYSxHQUEyQixJQUFJLENBQUM7O0lBMEMzRCxDQUFDO0lBeENHLGdDQUFNLEdBQU47UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUMxRSxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUN4RSxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUN0RSxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUM3RSxDQUFDO0lBRU0sK0JBQUssR0FBWixVQUFhLFlBQW9DO1FBQzdDLElBQUksQ0FBQyxhQUFhLEdBQUcsWUFBWSxDQUFDO0lBQ3RDLENBQUM7SUFFUyxzQ0FBWSxHQUF0QixVQUF1QixDQUFzQjtRQUN6QyxJQUFJLGFBQWEsR0FBRyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDcEMsSUFBSSxZQUFZLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2pFLElBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUNwRCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztRQUN4QixJQUFJLENBQUMsYUFBYSxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBRVMscUNBQVcsR0FBckIsVUFBc0IsQ0FBc0I7UUFDeEMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXO1lBQ2pCLE9BQU87UUFFWCxJQUFJLGFBQWEsR0FBRyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDcEMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUNsQyxJQUFJLENBQUMsYUFBYSxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBRVMsb0NBQVUsR0FBcEIsVUFBcUIsQ0FBc0I7UUFDdkMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXO1lBQ2pCLE9BQU87UUFFWCxJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztJQUM3QixDQUFDO0lBRVMsdUNBQWEsR0FBdkIsVUFBd0IsUUFBaUI7UUFDckMsSUFBSSxZQUFZLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDbkQsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsb0JBQW9CLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDbkUsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDO0lBQ2xDLENBQUM7SUE1Q2dCLGVBQWU7UUFEbkMsT0FBTztPQUNhLGVBQWUsQ0E2Q25DO0lBQUQsc0JBQUM7Q0E3Q0QsQUE2Q0MsQ0E3QzRDLEVBQUUsQ0FBQyxTQUFTLEdBNkN4RDtrQkE3Q29CLGVBQWUiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDb3B5cmlnaHQgMjAyMCBDYW8gR2FvdGluZzxjYW9ndGFhQGdtYWlsLmNvbT5cbi8vIGh0dHBzOi8vY2FvZ3RhYS5naXRodWIuaW9cbi8vIFRoaXMgZmlsZSBpcyBsaWNlbnNlZCB1bmRlciB0aGUgTUlUIExpY2Vuc2UuXG4vLyBMaWNlbnNlIHRleHQgYXZhaWxhYmxlIGF0IGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlUXG5cbi8qXG4gKiBEYXRlOiAyMDIwLTA3LTEzIDAyOjQ0OjE3XG4gKiBMYXN0RWRpdG9yczogR1Q8Y2FvZ3RhYUBnbWFpbC5jb20+XG4gKiBMYXN0RWRpdFRpbWU6IDIwMjAtMDctMjIgMTQ6MDE6MzBcbiovIFxuXG5cbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XG5cbkBjY2NsYXNzXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBTaW1wbGVEcmFnZ2FibGUgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xuICAgIHByb3RlY3RlZCBfdG91Y2hPZmZzZXQ6IGNjLlZlYzIgPSBjYy5WZWMyLlpFUk87XG4gICAgcHJvdGVjdGVkIF9pc0RyYWdnaW5nOiBib29sZWFuID0gZmFsc2U7XG4gICAgcHJvdGVjdGVkIF9tb3ZlQ2FsbGJhY2s6IChwb3M6IGNjLlZlYzIpID0+IHZvaWQgPSBudWxsO1xuICAgIFxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULCB0aGlzLk9uVG91Y2hTdGFydC5iaW5kKHRoaXMpKTtcbiAgICAgICAgdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX01PVkUsIHRoaXMuT25Ub3VjaE1vdmUuYmluZCh0aGlzKSk7XG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsIHRoaXMuT25Ub3VjaEVuZC5iaW5kKHRoaXMpKTtcbiAgICAgICAgdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0NBTkNFTCwgdGhpcy5PblRvdWNoRW5kLmJpbmQodGhpcykpO1xuICAgIH1cblxuICAgIHB1YmxpYyBTZXR1cChtb3ZlQ2FsbGJhY2s6IChwb3M6IGNjLlZlYzIpID0+IHZvaWQpIHtcbiAgICAgICAgdGhpcy5fbW92ZUNhbGxiYWNrID0gbW92ZUNhbGxiYWNrO1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBPblRvdWNoU3RhcnQoZTogY2MuRXZlbnQuRXZlbnRUb3VjaCkge1xuICAgICAgICBsZXQgdG91Y2hXb3JsZFBvcyA9IGUuZ2V0TG9jYXRpb24oKTtcbiAgICAgICAgbGV0IG5vZGVXb3JsZFBvcyA9IHRoaXMubm9kZS5jb252ZXJ0VG9Xb3JsZFNwYWNlQVIoY2MuVmVjMi5aRVJPKTtcbiAgICAgICAgdGhpcy5fdG91Y2hPZmZzZXQgPSBub2RlV29ybGRQb3Muc3ViKHRvdWNoV29ybGRQb3MpO1xuICAgICAgICB0aGlzLl9pc0RyYWdnaW5nID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5fbW92ZUNhbGxiYWNrICYmIHRoaXMuX21vdmVDYWxsYmFjayh0aGlzLm5vZGUucG9zaXRpb24pO1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBPblRvdWNoTW92ZShlOiBjYy5FdmVudC5FdmVudFRvdWNoKSB7XG4gICAgICAgIGlmICghdGhpcy5faXNEcmFnZ2luZylcbiAgICAgICAgICAgIHJldHVybjtcblxuICAgICAgICBsZXQgdG91Y2hXb3JsZFBvcyA9IGUuZ2V0TG9jYXRpb24oKTtcbiAgICAgICAgdGhpcy5UcmFjZVRvdWNoUG9zKHRvdWNoV29ybGRQb3MpO1xuICAgICAgICB0aGlzLl9tb3ZlQ2FsbGJhY2sgJiYgdGhpcy5fbW92ZUNhbGxiYWNrKHRoaXMubm9kZS5wb3NpdGlvbik7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIE9uVG91Y2hFbmQoZTogY2MuRXZlbnQuRXZlbnRUb3VjaCkge1xuICAgICAgICBpZiAoIXRoaXMuX2lzRHJhZ2dpbmcpXG4gICAgICAgICAgICByZXR1cm47XG5cbiAgICAgICAgdGhpcy5faXNEcmFnZ2luZyA9IGZhbHNlO1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBUcmFjZVRvdWNoUG9zKHdvcmxkUG9zOiBjYy5WZWMyKSB7XG4gICAgICAgIGxldCBub2RlV29ybGRQb3MgPSB3b3JsZFBvcy5hZGQodGhpcy5fdG91Y2hPZmZzZXQpO1xuICAgICAgICBsZXQgbG9jYWxQb3MgPSB0aGlzLm5vZGUucGFyZW50LmNvbnZlcnRUb05vZGVTcGFjZUFSKG5vZGVXb3JsZFBvcyk7XG4gICAgICAgIHRoaXMubm9kZS5wb3NpdGlvbiA9IGxvY2FsUG9zO1xuICAgIH1cbn1cbiJdfQ==