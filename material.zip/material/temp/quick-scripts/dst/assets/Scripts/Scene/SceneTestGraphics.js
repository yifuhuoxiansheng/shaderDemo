
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/Scene/SceneTestGraphics.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '7ec6envootE0LqAVSRT/P5s', 'SceneTestGraphics');
// Scripts/Scene/SceneTestGraphics.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-23 16:15:08
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-23 16:43:03
*/
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SceneTestGraphics = /** @class */ (function (_super) {
    __extends(SceneTestGraphics, _super);
    function SceneTestGraphics() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.graphics = null;
        return _this;
    }
    SceneTestGraphics.prototype.onLoad = function () {
        var ctx = this.graphics;
        ctx.clear();
        ctx.strokeColor = cc.Color.BLACK;
        ctx.fillColor = cc.Color.RED;
        ctx.lineWidth = 5;
        ctx.moveTo(0, 0);
        ctx.lineTo(100, 100);
        ctx.stroke();
        ctx.rect(20, 20, 80, 100);
        ctx.fill();
    };
    __decorate([
        property(cc.Graphics)
    ], SceneTestGraphics.prototype, "graphics", void 0);
    SceneTestGraphics = __decorate([
        ccclass
    ], SceneTestGraphics);
    return SceneTestGraphics;
}(cc.Component));
exports.default = SceneTestGraphics;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHRzL1NjZW5lL1NjZW5lVGVzdEdyYXBoaWNzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxnREFBZ0Q7QUFDaEQsNEJBQTRCO0FBQzVCLCtDQUErQztBQUMvQyxnRUFBZ0U7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVoRTs7OztFQUlFO0FBRUksSUFBQSxLQUF3QixFQUFFLENBQUMsVUFBVSxFQUFuQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWtCLENBQUM7QUFHNUM7SUFBK0MscUNBQVk7SUFBM0Q7UUFBQSxxRUFpQkM7UUFmRyxjQUFRLEdBQWdCLElBQUksQ0FBQzs7SUFlakMsQ0FBQztJQWJHLGtDQUFNLEdBQU47UUFDSSxJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDO1FBQ3hCLEdBQUcsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNaLEdBQUcsQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDakMsR0FBRyxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztRQUM3QixHQUFHLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQztRQUNsQixHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNqQixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNyQixHQUFHLENBQUMsTUFBTSxFQUFFLENBQUM7UUFFYixHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQzFCLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUNmLENBQUM7SUFkRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDO3VEQUNPO0lBRlosaUJBQWlCO1FBRHJDLE9BQU87T0FDYSxpQkFBaUIsQ0FpQnJDO0lBQUQsd0JBQUM7Q0FqQkQsQUFpQkMsQ0FqQjhDLEVBQUUsQ0FBQyxTQUFTLEdBaUIxRDtrQkFqQm9CLGlCQUFpQiIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIENvcHlyaWdodCAyMDIwIENhbyBHYW90aW5nPGNhb2d0YWFAZ21haWwuY29tPlxuLy8gaHR0cHM6Ly9jYW9ndGFhLmdpdGh1Yi5pb1xuLy8gVGhpcyBmaWxlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS5cbi8vIExpY2Vuc2UgdGV4dCBhdmFpbGFibGUgYXQgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVRcblxuLypcbiAqIERhdGU6IDIwMjAtMDctMjMgMTY6MTU6MDhcbiAqIExhc3RFZGl0b3JzOiBHVDxjYW9ndGFhQGdtYWlsLmNvbT5cbiAqIExhc3RFZGl0VGltZTogMjAyMC0wNy0yMyAxNjo0MzowM1xuKi9cblxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFNjZW5lVGVzdEdyYXBoaWNzIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcbiAgICBAcHJvcGVydHkoY2MuR3JhcGhpY3MpXG4gICAgZ3JhcGhpY3M6IGNjLkdyYXBoaWNzID0gbnVsbDtcblxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgbGV0IGN0eCA9IHRoaXMuZ3JhcGhpY3M7XG4gICAgICAgIGN0eC5jbGVhcigpO1xuICAgICAgICBjdHguc3Ryb2tlQ29sb3IgPSBjYy5Db2xvci5CTEFDSztcbiAgICAgICAgY3R4LmZpbGxDb2xvciA9IGNjLkNvbG9yLlJFRDtcbiAgICAgICAgY3R4LmxpbmVXaWR0aCA9IDU7XG4gICAgICAgIGN0eC5tb3ZlVG8oMCwgMCk7XG4gICAgICAgIGN0eC5saW5lVG8oMTAwLCAxMDApO1xuICAgICAgICBjdHguc3Ryb2tlKCk7XG5cbiAgICAgICAgY3R4LnJlY3QoMjAsIDIwLCA4MCwgMTAwKTtcbiAgICAgICAgY3R4LmZpbGwoKTsgICAgXG4gICAgfVxufVxuIl19