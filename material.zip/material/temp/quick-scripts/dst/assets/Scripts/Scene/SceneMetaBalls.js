
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/Scene/SceneMetaBalls.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '5d511arYq1Fy75gm6m2P7X0', 'SceneMetaBalls');
// Scripts/Scene/SceneMetaBalls.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-13 02:44:16
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:01:57
*/
var MetaBallsRenderer_1 = require("../../Shader/MetaBalls/MetaBallsRenderer");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SceneMetaBalls = /** @class */ (function (_super) {
    __extends(SceneMetaBalls, _super);
    function SceneMetaBalls() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.waterRendererCamera = null;
        _this.waterRenderer = null;
        _this.waterRendererPass2 = null;
        _this.metaBallsRenderer = null;
        _this.particleBox = null;
        _this._world = null;
        _this._particles = null;
        _this._particleGroup = null;
        return _this;
    }
    SceneMetaBalls.prototype.onLoad = function () {
        if (!CC_EDITOR) {
            this.SetupWorld();
        }
        var texture = new cc.RenderTexture();
        var size = this.waterRendererPass2.node.getContentSize();
        texture.initWithSize(size.width, size.height);
        var spriteFrame = new cc.SpriteFrame();
        spriteFrame.setTexture(texture);
        this.waterRendererCamera.targetTexture = texture;
        this.waterRendererPass2.spriteFrame = spriteFrame;
    };
    SceneMetaBalls.prototype.SetupWorld = function () {
        // enable physics manager
        var physicsManager = cc.director.getPhysicsManager();
        physicsManager.enabled = true;
        var world = this._world = physicsManager._world; // new b2.World(new b2.Vec2(0, -15.0));
        var psd = new b2.ParticleSystemDef();
        psd.radius = 0.35;
        // psd.dampingStrength = 1.5;
        psd.viscousStrength = 0;
        this._particles = world.CreateParticleSystem(psd);
    };
    SceneMetaBalls.prototype.CreateParticlesGroup = function () {
        var PTM_RATIO = cc.PhysicsManager.PTM_RATIO;
        var boxSize = this.particleBox.getContentSize();
        var boxPos = this.particleBox.getPosition();
        var size = cc.winSize;
        var box = new b2.PolygonShape();
        // https://google.github.io/liquidfun/API-Ref/html/classb2_polygon_shape.html#a890690250115483da6c7d69829be087e
        // Build vertices to represent an oriented box.
        // box的大小影响粒子的数量
        box.SetAsBox(boxSize.width / 2 / PTM_RATIO, boxSize.height / 2 / PTM_RATIO);
        var particleGroupDef = new b2.ParticleGroupDef();
        particleGroupDef.shape = box;
        particleGroupDef.flags = b2.waterParticle;
        particleGroupDef.position.Set((boxPos.x + size.width / 2) / PTM_RATIO, (boxPos.y + size.height / 2) / PTM_RATIO);
        this._particleGroup = this._particles.CreateParticleGroup(particleGroupDef);
        this.metaBallsRenderer.SetParticles(this._particles);
        var vertsCount = this._particles.GetParticleCount();
        console.log(vertsCount);
    };
    SceneMetaBalls.prototype.GenerateWater = function () {
        this.ResetParticleGroup();
        // re-create particles in next tick
        // otherwise old particle system is not correctly released
        // this is a non-repeat schedule
        var that = this;
        cc.director.getScheduler().schedule(function () {
            that.CreateParticlesGroup();
        }, this.node, 0, 0, 0, false);
    };
    SceneMetaBalls.prototype.ResetParticleGroup = function () {
        if (this._particleGroup != null) {
            this._particleGroup.DestroyParticles(false);
            this._particles.DestroyParticleGroup(this._particleGroup);
            this._particleGroup = null;
        }
    };
    __decorate([
        property(cc.Camera)
    ], SceneMetaBalls.prototype, "waterRendererCamera", void 0);
    __decorate([
        property(cc.Node)
    ], SceneMetaBalls.prototype, "waterRenderer", void 0);
    __decorate([
        property(cc.Sprite)
    ], SceneMetaBalls.prototype, "waterRendererPass2", void 0);
    __decorate([
        property(MetaBallsRenderer_1.default)
    ], SceneMetaBalls.prototype, "metaBallsRenderer", void 0);
    __decorate([
        property(cc.Node)
    ], SceneMetaBalls.prototype, "particleBox", void 0);
    SceneMetaBalls = __decorate([
        ccclass
    ], SceneMetaBalls);
    return SceneMetaBalls;
}(cc.Component));
exports.default = SceneMetaBalls;
var enableLowLevelOptimize = true;
if (enableLowLevelOptimize) {
    cc.game.once(cc.game.EVENT_ENGINE_INITED, function () {
        // b2ParticleSystem.prototype.FindContacts_Reference = function (contacts) {
        //@ts-ignore
        b2.ParticleSystem.prototype.FindContacts_Reference = function (contacts) {
            if (!this.m_flagsBuffer.data) {
                throw new Error();
            }
            if (!this.m_positionBuffer.data) {
                throw new Error();
            }
            var pos_data = this.m_positionBuffer.data;
            var squaredDiameter = this.m_squaredDiameter;
            var inverseDiameter = this.m_inverseDiameter;
            // DEBUG: b2Assert(contacts === this.m_contactBuffer);
            var beginProxy = 0;
            var endProxy = this.m_proxyBuffer.count;
            this.m_contactBuffer.count = 0;
            // let contactBuffer = this.m_contactBuffer;
            var proxyData = this.m_proxyBuffer.data;
            //@ts-ignore
            var computeRelativeTag = b2.ParticleSystem.computeRelativeTag;
            // var AddContact = this.AddContact2.bind(this);
            var dataA;
            var tagA = 0;
            var indexA = 0;
            var rightTag = 0;
            var dataB;
            var pos_data = this.m_positionBuffer.data;
            var flagBufferData = this.m_flagsBuffer.data;
            var flagBufferDataA;
            var indexB = 0;
            var pos_dataA;
            var pos_dataB;
            var ax = 0, ay = 0, bx = 0, by = 0, dx = 0, dy = 0;
            var distBtParticlesSq = 0;
            var bottomLeftTag = 0;
            var bottomRightTag = 0;
            var isFin = isFinite;
            for (var a = beginProxy, c = beginProxy; a < endProxy; ++a) {
                dataA = proxyData[a];
                tagA = dataA.tag;
                indexA = dataA.index;
                pos_dataA = pos_data[indexA];
                flagBufferDataA = flagBufferData[indexA];
                rightTag = computeRelativeTag(tagA, 1, 0);
                for (var b = a + 1; b < endProxy; ++b) {
                    dataB = proxyData[b];
                    if (rightTag < dataB.tag) {
                        break;
                    }
                    // ------- AddContact(indexA, proxyData[b].index, contactBuffer);
                    indexB = dataB.index;
                    // pos_dataA = pos_data[indexA];
                    pos_dataB = pos_data[indexB];
                    // DEBUG: b2Assert(contacts === this.m_contactBuffer);
                    ///b2Vec2 d = m_positionBuffer.data[b] - m_positionBuffer.data[a];
                    bx = pos_dataB.x;
                    by = pos_dataB.y;
                    ax = pos_dataA.x;
                    ay = pos_dataA.y;
                    dx = bx - ax;
                    dy = by - ay;
                    // var d = b2.Vec2.SubVV(pos_data[b], pos_data[a], s_d);
                    distBtParticlesSq = dx * dx + dy * dy;
                    // var distBtParticlesSq = b2.Vec2.DotVV(d, d);
                    if (distBtParticlesSq < squaredDiameter) {
                        var invD = 1 / Math.sqrt(distBtParticlesSq);
                        // var invD = b2.InvSqrt(distBtParticlesSq);
                        if (!isFin(invD)) {
                            invD = 1.98177537e+019;
                        }
                        ///b2ParticleContact& contact = contacts.Append();
                        var contact = this.m_contactBuffer.data[this.m_contactBuffer.Append()];
                        contact.indexA = indexA;
                        contact.indexB = indexB;
                        contact.flags = flagBufferDataA | flagBufferData[indexB];
                        contact.weight = 1 - distBtParticlesSq * invD * inverseDiameter;
                        ///contact.SetNormal(invD * d);
                        contact.normal.x = invD * dx;
                        contact.normal.y = invD * dy;
                        // b2.Vec2.MulSV(invD, d, contact.normal);
                    }
                    // end ------- AddContact(indexA, proxyData[b].index, contactBuffer);
                }
                bottomLeftTag = computeRelativeTag(tagA, -1, 1);
                for (; c < endProxy; ++c) {
                    if (bottomLeftTag <= proxyData[c].tag) {
                        break;
                    }
                }
                bottomRightTag = computeRelativeTag(tagA, 1, 1);
                for (var b = c; b < endProxy; ++b) {
                    dataB = proxyData[b];
                    if (bottomRightTag < dataB.tag) {
                        break;
                    }
                    // ------- AddContact(indexA, proxyData[b].index, contactBuffer);
                    indexB = dataB.index;
                    // pos_dataA = pos_data[indexA];
                    pos_dataB = pos_data[indexB];
                    // DEBUG: b2Assert(contacts === this.m_contactBuffer);
                    ///b2Vec2 d = m_positionBuffer.data[b] - m_positionBuffer.data[a];
                    bx = pos_dataB.x;
                    by = pos_dataB.y;
                    ax = pos_dataA.x;
                    ay = pos_dataA.y;
                    dx = bx - ax;
                    dy = by - ay;
                    // var d = b2.Vec2.SubVV(pos_data[b], pos_data[a], s_d);
                    distBtParticlesSq = dx * dx + dy * dy;
                    // var distBtParticlesSq = b2.Vec2.DotVV(d, d);
                    if (distBtParticlesSq < squaredDiameter) {
                        var invD = 1 / Math.sqrt(distBtParticlesSq);
                        // var invD = b2.InvSqrt(distBtParticlesSq);
                        if (!isFin(invD)) {
                            invD = 1.98177537e+019;
                        }
                        ///b2ParticleContact& contact = contacts.Append();
                        var contact = this.m_contactBuffer.data[this.m_contactBuffer.Append()];
                        contact.indexA = indexA;
                        contact.indexB = indexB;
                        contact.flags = flagBufferDataA | flagBufferData[indexB];
                        contact.weight = 1 - distBtParticlesSq * invD * inverseDiameter;
                        ///contact.SetNormal(invD * d);
                        contact.normal.x = invD * dx;
                        contact.normal.y = invD * dy;
                        // b2.Vec2.MulSV(invD, d, contact.normal);
                    }
                    // end ------- AddContact(indexA, proxyData[b].index, contactBuffer);
                }
            }
        };
    });
}

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHRzL1NjZW5lL1NjZW5lTWV0YUJhbGxzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxnREFBZ0Q7QUFDaEQsNEJBQTRCO0FBQzVCLCtDQUErQztBQUMvQyxnRUFBZ0U7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVoRTs7OztFQUlFO0FBR0YsOEVBQXlFO0FBRW5FLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQTRDLGtDQUFZO0lBQXhEO1FBQUEscUVBaUdDO1FBL0ZBLHlCQUFtQixHQUFjLElBQUksQ0FBQztRQUd0QyxtQkFBYSxHQUFZLElBQUksQ0FBQztRQUc5Qix3QkFBa0IsR0FBYyxJQUFJLENBQUM7UUFHckMsdUJBQWlCLEdBQXNCLElBQUksQ0FBQztRQUc1QyxpQkFBVyxHQUFZLElBQUksQ0FBQztRQUVsQixZQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ2QsZ0JBQVUsR0FBRyxJQUFJLENBQUM7UUFDbEIsb0JBQWMsR0FBRyxJQUFJLENBQUM7O0lBK0VqQyxDQUFDO0lBN0VBLCtCQUFNLEdBQU47UUFDQyxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2YsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1NBQ2xCO1FBRUQsSUFBTSxPQUFPLEdBQUcsSUFBSSxFQUFFLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDdkMsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUNuRCxPQUFPLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRTlDLElBQU0sV0FBVyxHQUFHLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3pDLFdBQVcsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDaEMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLGFBQWEsR0FBRyxPQUFPLENBQUM7UUFDakQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7SUFDekQsQ0FBQztJQUVELG1DQUFVLEdBQVY7UUFDQyx5QkFBeUI7UUFDekIsSUFBSSxjQUFjLEdBQUcsRUFBRSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsRUFBRSxDQUFBO1FBQ3BELGNBQWMsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBRTlCLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFBLHVDQUF1QztRQUN2RixJQUFJLEdBQUcsR0FBRyxJQUFJLEVBQUUsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQ3JDLEdBQUcsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ2xCLDZCQUE2QjtRQUM3QixHQUFHLENBQUMsZUFBZSxHQUFHLENBQUMsQ0FBQztRQUV4QixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRUQsNkNBQW9CLEdBQXBCO1FBQ0MsSUFBSSxTQUFTLEdBQUcsRUFBRSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUM7UUFDNUMsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUNoRCxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQzVDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUM7UUFDdEIsSUFBSSxHQUFHLEdBQUcsSUFBSSxFQUFFLENBQUMsWUFBWSxFQUFFLENBQUM7UUFFaEMsK0dBQStHO1FBQy9HLCtDQUErQztRQUMvQyxnQkFBZ0I7UUFDaEIsR0FBRyxDQUFDLFFBQVEsQ0FDWCxPQUFPLENBQUMsS0FBSyxHQUFHLENBQUMsR0FBRyxTQUFTLEVBQzdCLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxDQUFBO1FBRWhDLElBQUksZ0JBQWdCLEdBQUcsSUFBSSxFQUFFLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUNqRCxnQkFBZ0IsQ0FBQyxLQUFLLEdBQUcsR0FBRyxDQUFDO1FBQzdCLGdCQUFnQixDQUFDLEtBQUssR0FBRyxFQUFFLENBQUMsYUFBYSxDQUFDO1FBQzFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQzVCLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxHQUFHLFNBQVMsRUFDckMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLENBQUM7UUFFekMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFDNUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFFckQsSUFBSSxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQ3BELE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDekIsQ0FBQztJQUVFLHNDQUFhLEdBQWI7UUFDRixJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUUxQixtQ0FBbUM7UUFDbkMsMERBQTBEO1FBQzFELGdDQUFnQztRQUNoQyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUM7UUFDaEIsRUFBRSxDQUFDLFFBQVEsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxRQUFRLENBQUM7WUFDbkMsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7UUFDN0IsQ0FBQyxFQUFFLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDL0IsQ0FBQztJQUVFLDJDQUFrQixHQUFsQjtRQUNGLElBQUksSUFBSSxDQUFDLGNBQWMsSUFBSSxJQUFJLEVBQUU7WUFDaEMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUM1QyxJQUFJLENBQUMsVUFBVSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUUxRCxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQztTQUMzQjtJQUNDLENBQUM7SUE5Rko7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQzsrREFDa0I7SUFHdEM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzt5REFDWTtJQUc5QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDOzhEQUNpQjtJQUdyQztRQURDLFFBQVEsQ0FBQywyQkFBaUIsQ0FBQzs2REFDZ0I7SUFHNUM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzt1REFDVTtJQWRSLGNBQWM7UUFEbEMsT0FBTztPQUNhLGNBQWMsQ0FpR2xDO0lBQUQscUJBQUM7Q0FqR0QsQUFpR0MsQ0FqRzJDLEVBQUUsQ0FBQyxTQUFTLEdBaUd2RDtrQkFqR29CLGNBQWM7QUFtR25DLElBQUksc0JBQXNCLEdBQUcsSUFBSSxDQUFDO0FBQ2xDLElBQUksc0JBQXNCLEVBQUU7SUFDM0IsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsRUFBRTtRQUN6Qyw0RUFBNEU7UUFDNUUsWUFBWTtRQUNaLEVBQUUsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLHNCQUFzQixHQUFHLFVBQVUsUUFBUTtZQUN0RSxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUU7Z0JBQzdCLE1BQU0sSUFBSSxLQUFLLEVBQUUsQ0FBQzthQUNsQjtZQUNELElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxFQUFFO2dCQUNoQyxNQUFNLElBQUksS0FBSyxFQUFFLENBQUM7YUFDbEI7WUFFRCxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDO1lBQzFDLElBQUksZUFBZSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztZQUM3QyxJQUFJLGVBQWUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUM7WUFFN0Msc0RBQXNEO1lBQ3RELElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztZQUNuQixJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQztZQUN4QyxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7WUFDL0IsNENBQTRDO1lBQzVDLElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDO1lBQ3hDLFlBQVk7WUFDWixJQUFJLGtCQUFrQixHQUFHLEVBQUUsQ0FBQyxjQUFjLENBQUMsa0JBQWtCLENBQUM7WUFDOUQsZ0RBQWdEO1lBRWhELElBQUksS0FBSyxDQUFDO1lBQ1YsSUFBSSxJQUFJLEdBQUcsQ0FBQyxDQUFDO1lBQ2IsSUFBSSxNQUFNLEdBQUcsQ0FBQyxDQUFDO1lBQ2YsSUFBSSxRQUFRLEdBQUcsQ0FBQyxDQUFDO1lBQ2pCLElBQUksS0FBSyxDQUFDO1lBRVYsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQztZQUMxQyxJQUFJLGNBQWMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQztZQUM3QyxJQUFJLGVBQWUsQ0FBQztZQUNwQixJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUM7WUFDZixJQUFJLFNBQVMsQ0FBQztZQUNkLElBQUksU0FBUyxDQUFDO1lBRWQsSUFBSSxFQUFFLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQztZQUNuRCxJQUFJLGlCQUFpQixHQUFHLENBQUMsQ0FBQztZQUUxQixJQUFJLGFBQWEsR0FBRyxDQUFDLENBQUM7WUFDdEIsSUFBSSxjQUFjLEdBQUcsQ0FBQyxDQUFDO1lBRXZCLElBQUksS0FBSyxHQUFHLFFBQVEsQ0FBQztZQUVyQixLQUFLLElBQUksQ0FBQyxHQUFHLFVBQVUsRUFBRSxDQUFDLEdBQUcsVUFBVSxFQUFFLENBQUMsR0FBRyxRQUFRLEVBQUUsRUFBRSxDQUFDLEVBQUU7Z0JBQzNELEtBQUssR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3JCLElBQUksR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDO2dCQUNqQixNQUFNLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQztnQkFDckIsU0FBUyxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDN0IsZUFBZSxHQUFHLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFFekMsUUFBUSxHQUFHLGtCQUFrQixDQUFDLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQzFDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxFQUFFLEVBQUUsQ0FBQyxFQUFFO29CQUN0QyxLQUFLLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNyQixJQUFJLFFBQVEsR0FBRyxLQUFLLENBQUMsR0FBRyxFQUFFO3dCQUN6QixNQUFNO3FCQUNOO29CQUVELGlFQUFpRTtvQkFDakUsTUFBTSxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUM7b0JBQ3JCLGdDQUFnQztvQkFDaEMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFFN0Isc0RBQXNEO29CQUN0RCxrRUFBa0U7b0JBRWxFLEVBQUUsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDO29CQUNqQixFQUFFLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQztvQkFDakIsRUFBRSxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUM7b0JBQ2pCLEVBQUUsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDO29CQUVqQixFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztvQkFDYixFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztvQkFDYix3REFBd0Q7b0JBRXhELGlCQUFpQixHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztvQkFDdEMsK0NBQStDO29CQUMvQyxJQUFJLGlCQUFpQixHQUFHLGVBQWUsRUFBRTt3QkFDeEMsSUFBSSxJQUFJLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQzt3QkFDNUMsNENBQTRDO3dCQUM1QyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFOzRCQUNqQixJQUFJLEdBQUcsZUFBZSxDQUFDO3lCQUN2Qjt3QkFDRCxrREFBa0Q7d0JBQ2xELElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQzt3QkFDdkUsT0FBTyxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7d0JBQ3hCLE9BQU8sQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO3dCQUN4QixPQUFPLENBQUMsS0FBSyxHQUFHLGVBQWUsR0FBRyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUM7d0JBQ3pELE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLGlCQUFpQixHQUFHLElBQUksR0FBRyxlQUFlLENBQUM7d0JBQ2hFLCtCQUErQjt3QkFFL0IsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQzt3QkFDN0IsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQzt3QkFDN0IsMENBQTBDO3FCQUMxQztvQkFDRCxxRUFBcUU7aUJBQ3JFO2dCQUNELGFBQWEsR0FBRyxrQkFBa0IsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hELE9BQU8sQ0FBQyxHQUFHLFFBQVEsRUFBRSxFQUFFLENBQUMsRUFBRTtvQkFDekIsSUFBSSxhQUFhLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRTt3QkFDdEMsTUFBTTtxQkFDTjtpQkFDRDtnQkFDRCxjQUFjLEdBQUcsa0JBQWtCLENBQUMsSUFBSSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDaEQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsRUFBRSxFQUFFLENBQUMsRUFBRTtvQkFDbEMsS0FBSyxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDckIsSUFBSSxjQUFjLEdBQUcsS0FBSyxDQUFDLEdBQUcsRUFBRTt3QkFDL0IsTUFBTTtxQkFDTjtvQkFFRCxpRUFBaUU7b0JBQ2pFLE1BQU0sR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDO29CQUNyQixnQ0FBZ0M7b0JBQ2hDLFNBQVMsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQzdCLHNEQUFzRDtvQkFDdEQsa0VBQWtFO29CQUVsRSxFQUFFLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQztvQkFDakIsRUFBRSxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUM7b0JBQ2pCLEVBQUUsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDO29CQUNqQixFQUFFLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQztvQkFFakIsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7b0JBQ2IsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7b0JBQ2Isd0RBQXdEO29CQUV4RCxpQkFBaUIsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7b0JBQ3RDLCtDQUErQztvQkFDL0MsSUFBSSxpQkFBaUIsR0FBRyxlQUFlLEVBQUU7d0JBQ3hDLElBQUksSUFBSSxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7d0JBQzVDLDRDQUE0Qzt3QkFDNUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRTs0QkFDakIsSUFBSSxHQUFHLGVBQWUsQ0FBQzt5QkFDdkI7d0JBQ0Qsa0RBQWtEO3dCQUNsRCxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7d0JBQ3ZFLE9BQU8sQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO3dCQUN4QixPQUFPLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQzt3QkFDeEIsT0FBTyxDQUFDLEtBQUssR0FBRyxlQUFlLEdBQUcsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDO3dCQUN6RCxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsR0FBRyxpQkFBaUIsR0FBRyxJQUFJLEdBQUcsZUFBZSxDQUFDO3dCQUNoRSwrQkFBK0I7d0JBRS9CLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7d0JBQzdCLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7d0JBQzdCLDBDQUEwQztxQkFDMUM7b0JBQ0QscUVBQXFFO2lCQUNyRTthQUNEO1FBQ0YsQ0FBQyxDQUFDO0lBQ0gsQ0FBQyxDQUFDLENBQUM7Q0FDSCIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIENvcHlyaWdodCAyMDIwIENhbyBHYW90aW5nPGNhb2d0YWFAZ21haWwuY29tPlxyXG4vLyBodHRwczovL2Nhb2d0YWEuZ2l0aHViLmlvXHJcbi8vIFRoaXMgZmlsZSBpcyBsaWNlbnNlZCB1bmRlciB0aGUgTUlUIExpY2Vuc2UuXHJcbi8vIExpY2Vuc2UgdGV4dCBhdmFpbGFibGUgYXQgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVRcclxuXHJcbi8qXHJcbiAqIERhdGU6IDIwMjAtMDctMTMgMDI6NDQ6MTZcclxuICogTGFzdEVkaXRvcnM6IEdUPGNhb2d0YWFAZ21haWwuY29tPlxyXG4gKiBMYXN0RWRpdFRpbWU6IDIwMjAtMDctMjIgMTQ6MDE6NTdcclxuKi8gXHJcblxyXG5cclxuaW1wb3J0IE1ldGFCYWxsc1JlbmRlcmVyIGZyb20gXCIuLi8uLi9TaGFkZXIvTWV0YUJhbGxzL01ldGFCYWxsc1JlbmRlcmVyXCI7XHJcblxyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgU2NlbmVNZXRhQmFsbHMgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG5cdEBwcm9wZXJ0eShjYy5DYW1lcmEpXHJcblx0d2F0ZXJSZW5kZXJlckNhbWVyYTogY2MuQ2FtZXJhID0gbnVsbDtcclxuXHJcblx0QHByb3BlcnR5KGNjLk5vZGUpXHJcblx0d2F0ZXJSZW5kZXJlcjogY2MuTm9kZSA9IG51bGw7XHJcblxyXG5cdEBwcm9wZXJ0eShjYy5TcHJpdGUpXHJcblx0d2F0ZXJSZW5kZXJlclBhc3MyOiBjYy5TcHJpdGUgPSBudWxsO1xyXG5cclxuXHRAcHJvcGVydHkoTWV0YUJhbGxzUmVuZGVyZXIpXHJcblx0bWV0YUJhbGxzUmVuZGVyZXI6IE1ldGFCYWxsc1JlbmRlcmVyID0gbnVsbDtcclxuXHJcblx0QHByb3BlcnR5KGNjLk5vZGUpXHJcblx0cGFydGljbGVCb3g6IGNjLk5vZGUgPSBudWxsO1xyXG5cclxuXHRwcm90ZWN0ZWQgX3dvcmxkID0gbnVsbDtcclxuXHRwcm90ZWN0ZWQgX3BhcnRpY2xlcyA9IG51bGw7XHJcblx0cHJvdGVjdGVkIF9wYXJ0aWNsZUdyb3VwID0gbnVsbDtcclxuXHJcblx0b25Mb2FkKCkge1xyXG5cdFx0aWYgKCFDQ19FRElUT1IpIHtcclxuXHRcdFx0dGhpcy5TZXR1cFdvcmxkKCk7XHJcblx0XHR9XHJcblxyXG5cdFx0Y29uc3QgdGV4dHVyZSA9IG5ldyBjYy5SZW5kZXJUZXh0dXJlKCk7XHJcblx0XHRsZXQgc2l6ZSA9IHRoaXMud2F0ZXJSZW5kZXJlclBhc3MyLm5vZGUuZ2V0Q29udGVudFNpemUoKTtcclxuICAgICAgICB0ZXh0dXJlLmluaXRXaXRoU2l6ZShzaXplLndpZHRoLCBzaXplLmhlaWdodCk7XHJcblx0XHRcclxuICAgICAgICBjb25zdCBzcHJpdGVGcmFtZSA9IG5ldyBjYy5TcHJpdGVGcmFtZSgpO1xyXG4gICAgICAgIHNwcml0ZUZyYW1lLnNldFRleHR1cmUodGV4dHVyZSk7XHJcbiAgICAgICAgdGhpcy53YXRlclJlbmRlcmVyQ2FtZXJhLnRhcmdldFRleHR1cmUgPSB0ZXh0dXJlO1xyXG4gICAgICAgIHRoaXMud2F0ZXJSZW5kZXJlclBhc3MyLnNwcml0ZUZyYW1lID0gc3ByaXRlRnJhbWU7XHJcblx0fVxyXG5cclxuXHRTZXR1cFdvcmxkKCkge1xyXG5cdFx0Ly8gZW5hYmxlIHBoeXNpY3MgbWFuYWdlclxyXG5cdFx0bGV0IHBoeXNpY3NNYW5hZ2VyID0gY2MuZGlyZWN0b3IuZ2V0UGh5c2ljc01hbmFnZXIoKVxyXG5cdFx0cGh5c2ljc01hbmFnZXIuZW5hYmxlZCA9IHRydWU7XHJcblxyXG5cdFx0bGV0IHdvcmxkID0gdGhpcy5fd29ybGQgPSBwaHlzaWNzTWFuYWdlci5fd29ybGQ7Ly8gbmV3IGIyLldvcmxkKG5ldyBiMi5WZWMyKDAsIC0xNS4wKSk7XHJcblx0XHR2YXIgcHNkID0gbmV3IGIyLlBhcnRpY2xlU3lzdGVtRGVmKCk7XHJcblx0XHRwc2QucmFkaXVzID0gMC4zNTtcclxuXHRcdC8vIHBzZC5kYW1waW5nU3RyZW5ndGggPSAxLjU7XHJcblx0XHRwc2QudmlzY291c1N0cmVuZ3RoID0gMDtcclxuXHJcblx0XHR0aGlzLl9wYXJ0aWNsZXMgPSB3b3JsZC5DcmVhdGVQYXJ0aWNsZVN5c3RlbShwc2QpO1xyXG5cdH1cclxuXHJcblx0Q3JlYXRlUGFydGljbGVzR3JvdXAoKSB7XHJcblx0XHRsZXQgUFRNX1JBVElPID0gY2MuUGh5c2ljc01hbmFnZXIuUFRNX1JBVElPO1xyXG5cdFx0dmFyIGJveFNpemUgPSB0aGlzLnBhcnRpY2xlQm94LmdldENvbnRlbnRTaXplKCk7XHJcblx0XHR2YXIgYm94UG9zID0gdGhpcy5wYXJ0aWNsZUJveC5nZXRQb3NpdGlvbigpO1xyXG5cdFx0dmFyIHNpemUgPSBjYy53aW5TaXplO1xyXG5cdFx0dmFyIGJveCA9IG5ldyBiMi5Qb2x5Z29uU2hhcGUoKTtcclxuXHJcblx0XHQvLyBodHRwczovL2dvb2dsZS5naXRodWIuaW8vbGlxdWlkZnVuL0FQSS1SZWYvaHRtbC9jbGFzc2IyX3BvbHlnb25fc2hhcGUuaHRtbCNhODkwNjkwMjUwMTE1NDgzZGE2YzdkNjk4MjliZTA4N2VcclxuXHRcdC8vIEJ1aWxkIHZlcnRpY2VzIHRvIHJlcHJlc2VudCBhbiBvcmllbnRlZCBib3guXHJcblx0XHQvLyBib3jnmoTlpKflsI/lvbHlk43nspLlrZDnmoTmlbDph49cclxuXHRcdGJveC5TZXRBc0JveChcclxuXHRcdFx0Ym94U2l6ZS53aWR0aCAvIDIgLyBQVE1fUkFUSU8sXHJcblx0XHRcdGJveFNpemUuaGVpZ2h0IC8gMiAvIFBUTV9SQVRJTylcclxuXHJcblx0XHR2YXIgcGFydGljbGVHcm91cERlZiA9IG5ldyBiMi5QYXJ0aWNsZUdyb3VwRGVmKCk7XHJcblx0XHRwYXJ0aWNsZUdyb3VwRGVmLnNoYXBlID0gYm94O1xyXG5cdFx0cGFydGljbGVHcm91cERlZi5mbGFncyA9IGIyLndhdGVyUGFydGljbGU7XHJcblx0XHRwYXJ0aWNsZUdyb3VwRGVmLnBvc2l0aW9uLlNldChcclxuXHRcdFx0KGJveFBvcy54ICsgc2l6ZS53aWR0aC8yKSAvIFBUTV9SQVRJTyxcclxuXHRcdFx0KGJveFBvcy55ICsgc2l6ZS5oZWlnaHQvMikgLyBQVE1fUkFUSU8pO1xyXG5cclxuXHRcdHRoaXMuX3BhcnRpY2xlR3JvdXAgPSB0aGlzLl9wYXJ0aWNsZXMuQ3JlYXRlUGFydGljbGVHcm91cChwYXJ0aWNsZUdyb3VwRGVmKTtcclxuXHRcdHRoaXMubWV0YUJhbGxzUmVuZGVyZXIuU2V0UGFydGljbGVzKHRoaXMuX3BhcnRpY2xlcyk7XHJcblxyXG5cdFx0bGV0IHZlcnRzQ291bnQgPSB0aGlzLl9wYXJ0aWNsZXMuR2V0UGFydGljbGVDb3VudCgpO1xyXG5cdFx0Y29uc29sZS5sb2codmVydHNDb3VudCk7XHJcblx0fVxyXG5cclxuICAgIEdlbmVyYXRlV2F0ZXIoKSB7XHJcblx0XHR0aGlzLlJlc2V0UGFydGljbGVHcm91cCgpO1xyXG5cclxuXHRcdC8vIHJlLWNyZWF0ZSBwYXJ0aWNsZXMgaW4gbmV4dCB0aWNrXHJcblx0XHQvLyBvdGhlcndpc2Ugb2xkIHBhcnRpY2xlIHN5c3RlbSBpcyBub3QgY29ycmVjdGx5IHJlbGVhc2VkXHJcblx0XHQvLyB0aGlzIGlzIGEgbm9uLXJlcGVhdCBzY2hlZHVsZVxyXG5cdFx0bGV0IHRoYXQgPSB0aGlzO1xyXG5cdFx0Y2MuZGlyZWN0b3IuZ2V0U2NoZWR1bGVyKCkuc2NoZWR1bGUoKCkgPT4ge1xyXG5cdFx0XHR0aGF0LkNyZWF0ZVBhcnRpY2xlc0dyb3VwKCk7XHJcblx0XHR9LCB0aGlzLm5vZGUsIDAsIDAsIDAsIGZhbHNlKTtcclxuXHR9XHJcblxyXG4gICAgUmVzZXRQYXJ0aWNsZUdyb3VwKCkge1xyXG5cdFx0aWYgKHRoaXMuX3BhcnRpY2xlR3JvdXAgIT0gbnVsbCkge1xyXG5cdFx0XHR0aGlzLl9wYXJ0aWNsZUdyb3VwLkRlc3Ryb3lQYXJ0aWNsZXMoZmFsc2UpO1xyXG5cdFx0XHR0aGlzLl9wYXJ0aWNsZXMuRGVzdHJveVBhcnRpY2xlR3JvdXAodGhpcy5fcGFydGljbGVHcm91cCk7XHJcblxyXG5cdFx0XHR0aGlzLl9wYXJ0aWNsZUdyb3VwID0gbnVsbDtcclxuXHRcdH1cclxuICAgIH1cclxufVxyXG5cclxudmFyIGVuYWJsZUxvd0xldmVsT3B0aW1pemUgPSB0cnVlO1xyXG5pZiAoZW5hYmxlTG93TGV2ZWxPcHRpbWl6ZSkge1xyXG5cdGNjLmdhbWUub25jZShjYy5nYW1lLkVWRU5UX0VOR0lORV9JTklURUQsICgpID0+IHtcclxuXHRcdC8vIGIyUGFydGljbGVTeXN0ZW0ucHJvdG90eXBlLkZpbmRDb250YWN0c19SZWZlcmVuY2UgPSBmdW5jdGlvbiAoY29udGFjdHMpIHtcclxuXHRcdC8vQHRzLWlnbm9yZVxyXG5cdFx0YjIuUGFydGljbGVTeXN0ZW0ucHJvdG90eXBlLkZpbmRDb250YWN0c19SZWZlcmVuY2UgPSBmdW5jdGlvbiAoY29udGFjdHMpIHtcclxuXHRcdFx0aWYgKCF0aGlzLm1fZmxhZ3NCdWZmZXIuZGF0YSkge1xyXG5cdFx0XHRcdHRocm93IG5ldyBFcnJvcigpO1xyXG5cdFx0XHR9XHJcblx0XHRcdGlmICghdGhpcy5tX3Bvc2l0aW9uQnVmZmVyLmRhdGEpIHtcclxuXHRcdFx0XHR0aHJvdyBuZXcgRXJyb3IoKTtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0dmFyIHBvc19kYXRhID0gdGhpcy5tX3Bvc2l0aW9uQnVmZmVyLmRhdGE7XHJcblx0XHRcdHZhciBzcXVhcmVkRGlhbWV0ZXIgPSB0aGlzLm1fc3F1YXJlZERpYW1ldGVyO1xyXG5cdFx0XHR2YXIgaW52ZXJzZURpYW1ldGVyID0gdGhpcy5tX2ludmVyc2VEaWFtZXRlcjtcclxuXHJcblx0XHRcdC8vIERFQlVHOiBiMkFzc2VydChjb250YWN0cyA9PT0gdGhpcy5tX2NvbnRhY3RCdWZmZXIpO1xyXG5cdFx0XHR2YXIgYmVnaW5Qcm94eSA9IDA7XHJcblx0XHRcdHZhciBlbmRQcm94eSA9IHRoaXMubV9wcm94eUJ1ZmZlci5jb3VudDtcclxuXHRcdFx0dGhpcy5tX2NvbnRhY3RCdWZmZXIuY291bnQgPSAwO1xyXG5cdFx0XHQvLyBsZXQgY29udGFjdEJ1ZmZlciA9IHRoaXMubV9jb250YWN0QnVmZmVyO1xyXG5cdFx0XHR2YXIgcHJveHlEYXRhID0gdGhpcy5tX3Byb3h5QnVmZmVyLmRhdGE7XHJcblx0XHRcdC8vQHRzLWlnbm9yZVxyXG5cdFx0XHR2YXIgY29tcHV0ZVJlbGF0aXZlVGFnID0gYjIuUGFydGljbGVTeXN0ZW0uY29tcHV0ZVJlbGF0aXZlVGFnO1xyXG5cdFx0XHQvLyB2YXIgQWRkQ29udGFjdCA9IHRoaXMuQWRkQ29udGFjdDIuYmluZCh0aGlzKTtcclxuXHJcblx0XHRcdHZhciBkYXRhQTtcclxuXHRcdFx0dmFyIHRhZ0EgPSAwO1xyXG5cdFx0XHR2YXIgaW5kZXhBID0gMDtcclxuXHRcdFx0dmFyIHJpZ2h0VGFnID0gMDtcclxuXHRcdFx0dmFyIGRhdGFCO1xyXG5cclxuXHRcdFx0dmFyIHBvc19kYXRhID0gdGhpcy5tX3Bvc2l0aW9uQnVmZmVyLmRhdGE7XHJcblx0XHRcdHZhciBmbGFnQnVmZmVyRGF0YSA9IHRoaXMubV9mbGFnc0J1ZmZlci5kYXRhO1xyXG5cdFx0XHR2YXIgZmxhZ0J1ZmZlckRhdGFBO1xyXG5cdFx0XHR2YXIgaW5kZXhCID0gMDtcclxuXHRcdFx0dmFyIHBvc19kYXRhQTtcclxuXHRcdFx0dmFyIHBvc19kYXRhQjtcclxuXHJcblx0XHRcdHZhciBheCA9IDAsIGF5ID0gMCwgYnggPSAwLCBieSA9IDAsIGR4ID0gMCwgZHkgPSAwO1xyXG5cdFx0XHR2YXIgZGlzdEJ0UGFydGljbGVzU3EgPSAwO1xyXG5cclxuXHRcdFx0dmFyIGJvdHRvbUxlZnRUYWcgPSAwO1xyXG5cdFx0XHR2YXIgYm90dG9tUmlnaHRUYWcgPSAwO1xyXG5cclxuXHRcdFx0dmFyIGlzRmluID0gaXNGaW5pdGU7XHJcblxyXG5cdFx0XHRmb3IgKHZhciBhID0gYmVnaW5Qcm94eSwgYyA9IGJlZ2luUHJveHk7IGEgPCBlbmRQcm94eTsgKythKSB7XHJcblx0XHRcdFx0ZGF0YUEgPSBwcm94eURhdGFbYV07XHJcblx0XHRcdFx0dGFnQSA9IGRhdGFBLnRhZztcclxuXHRcdFx0XHRpbmRleEEgPSBkYXRhQS5pbmRleDtcclxuXHRcdFx0XHRwb3NfZGF0YUEgPSBwb3NfZGF0YVtpbmRleEFdO1xyXG5cdFx0XHRcdGZsYWdCdWZmZXJEYXRhQSA9IGZsYWdCdWZmZXJEYXRhW2luZGV4QV07XHJcblxyXG5cdFx0XHRcdHJpZ2h0VGFnID0gY29tcHV0ZVJlbGF0aXZlVGFnKHRhZ0EsIDEsIDApO1xyXG5cdFx0XHRcdGZvciAodmFyIGIgPSBhICsgMTsgYiA8IGVuZFByb3h5OyArK2IpIHtcclxuXHRcdFx0XHRcdGRhdGFCID0gcHJveHlEYXRhW2JdO1xyXG5cdFx0XHRcdFx0aWYgKHJpZ2h0VGFnIDwgZGF0YUIudGFnKSB7XHJcblx0XHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHJcblx0XHRcdFx0XHQvLyAtLS0tLS0tIEFkZENvbnRhY3QoaW5kZXhBLCBwcm94eURhdGFbYl0uaW5kZXgsIGNvbnRhY3RCdWZmZXIpO1xyXG5cdFx0XHRcdFx0aW5kZXhCID0gZGF0YUIuaW5kZXg7XHJcblx0XHRcdFx0XHQvLyBwb3NfZGF0YUEgPSBwb3NfZGF0YVtpbmRleEFdO1xyXG5cdFx0XHRcdFx0cG9zX2RhdGFCID0gcG9zX2RhdGFbaW5kZXhCXTtcclxuXHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0Ly8gREVCVUc6IGIyQXNzZXJ0KGNvbnRhY3RzID09PSB0aGlzLm1fY29udGFjdEJ1ZmZlcik7XHJcblx0XHRcdFx0XHQvLy9iMlZlYzIgZCA9IG1fcG9zaXRpb25CdWZmZXIuZGF0YVtiXSAtIG1fcG9zaXRpb25CdWZmZXIuZGF0YVthXTtcclxuXHJcblx0XHRcdFx0XHRieCA9IHBvc19kYXRhQi54O1xyXG5cdFx0XHRcdFx0YnkgPSBwb3NfZGF0YUIueTtcclxuXHRcdFx0XHRcdGF4ID0gcG9zX2RhdGFBLng7XHJcblx0XHRcdFx0XHRheSA9IHBvc19kYXRhQS55O1xyXG5cclxuXHRcdFx0XHRcdGR4ID0gYnggLSBheDtcclxuXHRcdFx0XHRcdGR5ID0gYnkgLSBheTtcclxuXHRcdFx0XHRcdC8vIHZhciBkID0gYjIuVmVjMi5TdWJWVihwb3NfZGF0YVtiXSwgcG9zX2RhdGFbYV0sIHNfZCk7XHJcblxyXG5cdFx0XHRcdFx0ZGlzdEJ0UGFydGljbGVzU3EgPSBkeCAqIGR4ICsgZHkgKiBkeTtcclxuXHRcdFx0XHRcdC8vIHZhciBkaXN0QnRQYXJ0aWNsZXNTcSA9IGIyLlZlYzIuRG90VlYoZCwgZCk7XHJcblx0XHRcdFx0XHRpZiAoZGlzdEJ0UGFydGljbGVzU3EgPCBzcXVhcmVkRGlhbWV0ZXIpIHtcclxuXHRcdFx0XHRcdFx0dmFyIGludkQgPSAxIC8gTWF0aC5zcXJ0KGRpc3RCdFBhcnRpY2xlc1NxKTtcclxuXHRcdFx0XHRcdFx0Ly8gdmFyIGludkQgPSBiMi5JbnZTcXJ0KGRpc3RCdFBhcnRpY2xlc1NxKTtcclxuXHRcdFx0XHRcdFx0aWYgKCFpc0ZpbihpbnZEKSkge1xyXG5cdFx0XHRcdFx0XHRcdGludkQgPSAxLjk4MTc3NTM3ZSswMTk7XHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0Ly8vYjJQYXJ0aWNsZUNvbnRhY3QmIGNvbnRhY3QgPSBjb250YWN0cy5BcHBlbmQoKTtcclxuXHRcdFx0XHRcdFx0dmFyIGNvbnRhY3QgPSB0aGlzLm1fY29udGFjdEJ1ZmZlci5kYXRhW3RoaXMubV9jb250YWN0QnVmZmVyLkFwcGVuZCgpXTtcclxuXHRcdFx0XHRcdFx0Y29udGFjdC5pbmRleEEgPSBpbmRleEE7XHJcblx0XHRcdFx0XHRcdGNvbnRhY3QuaW5kZXhCID0gaW5kZXhCO1xyXG5cdFx0XHRcdFx0XHRjb250YWN0LmZsYWdzID0gZmxhZ0J1ZmZlckRhdGFBIHwgZmxhZ0J1ZmZlckRhdGFbaW5kZXhCXTtcclxuXHRcdFx0XHRcdFx0Y29udGFjdC53ZWlnaHQgPSAxIC0gZGlzdEJ0UGFydGljbGVzU3EgKiBpbnZEICogaW52ZXJzZURpYW1ldGVyO1xyXG5cdFx0XHRcdFx0XHQvLy9jb250YWN0LlNldE5vcm1hbChpbnZEICogZCk7XHJcblxyXG5cdFx0XHRcdFx0XHRjb250YWN0Lm5vcm1hbC54ID0gaW52RCAqIGR4O1xyXG5cdFx0XHRcdFx0XHRjb250YWN0Lm5vcm1hbC55ID0gaW52RCAqIGR5O1xyXG5cdFx0XHRcdFx0XHQvLyBiMi5WZWMyLk11bFNWKGludkQsIGQsIGNvbnRhY3Qubm9ybWFsKTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdC8vIGVuZCAtLS0tLS0tIEFkZENvbnRhY3QoaW5kZXhBLCBwcm94eURhdGFbYl0uaW5kZXgsIGNvbnRhY3RCdWZmZXIpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRib3R0b21MZWZ0VGFnID0gY29tcHV0ZVJlbGF0aXZlVGFnKHRhZ0EsIC0xLCAxKTtcclxuXHRcdFx0XHRmb3IgKDsgYyA8IGVuZFByb3h5OyArK2MpIHtcclxuXHRcdFx0XHRcdGlmIChib3R0b21MZWZ0VGFnIDw9IHByb3h5RGF0YVtjXS50YWcpIHtcclxuXHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdGJvdHRvbVJpZ2h0VGFnID0gY29tcHV0ZVJlbGF0aXZlVGFnKHRhZ0EsIDEsIDEpO1xyXG5cdFx0XHRcdGZvciAodmFyIGIgPSBjOyBiIDwgZW5kUHJveHk7ICsrYikge1xyXG5cdFx0XHRcdFx0ZGF0YUIgPSBwcm94eURhdGFbYl07XHJcblx0XHRcdFx0XHRpZiAoYm90dG9tUmlnaHRUYWcgPCBkYXRhQi50YWcpIHtcclxuXHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdC8vIC0tLS0tLS0gQWRkQ29udGFjdChpbmRleEEsIHByb3h5RGF0YVtiXS5pbmRleCwgY29udGFjdEJ1ZmZlcik7XHJcblx0XHRcdFx0XHRpbmRleEIgPSBkYXRhQi5pbmRleDtcclxuXHRcdFx0XHRcdC8vIHBvc19kYXRhQSA9IHBvc19kYXRhW2luZGV4QV07XHJcblx0XHRcdFx0XHRwb3NfZGF0YUIgPSBwb3NfZGF0YVtpbmRleEJdO1xyXG5cdFx0XHRcdFx0Ly8gREVCVUc6IGIyQXNzZXJ0KGNvbnRhY3RzID09PSB0aGlzLm1fY29udGFjdEJ1ZmZlcik7XHJcblx0XHRcdFx0XHQvLy9iMlZlYzIgZCA9IG1fcG9zaXRpb25CdWZmZXIuZGF0YVtiXSAtIG1fcG9zaXRpb25CdWZmZXIuZGF0YVthXTtcclxuXHJcblx0XHRcdFx0XHRieCA9IHBvc19kYXRhQi54O1xyXG5cdFx0XHRcdFx0YnkgPSBwb3NfZGF0YUIueTtcclxuXHRcdFx0XHRcdGF4ID0gcG9zX2RhdGFBLng7XHJcblx0XHRcdFx0XHRheSA9IHBvc19kYXRhQS55O1xyXG5cclxuXHRcdFx0XHRcdGR4ID0gYnggLSBheDtcclxuXHRcdFx0XHRcdGR5ID0gYnkgLSBheTtcclxuXHRcdFx0XHRcdC8vIHZhciBkID0gYjIuVmVjMi5TdWJWVihwb3NfZGF0YVtiXSwgcG9zX2RhdGFbYV0sIHNfZCk7XHJcblxyXG5cdFx0XHRcdFx0ZGlzdEJ0UGFydGljbGVzU3EgPSBkeCAqIGR4ICsgZHkgKiBkeTtcclxuXHRcdFx0XHRcdC8vIHZhciBkaXN0QnRQYXJ0aWNsZXNTcSA9IGIyLlZlYzIuRG90VlYoZCwgZCk7XHJcblx0XHRcdFx0XHRpZiAoZGlzdEJ0UGFydGljbGVzU3EgPCBzcXVhcmVkRGlhbWV0ZXIpIHtcclxuXHRcdFx0XHRcdFx0dmFyIGludkQgPSAxIC8gTWF0aC5zcXJ0KGRpc3RCdFBhcnRpY2xlc1NxKTtcclxuXHRcdFx0XHRcdFx0Ly8gdmFyIGludkQgPSBiMi5JbnZTcXJ0KGRpc3RCdFBhcnRpY2xlc1NxKTtcclxuXHRcdFx0XHRcdFx0aWYgKCFpc0ZpbihpbnZEKSkge1xyXG5cdFx0XHRcdFx0XHRcdGludkQgPSAxLjk4MTc3NTM3ZSswMTk7XHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0Ly8vYjJQYXJ0aWNsZUNvbnRhY3QmIGNvbnRhY3QgPSBjb250YWN0cy5BcHBlbmQoKTtcclxuXHRcdFx0XHRcdFx0dmFyIGNvbnRhY3QgPSB0aGlzLm1fY29udGFjdEJ1ZmZlci5kYXRhW3RoaXMubV9jb250YWN0QnVmZmVyLkFwcGVuZCgpXTtcclxuXHRcdFx0XHRcdFx0Y29udGFjdC5pbmRleEEgPSBpbmRleEE7XHJcblx0XHRcdFx0XHRcdGNvbnRhY3QuaW5kZXhCID0gaW5kZXhCO1xyXG5cdFx0XHRcdFx0XHRjb250YWN0LmZsYWdzID0gZmxhZ0J1ZmZlckRhdGFBIHwgZmxhZ0J1ZmZlckRhdGFbaW5kZXhCXTtcclxuXHRcdFx0XHRcdFx0Y29udGFjdC53ZWlnaHQgPSAxIC0gZGlzdEJ0UGFydGljbGVzU3EgKiBpbnZEICogaW52ZXJzZURpYW1ldGVyO1xyXG5cdFx0XHRcdFx0XHQvLy9jb250YWN0LlNldE5vcm1hbChpbnZEICogZCk7XHJcblxyXG5cdFx0XHRcdFx0XHRjb250YWN0Lm5vcm1hbC54ID0gaW52RCAqIGR4O1xyXG5cdFx0XHRcdFx0XHRjb250YWN0Lm5vcm1hbC55ID0gaW52RCAqIGR5O1xyXG5cdFx0XHRcdFx0XHQvLyBiMi5WZWMyLk11bFNWKGludkQsIGQsIGNvbnRhY3Qubm9ybWFsKTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdC8vIGVuZCAtLS0tLS0tIEFkZENvbnRhY3QoaW5kZXhBLCBwcm94eURhdGFbYl0uaW5kZXgsIGNvbnRhY3RCdWZmZXIpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0fTtcclxuXHR9KTtcclxufVxyXG4iXX0=