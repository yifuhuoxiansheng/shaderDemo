
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/Scene/SceneSpriteMaskedAvatars.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e358arsN59DbZ0N3kUBhrCb', 'SceneSpriteMaskedAvatars');
// Scripts/Scene/SceneSpriteMaskedAvatars.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-22 02:50:07
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:02:05
*/
var SpriteMaskedAvatarSprite_1 = require("../../Shader/SpriteMaskedAvatar/SpriteMaskedAvatarSprite");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SceneSpriteMaskedAvatars = /** @class */ (function (_super) {
    __extends(SceneSpriteMaskedAvatars, _super);
    function SceneSpriteMaskedAvatars() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.board = null;
        _this._enableMask = true;
        return _this;
    }
    SceneSpriteMaskedAvatars.prototype.onLoad = function () {
    };
    SceneSpriteMaskedAvatars.prototype.onToggleMask = function () {
        var enable = this._enableMask = !this._enableMask;
        for (var _i = 0, _a = this.board.children; _i < _a.length; _i++) {
            var c = _a[_i];
            var comp = c.getComponent(SpriteMaskedAvatarSprite_1.default);
            comp.enableMask = enable;
        }
    };
    __decorate([
        property(cc.Node)
    ], SceneSpriteMaskedAvatars.prototype, "board", void 0);
    SceneSpriteMaskedAvatars = __decorate([
        ccclass
    ], SceneSpriteMaskedAvatars);
    return SceneSpriteMaskedAvatars;
}(cc.Component));
exports.default = SceneSpriteMaskedAvatars;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHRzL1NjZW5lL1NjZW5lU3ByaXRlTWFza2VkQXZhdGFycy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsZ0RBQWdEO0FBQ2hELDRCQUE0QjtBQUM1QiwrQ0FBK0M7QUFDL0MsZ0VBQWdFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFaEU7Ozs7RUFJRTtBQUVGLHFHQUFnRztBQUUxRixJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUc1QztJQUFzRCw0Q0FBWTtJQUFsRTtRQUFBLHFFQWtCQztRQWhCRyxXQUFLLEdBQVksSUFBSSxDQUFDO1FBRVosaUJBQVcsR0FBWSxJQUFJLENBQUM7O0lBYzFDLENBQUM7SUFaRyx5Q0FBTSxHQUFOO0lBRUEsQ0FBQztJQUVELCtDQUFZLEdBQVo7UUFDSSxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQztRQUVsRCxLQUFjLFVBQW1CLEVBQW5CLEtBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQW5CLGNBQW1CLEVBQW5CLElBQW1CLEVBQUU7WUFBOUIsSUFBSSxDQUFDLFNBQUE7WUFDTixJQUFJLElBQUksR0FBRyxDQUFDLENBQUMsWUFBWSxDQUFDLGtDQUF3QixDQUFDLENBQUM7WUFDcEQsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUM7U0FDNUI7SUFDTCxDQUFDO0lBZkQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzsyREFDSTtJQUZMLHdCQUF3QjtRQUQ1QyxPQUFPO09BQ2Esd0JBQXdCLENBa0I1QztJQUFELCtCQUFDO0NBbEJELEFBa0JDLENBbEJxRCxFQUFFLENBQUMsU0FBUyxHQWtCakU7a0JBbEJvQix3QkFBd0IiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDb3B5cmlnaHQgMjAyMCBDYW8gR2FvdGluZzxjYW9ndGFhQGdtYWlsLmNvbT5cbi8vIGh0dHBzOi8vY2FvZ3RhYS5naXRodWIuaW9cbi8vIFRoaXMgZmlsZSBpcyBsaWNlbnNlZCB1bmRlciB0aGUgTUlUIExpY2Vuc2UuXG4vLyBMaWNlbnNlIHRleHQgYXZhaWxhYmxlIGF0IGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlUXG5cbi8qXG4gKiBEYXRlOiAyMDIwLTA3LTIyIDAyOjUwOjA3XG4gKiBMYXN0RWRpdG9yczogR1Q8Y2FvZ3RhYUBnbWFpbC5jb20+XG4gKiBMYXN0RWRpdFRpbWU6IDIwMjAtMDctMjIgMTQ6MDI6MDVcbiovIFxuXG5pbXBvcnQgU3ByaXRlTWFza2VkQXZhdGFyU3ByaXRlIGZyb20gXCIuLi8uLi9TaGFkZXIvU3ByaXRlTWFza2VkQXZhdGFyL1Nwcml0ZU1hc2tlZEF2YXRhclNwcml0ZVwiO1xuXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xuXG5AY2NjbGFzc1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgU2NlbmVTcHJpdGVNYXNrZWRBdmF0YXJzIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcbiAgICBib2FyZDogY2MuTm9kZSA9IG51bGw7XG5cbiAgICBwcm90ZWN0ZWQgX2VuYWJsZU1hc2s6IGJvb2xlYW4gPSB0cnVlO1xuXG4gICAgb25Mb2FkKCkge1xuXG4gICAgfVxuXG4gICAgb25Ub2dnbGVNYXNrKCkge1xuICAgICAgICBsZXQgZW5hYmxlID0gdGhpcy5fZW5hYmxlTWFzayA9ICF0aGlzLl9lbmFibGVNYXNrO1xuXG4gICAgICAgIGZvciAobGV0IGMgb2YgdGhpcy5ib2FyZC5jaGlsZHJlbikge1xuICAgICAgICAgICAgbGV0IGNvbXAgPSBjLmdldENvbXBvbmVudChTcHJpdGVNYXNrZWRBdmF0YXJTcHJpdGUpO1xuICAgICAgICAgICAgY29tcC5lbmFibGVNYXNrID0gZW5hYmxlO1xuICAgICAgICB9XG4gICAgfVxufVxuIl19