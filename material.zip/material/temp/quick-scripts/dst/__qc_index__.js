
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/Scripts/Helloworld');
require('./assets/Scripts/Misc/NavigatorButton');
require('./assets/Scripts/Misc/SimpleDraggable');
require('./assets/Scripts/Scene/SceneLayeredBatchingScrollView');
require('./assets/Scripts/Scene/SceneMetaBalls');
require('./assets/Scripts/Scene/SceneSpriteMaskedAvatars');
require('./assets/Scripts/Scene/SceneTest');
require('./assets/Scripts/Scene/SceneTestGraphics');
require('./assets/Scripts/Scene/SceneWelcome');
require('./assets/Shader/Avatar/AvatarAssembler');
require('./assets/Shader/Avatar/AvatarSprite');
require('./assets/Shader/EqualScallingSprite/EqualScalingAssembler');
require('./assets/Shader/EqualScallingSprite/EqualScalingSprite');
require('./assets/Shader/GTAssembler2D');
require('./assets/Shader/GTAutoFitSpriteAssembler2D');
require('./assets/Shader/GTSimpleSpriteAssembler2D');
require('./assets/Shader/LayeredBatching/LayeredBatchingAssembler');
require('./assets/Shader/LayeredBatching/LayeredBatchingRootRenderer');
require('./assets/Shader/MetaBalls/MetaBallsAssembler');
require('./assets/Shader/MetaBalls/MetaBallsRenderer');
require('./assets/Shader/MovingBG/MovingBGAssembler');
require('./assets/Shader/MovingBG/MovingBGSprite');
require('./assets/Shader/SpriteMaskedAvatar/SpriteMaskedAvatarAssembler');
require('./assets/Shader/SpriteMaskedAvatar/SpriteMaskedAvatarSprite');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();