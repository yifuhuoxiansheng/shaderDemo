
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/Scripts/Helloworld');
require('./assets/Scripts/Misc/NavigatorButton');
require('./assets/Scripts/Misc/SimpleDraggable');
require('./assets/Scripts/Scene/SceneLayeredBatchingScrollView');
require('./assets/Scripts/Scene/SceneMetaBalls');
require('./assets/Scripts/Scene/SceneSpriteMaskedAvatars');
require('./assets/Scripts/Scene/SceneTest');
require('./assets/Scripts/Scene/SceneTestGraphics');
require('./assets/Scripts/Scene/SceneWelcome');
require('./assets/Shader/Avatar/AvatarAssembler');
require('./assets/Shader/Avatar/AvatarSprite');
require('./assets/Shader/EqualScallingSprite/EqualScalingAssembler');
require('./assets/Shader/EqualScallingSprite/EqualScalingSprite');
require('./assets/Shader/GTAssembler2D');
require('./assets/Shader/GTAutoFitSpriteAssembler2D');
require('./assets/Shader/GTSimpleSpriteAssembler2D');
require('./assets/Shader/LayeredBatching/LayeredBatchingAssembler');
require('./assets/Shader/LayeredBatching/LayeredBatchingRootRenderer');
require('./assets/Shader/MetaBalls/MetaBallsAssembler');
require('./assets/Shader/MetaBalls/MetaBallsRenderer');
require('./assets/Shader/MovingBG/MovingBGAssembler');
require('./assets/Shader/MovingBG/MovingBGSprite');
require('./assets/Shader/SpriteMaskedAvatar/SpriteMaskedAvatarAssembler');
require('./assets/Shader/SpriteMaskedAvatar/SpriteMaskedAvatarSprite');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/MetaBalls/MetaBallsAssembler.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'a8beeORb6JL3b0pL3OhMdkI', 'MetaBallsAssembler');
// Shader/MetaBalls/MetaBallsAssembler.ts

"use strict";
/****************************************************************************
 Author: GT <caogtaa@gmail.com>
 https://caogtaa.github.io
****************************************************************************/
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
//@ts-ignore
var gfx = cc.gfx;
var vfmtPosCenterWeb = new gfx.VertexFormat([
    { name: gfx.ATTR_POSITION, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: "a_center", type: gfx.ATTR_TYPE_FLOAT32, num: 2 } // 原粒子中心（每个顶点相同数据）
]);
var vfmtPosCenterNative = new gfx.VertexFormat([
    { name: gfx.ATTR_POSITION, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: "a_corner", type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: "a_center", type: gfx.ATTR_TYPE_FLOAT32, num: 2 } // 原粒子中心（每个顶点相同数据）
]);
var MetaBallsAssembler = /** @class */ (function (_super) {
    __extends(MetaBallsAssembler, _super);
    function MetaBallsAssembler() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.verticesCount = 0;
        _this.indicesCount = 0;
        _this.floatsPerVert = CC_NATIVERENDERER ? 6 : 4;
        _this._renderData = null;
        _this._prevVerticesCount = 0;
        return _this;
    }
    MetaBallsAssembler.prototype.init = function (comp) {
        _super.prototype.init.call(this, comp);
        this._renderData = new cc.RenderData();
        this._renderData.init(this);
    };
    // initData() {
    //     // do nothing
    // }
    MetaBallsAssembler.prototype.updateColor = function (comp, color) {
        // do nothing
    };
    MetaBallsAssembler.prototype.updateUVs = function (comp) {
        // do nothing
    };
    MetaBallsAssembler.prototype.updateVerts = function (comp) {
        if (!CC_NATIVERENDERER) {
            // web模式直接在fillbuffer里做所有操作，不经过RenderData缓存
            return;
        }
        var particles = this.particles;
        var PTM_RATIO = cc.PhysicsManager.PTM_RATIO;
        var posBuff = particles.GetPositionBuffer();
        var r = particles.GetRadius() * PTM_RATIO * 3; // 倍数扩大渲染距离，超出r的范围颜色衰减
        var particleCount = this.particles.GetParticleCount();
        var verts = this._renderData.vDatas[0];
        var xoffset = comp.node.width * comp.node.anchorX;
        var yoffset = comp.node.height * comp.node.anchorY;
        // fill vertices
        // 暂时不考虑buffer满的情况
        var vertexOffset = 0;
        for (var i = 0; i < particleCount; ++i) {
            var x = posBuff[i].x * PTM_RATIO - xoffset;
            var y = posBuff[i].y * PTM_RATIO - yoffset;
            // left-bottom
            verts[vertexOffset++] = x - r;
            verts[vertexOffset++] = y + r;
            verts[vertexOffset++] = x - r;
            verts[vertexOffset++] = y + r;
            verts[vertexOffset++] = x;
            verts[vertexOffset++] = y;
            // right-bottom
            verts[vertexOffset++] = x + r;
            verts[vertexOffset++] = y + r;
            verts[vertexOffset++] = x + r;
            verts[vertexOffset++] = y + r;
            verts[vertexOffset++] = x;
            verts[vertexOffset++] = y;
            // left-top
            verts[vertexOffset++] = x - r;
            verts[vertexOffset++] = y - r;
            verts[vertexOffset++] = x - r;
            verts[vertexOffset++] = y - r;
            verts[vertexOffset++] = x;
            verts[vertexOffset++] = y;
            // right-top
            verts[vertexOffset++] = x + r;
            verts[vertexOffset++] = y - r;
            verts[vertexOffset++] = x + r;
            verts[vertexOffset++] = y - r;
            verts[vertexOffset++] = x;
            verts[vertexOffset++] = y;
        }
    };
    MetaBallsAssembler.prototype.updateRenderData = function (comp) {
        var _a;
        if (!CC_NATIVERENDERER) {
            return;
        }
        var particleCount = (_a = this.particles) === null || _a === void 0 ? void 0 : _a.GetParticleCount();
        if (!particleCount)
            return;
        if (this._prevVerticesCount != particleCount) {
            this._prevVerticesCount = particleCount;
            // rebuild render data
            this.verticesCount = particleCount * 4;
            this.indicesCount = particleCount * 6;
            var data = this._renderData;
            data.createFlexData(0, this.verticesCount, this.indicesCount, this.getVfmt());
            var indices = data.iDatas[0];
            var count = indices.length / 6;
            for (var i = 0, idx = 0; i < count; i++) {
                var vertextID = i * 4;
                indices[idx++] = vertextID;
                indices[idx++] = vertextID + 1;
                indices[idx++] = vertextID + 2;
                indices[idx++] = vertextID + 1;
                indices[idx++] = vertextID + 3;
                indices[idx++] = vertextID + 2;
            }
        }
        if (comp._vertsDirty) {
            this.updateVerts(comp);
            comp._vertsDirty = false;
        }
    };
    MetaBallsAssembler.prototype.getVfmt = function () {
        if (CC_NATIVERENDERER)
            return vfmtPosCenterNative;
        return vfmtPosCenterWeb;
    };
    MetaBallsAssembler.prototype.getBuffer = function () {
        //@ts-ignore
        return cc.renderer._handle.getBuffer("mesh", this.getVfmt());
    };
    MetaBallsAssembler.prototype.fillBuffers = function (comp, renderer) {
        if (CC_NATIVERENDERER) {
            // 仅对web实现
            // native由于fillBuffer实现在了C++层，需要使用RenderData做缓存
            return;
        }
        var particles = this.particles;
        var particleCount = particles === null || particles === void 0 ? void 0 : particles.GetParticleCount();
        if (!particleCount)
            return;
        // TODO: 简化为按照三角形渲染
        var verticesCount = particleCount * 4;
        var indicesCount = particleCount * 6;
        var PTM_RATIO = cc.PhysicsManager.PTM_RATIO;
        var posBuff = particles.GetPositionBuffer();
        var r = particles.GetRadius() * PTM_RATIO * 3; // 倍数扩大渲染距离，超出r的范围颜色衰减
        //@ts-ignore
        var buffer = this.getBuffer( /*renderer*/);
        var offsetInfo = buffer.request(verticesCount, indicesCount);
        var vertexOffset = offsetInfo.byteOffset >> 2, vbuf = buffer._vData;
        // fill vertices
        // 暂时不考虑buffer满的情况
        for (var i = 0; i < particleCount; ++i) {
            var x = posBuff[i].x * PTM_RATIO;
            var y = posBuff[i].y * PTM_RATIO;
            // left-bottom
            vbuf[vertexOffset++] = x - r;
            vbuf[vertexOffset++] = y + r;
            vbuf[vertexOffset++] = x;
            vbuf[vertexOffset++] = y;
            // right-bottom
            vbuf[vertexOffset++] = x + r;
            vbuf[vertexOffset++] = y + r;
            vbuf[vertexOffset++] = x;
            vbuf[vertexOffset++] = y;
            // left-top
            vbuf[vertexOffset++] = x - r;
            vbuf[vertexOffset++] = y - r;
            vbuf[vertexOffset++] = x;
            vbuf[vertexOffset++] = y;
            // right-top
            vbuf[vertexOffset++] = x + r;
            vbuf[vertexOffset++] = y - r;
            vbuf[vertexOffset++] = x;
            vbuf[vertexOffset++] = y;
        }
        // 仅当顶点索引发生变化时计算? 
        // vertexOffset是动态的，每一帧都有可能有差异，无法批量拷贝
        var ibuf = buffer._iData, indiceOffset = offsetInfo.indiceOffset, vertexId = offsetInfo.vertexOffset; // vertexId是已经在buffer里的顶点数，也是当前顶点序号的基数
        for (var i = 0; i < particleCount; ++i) {
            ibuf[indiceOffset++] = vertexId;
            ibuf[indiceOffset++] = vertexId + 1;
            ibuf[indiceOffset++] = vertexId + 2;
            ibuf[indiceOffset++] = vertexId + 1;
            ibuf[indiceOffset++] = vertexId + 3;
            ibuf[indiceOffset++] = vertexId + 2;
            vertexId += 4;
        }
    };
    return MetaBallsAssembler;
}(cc.Assembler));
exports.default = MetaBallsAssembler;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvTWV0YUJhbGxzL01ldGFCYWxsc0Fzc2VtYmxlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7Ozs2RUFHNkU7Ozs7Ozs7Ozs7Ozs7OztBQUU3RSxZQUFZO0FBQ1osSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQztBQUNqQixJQUFJLGdCQUFnQixHQUFHLElBQUksR0FBRyxDQUFDLFlBQVksQ0FBQztJQUN4QyxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsYUFBYSxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsaUJBQWlCLEVBQUUsR0FBRyxFQUFFLENBQUMsRUFBRTtJQUNoRSxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQVcsa0JBQWtCO0NBQ3pGLENBQUMsQ0FBQztBQUVILElBQUksbUJBQW1CLEdBQUcsSUFBSSxHQUFHLENBQUMsWUFBWSxDQUFDO0lBQzNDLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQyxhQUFhLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxHQUFHLEVBQUUsQ0FBQyxFQUFFO0lBQ2hFLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLGlCQUFpQixFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQUU7SUFDekQsRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsaUJBQWlCLEVBQUUsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFXLGtCQUFrQjtDQUN6RixDQUFDLENBQUM7QUFFSDtJQUFnRCxzQ0FBWTtJQUE1RDtRQUFBLHFFQWlOQztRQWhORyxtQkFBYSxHQUFHLENBQUMsQ0FBQztRQUNsQixrQkFBWSxHQUFHLENBQUMsQ0FBQztRQUNqQixtQkFBYSxHQUFHLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUloQyxpQkFBVyxHQUFrQixJQUFJLENBQUM7UUFDbEMsd0JBQWtCLEdBQVcsQ0FBQyxDQUFDOztJQXlNN0MsQ0FBQztJQXZNRyxpQ0FBSSxHQUFKLFVBQUssSUFBd0I7UUFDekIsaUJBQU0sSUFBSSxZQUFDLElBQUksQ0FBQyxDQUFDO1FBRWpCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxFQUFFLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDdkMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDaEMsQ0FBQztJQUVELGVBQWU7SUFDZixvQkFBb0I7SUFDcEIsSUFBSTtJQUVKLHdDQUFXLEdBQVgsVUFBWSxJQUFJLEVBQUUsS0FBSztRQUNuQixhQUFhO0lBQ2pCLENBQUM7SUFFRCxzQ0FBUyxHQUFULFVBQVUsSUFBSTtRQUNWLGFBQWE7SUFDakIsQ0FBQztJQUVELHdDQUFXLEdBQVgsVUFBWSxJQUFJO1FBQ1osSUFBSSxDQUFDLGlCQUFpQixFQUFFO1lBQ3BCLDJDQUEyQztZQUMzQyxPQUFPO1NBQ1Y7UUFFRCxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBQy9CLElBQUksU0FBUyxHQUFHLEVBQUUsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDO1FBQ2xELElBQUksT0FBTyxHQUFHLFNBQVMsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQ3RDLElBQUksQ0FBQyxHQUFHLFNBQVMsQ0FBQyxTQUFTLEVBQUUsR0FBRyxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQU0sc0JBQXNCO1FBQzFFLElBQUksYUFBYSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUN0RCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUV2QyxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztRQUNsRCxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztRQUVuRCxnQkFBZ0I7UUFDaEIsa0JBQWtCO1FBQ2xCLElBQUksWUFBWSxHQUFHLENBQUMsQ0FBQztRQUNyQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsYUFBYSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ3BDLElBQUksQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxHQUFHLE9BQU8sQ0FBQztZQUMzQyxJQUFJLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLFNBQVMsR0FBRyxPQUFPLENBQUM7WUFFM0MsY0FBYztZQUNkLEtBQUssQ0FBQyxZQUFZLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDOUIsS0FBSyxDQUFDLFlBQVksRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUM5QixLQUFLLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzlCLEtBQUssQ0FBQyxZQUFZLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDOUIsS0FBSyxDQUFDLFlBQVksRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzFCLEtBQUssQ0FBQyxZQUFZLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUUxQixlQUFlO1lBQ2YsS0FBSyxDQUFDLFlBQVksRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUM5QixLQUFLLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzlCLEtBQUssQ0FBQyxZQUFZLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDOUIsS0FBSyxDQUFDLFlBQVksRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUM5QixLQUFLLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDMUIsS0FBSyxDQUFDLFlBQVksRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBRTFCLFdBQVc7WUFDWCxLQUFLLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzlCLEtBQUssQ0FBQyxZQUFZLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDOUIsS0FBSyxDQUFDLFlBQVksRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUM5QixLQUFLLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzlCLEtBQUssQ0FBQyxZQUFZLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUMxQixLQUFLLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7WUFFMUIsWUFBWTtZQUNaLEtBQUssQ0FBQyxZQUFZLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDOUIsS0FBSyxDQUFDLFlBQVksRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUM5QixLQUFLLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzlCLEtBQUssQ0FBQyxZQUFZLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDOUIsS0FBSyxDQUFDLFlBQVksRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzFCLEtBQUssQ0FBQyxZQUFZLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUM3QjtJQUNMLENBQUM7SUFFRCw2Q0FBZ0IsR0FBaEIsVUFBaUIsSUFBSTs7UUFDakIsSUFBSSxDQUFDLGlCQUFpQixFQUFFO1lBQ3BCLE9BQU87U0FDVjtRQUVELElBQUksYUFBYSxTQUFHLElBQUksQ0FBQyxTQUFTLDBDQUFFLGdCQUFnQixFQUFFLENBQUM7UUFDdkQsSUFBSSxDQUFDLGFBQWE7WUFDZCxPQUFPO1FBRVgsSUFBSSxJQUFJLENBQUMsa0JBQWtCLElBQUksYUFBYSxFQUFFO1lBQzFDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxhQUFhLENBQUM7WUFFeEMsc0JBQXNCO1lBQ3RCLElBQUksQ0FBQyxhQUFhLEdBQUcsYUFBYSxHQUFHLENBQUMsQ0FBQztZQUN2QyxJQUFJLENBQUMsWUFBWSxHQUFHLGFBQWEsR0FBRyxDQUFDLENBQUM7WUFFdEMsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQztZQUM1QixJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7WUFFOUUsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM3QixJQUFJLEtBQUssR0FBRyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztZQUMvQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxHQUFHLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3JDLElBQUksU0FBUyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3RCLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLFNBQVMsQ0FBQztnQkFDM0IsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsU0FBUyxHQUFDLENBQUMsQ0FBQztnQkFDN0IsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsU0FBUyxHQUFDLENBQUMsQ0FBQztnQkFDN0IsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsU0FBUyxHQUFDLENBQUMsQ0FBQztnQkFDN0IsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsU0FBUyxHQUFDLENBQUMsQ0FBQztnQkFDN0IsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsU0FBUyxHQUFDLENBQUMsQ0FBQzthQUNoQztTQUNKO1FBRUQsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFO1lBQ2xCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDdkIsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7U0FDNUI7SUFDTCxDQUFDO0lBRUQsb0NBQU8sR0FBUDtRQUNJLElBQUksaUJBQWlCO1lBQ2pCLE9BQU8sbUJBQW1CLENBQUM7UUFFL0IsT0FBTyxnQkFBZ0IsQ0FBQztJQUM1QixDQUFDO0lBRUQsc0NBQVMsR0FBVDtRQUNJLFlBQVk7UUFDWixPQUFPLEVBQUUsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7SUFDakUsQ0FBQztJQUVELHdDQUFXLEdBQVgsVUFBWSxJQUFJLEVBQUUsUUFBUTtRQUN0QixJQUFJLGlCQUFpQixFQUFFO1lBQ25CLFVBQVU7WUFDViwrQ0FBK0M7WUFDL0MsT0FBTztTQUNWO1FBRUQsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztRQUMvQixJQUFJLGFBQWEsR0FBRyxTQUFTLGFBQVQsU0FBUyx1QkFBVCxTQUFTLENBQUUsZ0JBQWdCLEVBQUUsQ0FBQztRQUNsRCxJQUFJLENBQUMsYUFBYTtZQUNkLE9BQU87UUFFWCxtQkFBbUI7UUFDbkIsSUFBSSxhQUFhLEdBQUcsYUFBYSxHQUFHLENBQUMsQ0FBQztRQUN0QyxJQUFJLFlBQVksR0FBRyxhQUFhLEdBQUcsQ0FBQyxDQUFDO1FBQ3JDLElBQUksU0FBUyxHQUFHLEVBQUUsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDO1FBQ2xELElBQUksT0FBTyxHQUFHLFNBQVMsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQ3RDLElBQUksQ0FBQyxHQUFHLFNBQVMsQ0FBQyxTQUFTLEVBQUUsR0FBRyxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQU0sc0JBQXNCO1FBRTFFLFlBQVk7UUFDWixJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsU0FBUyxFQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzFDLElBQUksVUFBVSxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBRTdELElBQUksWUFBWSxHQUFHLFVBQVUsQ0FBQyxVQUFVLElBQUksQ0FBQyxFQUN6QyxJQUFJLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQztRQUV6QixnQkFBZ0I7UUFDaEIsa0JBQWtCO1FBQ2xCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxhQUFhLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDcEMsSUFBSSxDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxTQUFTLENBQUM7WUFDakMsSUFBSSxDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxTQUFTLENBQUM7WUFFakMsY0FBYztZQUNkLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDN0IsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUM3QixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDekIsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBRXpCLGVBQWU7WUFDZixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzdCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDN0IsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3pCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUV6QixXQUFXO1lBQ1gsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUM3QixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzdCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN6QixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7WUFFekIsWUFBWTtZQUNaLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDN0IsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUM3QixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDekIsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQzVCO1FBRUQsa0JBQWtCO1FBQ2xCLHFDQUFxQztRQUNyQyxJQUFJLElBQUksR0FBRyxNQUFNLENBQUMsTUFBTSxFQUN4QixZQUFZLEdBQUcsVUFBVSxDQUFDLFlBQVksRUFDdEMsUUFBUSxHQUFHLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBYSxzQ0FBc0M7UUFFdEYsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGFBQWEsRUFBRSxFQUFFLENBQUMsRUFBRTtZQUNwQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxRQUFRLENBQUM7WUFDaEMsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDLEdBQUcsUUFBUSxHQUFHLENBQUMsQ0FBQztZQUNwQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxRQUFRLEdBQUcsQ0FBQyxDQUFDO1lBQ3BDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxHQUFHLFFBQVEsR0FBRyxDQUFDLENBQUM7WUFDcEMsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDLEdBQUcsUUFBUSxHQUFHLENBQUMsQ0FBQztZQUNwQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxRQUFRLEdBQUcsQ0FBQyxDQUFDO1lBQ3BDLFFBQVEsSUFBSSxDQUFDLENBQUM7U0FDakI7SUFDTCxDQUFDO0lBQ0wseUJBQUM7QUFBRCxDQWpOQSxBQWlOQyxDQWpOK0MsRUFBRSxDQUFDLFNBQVMsR0FpTjNEIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiBBdXRob3I6IEdUIDxjYW9ndGFhQGdtYWlsLmNvbT5cbiBodHRwczovL2Nhb2d0YWEuZ2l0aHViLmlvXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuXG4vL0B0cy1pZ25vcmVcbmxldCBnZnggPSBjYy5nZng7XG52YXIgdmZtdFBvc0NlbnRlcldlYiA9IG5ldyBnZnguVmVydGV4Rm9ybWF0KFtcbiAgICB7IG5hbWU6IGdmeC5BVFRSX1BPU0lUSU9OLCB0eXBlOiBnZnguQVRUUl9UWVBFX0ZMT0FUMzIsIG51bTogMiB9LCAgIC8vIOeykuWtkOmhtueCue+8iDHkuKrnspLlrZDmnIkz5Liq5oiWNOS4qumhtueCue+8iVxuICAgIHsgbmFtZTogXCJhX2NlbnRlclwiLCB0eXBlOiBnZnguQVRUUl9UWVBFX0ZMT0FUMzIsIG51bTogMiB9ICAgICAgICAgICAvLyDljp/nspLlrZDkuK3lv4PvvIjmr4/kuKrpobbngrnnm7jlkIzmlbDmja7vvIlcbl0pO1xuXG52YXIgdmZtdFBvc0NlbnRlck5hdGl2ZSA9IG5ldyBnZnguVmVydGV4Rm9ybWF0KFtcbiAgICB7IG5hbWU6IGdmeC5BVFRSX1BPU0lUSU9OLCB0eXBlOiBnZnguQVRUUl9UWVBFX0ZMT0FUMzIsIG51bTogMiB9LCAgIC8vIOeykuWtkOmhtueCue+8iDHkuKrnspLlrZDmnIkz5Liq5oiWNOS4qumhtueCue+8iVxuICAgIHsgbmFtZTogXCJhX2Nvcm5lclwiLCB0eXBlOiBnZnguQVRUUl9UWVBFX0ZMT0FUMzIsIG51bTogMiB9LCAgICAgICAgICAvLyBhX3Bvc2l0aW9u55qE5YaX5L2Z77yMYV9wb3NpdGlvbuWcqG5hdGl2ZeaYr+S4quWkp+WdkVxuICAgIHsgbmFtZTogXCJhX2NlbnRlclwiLCB0eXBlOiBnZnguQVRUUl9UWVBFX0ZMT0FUMzIsIG51bTogMiB9ICAgICAgICAgICAvLyDljp/nspLlrZDkuK3lv4PvvIjmr4/kuKrpobbngrnnm7jlkIzmlbDmja7vvIlcbl0pO1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNZXRhQmFsbHNBc3NlbWJsZXIgZXh0ZW5kcyBjYy5Bc3NlbWJsZXIge1xuICAgIHZlcnRpY2VzQ291bnQgPSAwO1xuICAgIGluZGljZXNDb3VudCA9IDA7XG4gICAgZmxvYXRzUGVyVmVydCA9IENDX05BVElWRVJFTkRFUkVSID8gNiA6IDQ7XG5cbiAgICBwdWJsaWMgcGFydGljbGVzO1xuXG4gICAgcHJvdGVjdGVkIF9yZW5kZXJEYXRhOiBjYy5SZW5kZXJEYXRhID0gbnVsbDtcbiAgICBwcm90ZWN0ZWQgX3ByZXZWZXJ0aWNlc0NvdW50OiBudW1iZXIgPSAwO1xuXG4gICAgaW5pdChjb21wOiBjYy5SZW5kZXJDb21wb25lbnQpIHtcbiAgICAgICAgc3VwZXIuaW5pdChjb21wKTtcblxuICAgICAgICB0aGlzLl9yZW5kZXJEYXRhID0gbmV3IGNjLlJlbmRlckRhdGEoKTtcbiAgICAgICAgdGhpcy5fcmVuZGVyRGF0YS5pbml0KHRoaXMpO1xuICAgIH1cblxuICAgIC8vIGluaXREYXRhKCkge1xuICAgIC8vICAgICAvLyBkbyBub3RoaW5nXG4gICAgLy8gfVxuXG4gICAgdXBkYXRlQ29sb3IoY29tcCwgY29sb3IpIHtcbiAgICAgICAgLy8gZG8gbm90aGluZ1xuICAgIH1cblxuICAgIHVwZGF0ZVVWcyhjb21wKSB7XG4gICAgICAgIC8vIGRvIG5vdGhpbmdcbiAgICB9XG5cbiAgICB1cGRhdGVWZXJ0cyhjb21wKSB7XG4gICAgICAgIGlmICghQ0NfTkFUSVZFUkVOREVSRVIpIHtcbiAgICAgICAgICAgIC8vIHdlYuaooeW8j+ebtOaOpeWcqGZpbGxidWZmZXLph4zlgZrmiYDmnInmk43kvZzvvIzkuI3nu4/ov4dSZW5kZXJEYXRh57yT5a2YXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBsZXQgcGFydGljbGVzID0gdGhpcy5wYXJ0aWNsZXM7XG4gICAgICAgIGxldCBQVE1fUkFUSU8gPSBjYy5QaHlzaWNzTWFuYWdlci5QVE1fUkFUSU87XG5cdFx0bGV0IHBvc0J1ZmYgPSBwYXJ0aWNsZXMuR2V0UG9zaXRpb25CdWZmZXIoKTtcbiAgICAgICAgbGV0IHIgPSBwYXJ0aWNsZXMuR2V0UmFkaXVzKCkgKiBQVE1fUkFUSU8gKiAzOyAgICAgIC8vIOWAjeaVsOaJqeWkp+a4suafk+i3neemu++8jOi2heWHunLnmoTojIPlm7TpopzoibLoobDlh49cbiAgICAgICAgbGV0IHBhcnRpY2xlQ291bnQgPSB0aGlzLnBhcnRpY2xlcy5HZXRQYXJ0aWNsZUNvdW50KCk7XG4gICAgICAgIGxldCB2ZXJ0cyA9IHRoaXMuX3JlbmRlckRhdGEudkRhdGFzWzBdO1xuXG4gICAgICAgIGxldCB4b2Zmc2V0ID0gY29tcC5ub2RlLndpZHRoICogY29tcC5ub2RlLmFuY2hvclg7XG4gICAgICAgIGxldCB5b2Zmc2V0ID0gY29tcC5ub2RlLmhlaWdodCAqIGNvbXAubm9kZS5hbmNob3JZO1xuXG4gICAgICAgIC8vIGZpbGwgdmVydGljZXNcbiAgICAgICAgLy8g5pqC5pe25LiN6ICD6JmRYnVmZmVy5ruh55qE5oOF5Ya1XG4gICAgICAgIGxldCB2ZXJ0ZXhPZmZzZXQgPSAwO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHBhcnRpY2xlQ291bnQ7ICsraSkge1xuICAgICAgICAgICAgbGV0IHggPSBwb3NCdWZmW2ldLnggKiBQVE1fUkFUSU8gLSB4b2Zmc2V0O1xuICAgICAgICAgICAgbGV0IHkgPSBwb3NCdWZmW2ldLnkgKiBQVE1fUkFUSU8gLSB5b2Zmc2V0O1xuXG4gICAgICAgICAgICAvLyBsZWZ0LWJvdHRvbVxuICAgICAgICAgICAgdmVydHNbdmVydGV4T2Zmc2V0KytdID0geCAtIHI7XG4gICAgICAgICAgICB2ZXJ0c1t2ZXJ0ZXhPZmZzZXQrK10gPSB5ICsgcjtcbiAgICAgICAgICAgIHZlcnRzW3ZlcnRleE9mZnNldCsrXSA9IHggLSByO1xuICAgICAgICAgICAgdmVydHNbdmVydGV4T2Zmc2V0KytdID0geSArIHI7XG4gICAgICAgICAgICB2ZXJ0c1t2ZXJ0ZXhPZmZzZXQrK10gPSB4O1xuICAgICAgICAgICAgdmVydHNbdmVydGV4T2Zmc2V0KytdID0geTtcblxuICAgICAgICAgICAgLy8gcmlnaHQtYm90dG9tXG4gICAgICAgICAgICB2ZXJ0c1t2ZXJ0ZXhPZmZzZXQrK10gPSB4ICsgcjtcbiAgICAgICAgICAgIHZlcnRzW3ZlcnRleE9mZnNldCsrXSA9IHkgKyByO1xuICAgICAgICAgICAgdmVydHNbdmVydGV4T2Zmc2V0KytdID0geCArIHI7XG4gICAgICAgICAgICB2ZXJ0c1t2ZXJ0ZXhPZmZzZXQrK10gPSB5ICsgcjtcbiAgICAgICAgICAgIHZlcnRzW3ZlcnRleE9mZnNldCsrXSA9IHg7XG4gICAgICAgICAgICB2ZXJ0c1t2ZXJ0ZXhPZmZzZXQrK10gPSB5O1xuXG4gICAgICAgICAgICAvLyBsZWZ0LXRvcFxuICAgICAgICAgICAgdmVydHNbdmVydGV4T2Zmc2V0KytdID0geCAtIHI7XG4gICAgICAgICAgICB2ZXJ0c1t2ZXJ0ZXhPZmZzZXQrK10gPSB5IC0gcjtcbiAgICAgICAgICAgIHZlcnRzW3ZlcnRleE9mZnNldCsrXSA9IHggLSByO1xuICAgICAgICAgICAgdmVydHNbdmVydGV4T2Zmc2V0KytdID0geSAtIHI7XG4gICAgICAgICAgICB2ZXJ0c1t2ZXJ0ZXhPZmZzZXQrK10gPSB4O1xuICAgICAgICAgICAgdmVydHNbdmVydGV4T2Zmc2V0KytdID0geTtcblxuICAgICAgICAgICAgLy8gcmlnaHQtdG9wXG4gICAgICAgICAgICB2ZXJ0c1t2ZXJ0ZXhPZmZzZXQrK10gPSB4ICsgcjtcbiAgICAgICAgICAgIHZlcnRzW3ZlcnRleE9mZnNldCsrXSA9IHkgLSByO1xuICAgICAgICAgICAgdmVydHNbdmVydGV4T2Zmc2V0KytdID0geCArIHI7XG4gICAgICAgICAgICB2ZXJ0c1t2ZXJ0ZXhPZmZzZXQrK10gPSB5IC0gcjtcbiAgICAgICAgICAgIHZlcnRzW3ZlcnRleE9mZnNldCsrXSA9IHg7XG4gICAgICAgICAgICB2ZXJ0c1t2ZXJ0ZXhPZmZzZXQrK10gPSB5O1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgdXBkYXRlUmVuZGVyRGF0YShjb21wKSB7XG4gICAgICAgIGlmICghQ0NfTkFUSVZFUkVOREVSRVIpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGxldCBwYXJ0aWNsZUNvdW50ID0gdGhpcy5wYXJ0aWNsZXM/LkdldFBhcnRpY2xlQ291bnQoKTtcbiAgICAgICAgaWYgKCFwYXJ0aWNsZUNvdW50KVxuICAgICAgICAgICAgcmV0dXJuO1xuXG4gICAgICAgIGlmICh0aGlzLl9wcmV2VmVydGljZXNDb3VudCAhPSBwYXJ0aWNsZUNvdW50KSB7XG4gICAgICAgICAgICB0aGlzLl9wcmV2VmVydGljZXNDb3VudCA9IHBhcnRpY2xlQ291bnQ7XG5cbiAgICAgICAgICAgIC8vIHJlYnVpbGQgcmVuZGVyIGRhdGFcbiAgICAgICAgICAgIHRoaXMudmVydGljZXNDb3VudCA9IHBhcnRpY2xlQ291bnQgKiA0O1xuICAgICAgICAgICAgdGhpcy5pbmRpY2VzQ291bnQgPSBwYXJ0aWNsZUNvdW50ICogNjtcblxuICAgICAgICAgICAgbGV0IGRhdGEgPSB0aGlzLl9yZW5kZXJEYXRhO1xuICAgICAgICAgICAgZGF0YS5jcmVhdGVGbGV4RGF0YSgwLCB0aGlzLnZlcnRpY2VzQ291bnQsIHRoaXMuaW5kaWNlc0NvdW50LCB0aGlzLmdldFZmbXQoKSk7XG5cbiAgICAgICAgICAgIGxldCBpbmRpY2VzID0gZGF0YS5pRGF0YXNbMF07XG4gICAgICAgICAgICBsZXQgY291bnQgPSBpbmRpY2VzLmxlbmd0aCAvIDY7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMCwgaWR4ID0gMDsgaSA8IGNvdW50OyBpKyspIHtcbiAgICAgICAgICAgICAgICBsZXQgdmVydGV4dElEID0gaSAqIDQ7XG4gICAgICAgICAgICAgICAgaW5kaWNlc1tpZHgrK10gPSB2ZXJ0ZXh0SUQ7XG4gICAgICAgICAgICAgICAgaW5kaWNlc1tpZHgrK10gPSB2ZXJ0ZXh0SUQrMTtcbiAgICAgICAgICAgICAgICBpbmRpY2VzW2lkeCsrXSA9IHZlcnRleHRJRCsyO1xuICAgICAgICAgICAgICAgIGluZGljZXNbaWR4KytdID0gdmVydGV4dElEKzE7XG4gICAgICAgICAgICAgICAgaW5kaWNlc1tpZHgrK10gPSB2ZXJ0ZXh0SUQrMztcbiAgICAgICAgICAgICAgICBpbmRpY2VzW2lkeCsrXSA9IHZlcnRleHRJRCsyO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGNvbXAuX3ZlcnRzRGlydHkpIHtcbiAgICAgICAgICAgIHRoaXMudXBkYXRlVmVydHMoY29tcCk7XG4gICAgICAgICAgICBjb21wLl92ZXJ0c0RpcnR5ID0gZmFsc2U7XG4gICAgICAgIH0gICAgICAgIFxuICAgIH1cblxuICAgIGdldFZmbXQoKSB7XG4gICAgICAgIGlmIChDQ19OQVRJVkVSRU5ERVJFUilcbiAgICAgICAgICAgIHJldHVybiB2Zm10UG9zQ2VudGVyTmF0aXZlO1xuICAgICAgICBcbiAgICAgICAgcmV0dXJuIHZmbXRQb3NDZW50ZXJXZWI7XG4gICAgfVxuXG4gICAgZ2V0QnVmZmVyKCkge1xuICAgICAgICAvL0B0cy1pZ25vcmVcbiAgICAgICAgcmV0dXJuIGNjLnJlbmRlcmVyLl9oYW5kbGUuZ2V0QnVmZmVyKFwibWVzaFwiLCB0aGlzLmdldFZmbXQoKSk7XG4gICAgfVxuXG4gICAgZmlsbEJ1ZmZlcnMoY29tcCwgcmVuZGVyZXIpIHtcbiAgICAgICAgaWYgKENDX05BVElWRVJFTkRFUkVSKSB7XG4gICAgICAgICAgICAvLyDku4Xlr7l3ZWLlrp7njrBcbiAgICAgICAgICAgIC8vIG5hdGl2ZeeUseS6jmZpbGxCdWZmZXLlrp7njrDlnKjkuoZDKyvlsYLvvIzpnIDopoHkvb/nlKhSZW5kZXJEYXRh5YGa57yT5a2YXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBsZXQgcGFydGljbGVzID0gdGhpcy5wYXJ0aWNsZXM7XG4gICAgICAgIGxldCBwYXJ0aWNsZUNvdW50ID0gcGFydGljbGVzPy5HZXRQYXJ0aWNsZUNvdW50KCk7XG4gICAgICAgIGlmICghcGFydGljbGVDb3VudClcbiAgICAgICAgICAgIHJldHVybjtcblxuICAgICAgICAvLyBUT0RPOiDnroDljJbkuLrmjInnhafkuInop5LlvaLmuLLmn5NcbiAgICAgICAgbGV0IHZlcnRpY2VzQ291bnQgPSBwYXJ0aWNsZUNvdW50ICogNDtcbiAgICAgICAgbGV0IGluZGljZXNDb3VudCA9IHBhcnRpY2xlQ291bnQgKiA2O1xuICAgICAgICBsZXQgUFRNX1JBVElPID0gY2MuUGh5c2ljc01hbmFnZXIuUFRNX1JBVElPO1xuXHRcdGxldCBwb3NCdWZmID0gcGFydGljbGVzLkdldFBvc2l0aW9uQnVmZmVyKCk7XG4gICAgICAgIGxldCByID0gcGFydGljbGVzLkdldFJhZGl1cygpICogUFRNX1JBVElPICogMzsgICAgICAvLyDlgI3mlbDmianlpKfmuLLmn5Pot53nprvvvIzotoXlh7py55qE6IyD5Zu06aKc6Imy6KGw5YePXG4gICAgICAgIFxuICAgICAgICAvL0B0cy1pZ25vcmVcbiAgICAgICAgbGV0IGJ1ZmZlciA9IHRoaXMuZ2V0QnVmZmVyKC8qcmVuZGVyZXIqLyk7XG4gICAgICAgIGxldCBvZmZzZXRJbmZvID0gYnVmZmVyLnJlcXVlc3QodmVydGljZXNDb3VudCwgaW5kaWNlc0NvdW50KTtcblxuICAgICAgICBsZXQgdmVydGV4T2Zmc2V0ID0gb2Zmc2V0SW5mby5ieXRlT2Zmc2V0ID4+IDIsXG4gICAgICAgICAgICB2YnVmID0gYnVmZmVyLl92RGF0YTtcblxuICAgICAgICAvLyBmaWxsIHZlcnRpY2VzXG4gICAgICAgIC8vIOaaguaXtuS4jeiAg+iZkWJ1ZmZlcua7oeeahOaDheWGtVxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHBhcnRpY2xlQ291bnQ7ICsraSkge1xuICAgICAgICAgICAgbGV0IHggPSBwb3NCdWZmW2ldLnggKiBQVE1fUkFUSU87XG4gICAgICAgICAgICBsZXQgeSA9IHBvc0J1ZmZbaV0ueSAqIFBUTV9SQVRJTztcblxuICAgICAgICAgICAgLy8gbGVmdC1ib3R0b21cbiAgICAgICAgICAgIHZidWZbdmVydGV4T2Zmc2V0KytdID0geCAtIHI7XG4gICAgICAgICAgICB2YnVmW3ZlcnRleE9mZnNldCsrXSA9IHkgKyByO1xuICAgICAgICAgICAgdmJ1Zlt2ZXJ0ZXhPZmZzZXQrK10gPSB4O1xuICAgICAgICAgICAgdmJ1Zlt2ZXJ0ZXhPZmZzZXQrK10gPSB5O1xuXG4gICAgICAgICAgICAvLyByaWdodC1ib3R0b21cbiAgICAgICAgICAgIHZidWZbdmVydGV4T2Zmc2V0KytdID0geCArIHI7XG4gICAgICAgICAgICB2YnVmW3ZlcnRleE9mZnNldCsrXSA9IHkgKyByO1xuICAgICAgICAgICAgdmJ1Zlt2ZXJ0ZXhPZmZzZXQrK10gPSB4O1xuICAgICAgICAgICAgdmJ1Zlt2ZXJ0ZXhPZmZzZXQrK10gPSB5O1xuXG4gICAgICAgICAgICAvLyBsZWZ0LXRvcFxuICAgICAgICAgICAgdmJ1Zlt2ZXJ0ZXhPZmZzZXQrK10gPSB4IC0gcjtcbiAgICAgICAgICAgIHZidWZbdmVydGV4T2Zmc2V0KytdID0geSAtIHI7XG4gICAgICAgICAgICB2YnVmW3ZlcnRleE9mZnNldCsrXSA9IHg7XG4gICAgICAgICAgICB2YnVmW3ZlcnRleE9mZnNldCsrXSA9IHk7XG5cbiAgICAgICAgICAgIC8vIHJpZ2h0LXRvcFxuICAgICAgICAgICAgdmJ1Zlt2ZXJ0ZXhPZmZzZXQrK10gPSB4ICsgcjtcbiAgICAgICAgICAgIHZidWZbdmVydGV4T2Zmc2V0KytdID0geSAtIHI7XG4gICAgICAgICAgICB2YnVmW3ZlcnRleE9mZnNldCsrXSA9IHg7XG4gICAgICAgICAgICB2YnVmW3ZlcnRleE9mZnNldCsrXSA9IHk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyDku4XlvZPpobbngrnntKLlvJXlj5HnlJ/lj5jljJbml7borqHnrpc/IFxuICAgICAgICAvLyB2ZXJ0ZXhPZmZzZXTmmK/liqjmgIHnmoTvvIzmr4/kuIDluKfpg73mnInlj6/og73mnInlt67lvILvvIzml6Dms5Xmibnph4/mi7fotJ1cbiAgICAgICAgbGV0IGlidWYgPSBidWZmZXIuX2lEYXRhLFxuICAgICAgICBpbmRpY2VPZmZzZXQgPSBvZmZzZXRJbmZvLmluZGljZU9mZnNldCxcbiAgICAgICAgdmVydGV4SWQgPSBvZmZzZXRJbmZvLnZlcnRleE9mZnNldDsgICAgICAgICAgICAgLy8gdmVydGV4SWTmmK/lt7Lnu4/lnKhidWZmZXLph4znmoTpobbngrnmlbDvvIzkuZ/mmK/lvZPliY3pobbngrnluo/lj7fnmoTln7rmlbBcblxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHBhcnRpY2xlQ291bnQ7ICsraSkge1xuICAgICAgICAgICAgaWJ1ZltpbmRpY2VPZmZzZXQrK10gPSB2ZXJ0ZXhJZDtcbiAgICAgICAgICAgIGlidWZbaW5kaWNlT2Zmc2V0KytdID0gdmVydGV4SWQgKyAxO1xuICAgICAgICAgICAgaWJ1ZltpbmRpY2VPZmZzZXQrK10gPSB2ZXJ0ZXhJZCArIDI7XG4gICAgICAgICAgICBpYnVmW2luZGljZU9mZnNldCsrXSA9IHZlcnRleElkICsgMTtcbiAgICAgICAgICAgIGlidWZbaW5kaWNlT2Zmc2V0KytdID0gdmVydGV4SWQgKyAzO1xuICAgICAgICAgICAgaWJ1ZltpbmRpY2VPZmZzZXQrK10gPSB2ZXJ0ZXhJZCArIDI7XG4gICAgICAgICAgICB2ZXJ0ZXhJZCArPSA0O1xuICAgICAgICB9XG4gICAgfVxufVxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/GTAssembler2D.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ec2e84JLsNF8Z3zxl9otwbJ', 'GTAssembler2D');
// Shader/GTAssembler2D.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-13 02:44:17
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:04:43
*/
// 自定义渲染
// https://docs.cocos.com/creator/manual/zh/advanced-topics/custom-render.html#%E8%87%AA%E5%AE%9A%E4%B9%89-assembler
var GTAssembler2D = /** @class */ (function (_super) {
    __extends(GTAssembler2D, _super);
    function GTAssembler2D() {
        // 每个2d渲染单元里的有:
        // 4个顶点属性数据
        // 6个顶点索引 -> 三角剖分成2个三角形
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // 每个顶点属性由5个32位数据组成
        // 顶点属性声明:
        // var vfmtPosUvColor = new gfx.VertexFormat([
        //     { name: gfx.ATTR_POSITION, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
        //     { name: gfx.ATTR_UV0, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
        //     { name: gfx.ATTR_COLOR, type: gfx.ATTR_TYPE_UINT8, num: 4, normalize: true },       // 4个uint8
        // ]);
        // 顶点属性数据排列，每一格是32位 (float32/uint32)
        // x|y|u|v|color|x|y|u|v|color|...
        // 其中uv在一组数据中的偏移是2，color的偏移是4
        _this.verticesCount = 4;
        _this.indicesCount = 6;
        _this.floatsPerVert = 5;
        // vdata offset info
        _this.uvOffset = 2;
        _this.colorOffset = 4;
        _this._renderData = null;
        _this._local = null; // 中间结果。[l,b,r,t]。node对象左下、右上顶点的本地坐标，即相对于锚点的偏移
        return _this;
    }
    GTAssembler2D.prototype.init = function (comp) {
        _super.prototype.init.call(this, comp);
        // cc.Assembler2D的初始化放在constructor里
        // 此处把初始化放在init里，以便成员变量能够有机会修改
        this._renderData = new cc.RenderData();
        this._renderData.init(this);
        this.initLocal();
        this.initData();
    };
    Object.defineProperty(GTAssembler2D.prototype, "verticesFloats", {
        get: function () {
            return this.verticesCount * this.floatsPerVert;
        },
        enumerable: false,
        configurable: true
    });
    GTAssembler2D.prototype.initData = function () {
        var data = this._renderData;
        data.createQuadData(0, this.verticesFloats, this.indicesCount);
        // createQuadData内部会调用initQuadIndices初始化索引信息
        // 如果是用用flexbuffer创建则需要自己初始化
    };
    GTAssembler2D.prototype.initLocal = function () {
        this._local = [];
        this._local.length = 4;
    };
    GTAssembler2D.prototype.updateColor = function (comp, color) {
        // render data = verts = x|y|u|v|color|x|y|u|v|color|...
        // 填充render data中4个顶点的color部分
        var uintVerts = this._renderData.uintVDatas[0];
        if (!uintVerts)
            return;
        color = color != null ? color : comp.node.color._val;
        var floatsPerVert = this.floatsPerVert;
        var colorOffset = this.colorOffset;
        for (var i = colorOffset, l = uintVerts.length; i < l; i += floatsPerVert) {
            uintVerts[i] = color;
        }
    };
    GTAssembler2D.prototype.getBuffer = function () {
        //@ts-ignore
        return cc.renderer._handle._meshBuffer;
    };
    GTAssembler2D.prototype.updateWorldVerts = function (comp) {
        if (CC_NATIVERENDERER) {
            this.updateWorldVertsNative(comp);
        }
        else {
            this.updateWorldVertsWebGL(comp);
        }
    };
    GTAssembler2D.prototype.updateWorldVertsWebGL = function (comp) {
        var local = this._local;
        var verts = this._renderData.vDatas[0];
        var matrix = comp.node._worldMatrix;
        var matrixm = matrix.m, a = matrixm[0], b = matrixm[1], c = matrixm[4], d = matrixm[5], tx = matrixm[12], ty = matrixm[13];
        var vl = local[0], vr = local[2], vb = local[1], vt = local[3];
        /*
        m00 = 1, m01 = 0, m02 = 0, m03 = 0,
        m04 = 0, m05 = 1, m06 = 0, m07 = 0,
        m08 = 0, m09 = 0, m10 = 1, m11 = 0,
        m12 = 0, m13 = 0, m14 = 0, m15 = 1
        */
        // [a,b,c,d] = _worldMatrix[1,2,4,5] == [1,0,0,1]
        // _worldMatrix[12,13]是xy的平移量
        // 即世界矩阵的左上角2x2是单元矩阵，说明在2D场景内没有出现旋转或者缩放
        var justTranslate = a === 1 && b === 0 && c === 0 && d === 1;
        // render data = verts = x|y|u|v|color|x|y|u|v|color|...
        // 填充render data中4个顶点的xy部分
        var index = 0;
        var floatsPerVert = this.floatsPerVert;
        if (justTranslate) {
            // left bottom
            verts[index] = vl + tx;
            verts[index + 1] = vb + ty;
            index += floatsPerVert;
            // right bottom
            verts[index] = vr + tx;
            verts[index + 1] = vb + ty;
            index += floatsPerVert;
            // left top
            verts[index] = vl + tx;
            verts[index + 1] = vt + ty;
            index += floatsPerVert;
            // right top
            verts[index] = vr + tx;
            verts[index + 1] = vt + ty;
        }
        else {
            // 4对xy分别乘以 [2,2]仿射矩阵，然后+平移量
            var al = a * vl, ar = a * vr, bl = b * vl, br = b * vr, cb = c * vb, ct = c * vt, db = d * vb, dt = d * vt;
            // left bottom
            // newx = vl * a + vb * c + tx
            // newy = vl * b + vb * d + ty
            verts[index] = al + cb + tx;
            verts[index + 1] = bl + db + ty;
            index += floatsPerVert;
            // right bottom
            verts[index] = ar + cb + tx;
            verts[index + 1] = br + db + ty;
            index += floatsPerVert;
            // left top
            verts[index] = al + ct + tx;
            verts[index + 1] = bl + dt + ty;
            index += floatsPerVert;
            // right top
            verts[index] = ar + ct + tx;
            verts[index + 1] = br + dt + ty;
        }
    };
    // native场景下使用的updateWorldVerts
    // copy from \jsb-adapter-master\engine\assemblers\assembler-2d.js
    GTAssembler2D.prototype.updateWorldVertsNative = function (comp) {
        var local = this._local;
        var verts = this._renderData.vDatas[0];
        var floatsPerVert = this.floatsPerVert;
        var vl = local[0], vr = local[2], vb = local[1], vt = local[3];
        var index = 0;
        // left bottom
        verts[index] = vl;
        verts[index + 1] = vb;
        index += floatsPerVert;
        // right bottom
        verts[index] = vr;
        verts[index + 1] = vb;
        index += floatsPerVert;
        // left top
        verts[index] = vl;
        verts[index + 1] = vt;
        index += floatsPerVert;
        // right top
        verts[index] = vr;
        verts[index + 1] = vt;
    };
    // 将准备好的顶点数据填充进 VertexBuffer 和 IndiceBuffer
    GTAssembler2D.prototype.fillBuffers = function (comp, renderer) {
        if (renderer.worldMatDirty) {
            this.updateWorldVerts(comp);
        }
        var renderData = this._renderData;
        var vData = renderData.vDatas[0];
        var iData = renderData.iDatas[0];
        var buffer = this.getBuffer( /*renderer*/);
        var offsetInfo = buffer.request(this.verticesCount, this.indicesCount);
        // buffer data may be realloc, need get reference after request.
        // fill vertices
        var vertexOffset = offsetInfo.byteOffset >> 2, vbuf = buffer._vData;
        if (vData.length + vertexOffset > vbuf.length) {
            vbuf.set(vData.subarray(0, vbuf.length - vertexOffset), vertexOffset);
        }
        else {
            vbuf.set(vData, vertexOffset);
        }
        // fill indices
        var ibuf = buffer._iData, indiceOffset = offsetInfo.indiceOffset, vertexId = offsetInfo.vertexOffset; // vertexId是已经在buffer里的顶点数，也是当前顶点序号的基数
        for (var i = 0, l = iData.length; i < l; i++) {
            ibuf[indiceOffset++] = vertexId + iData[i];
        }
    };
    GTAssembler2D.prototype.packToDynamicAtlas = function (comp, frame) {
        if (CC_TEST)
            return;
        if (!frame._original && cc.dynamicAtlasManager && frame._texture.packable) {
            var packedFrame = cc.dynamicAtlasManager.insertSpriteFrame(frame);
            //@ts-ignore
            if (packedFrame) {
                frame._setDynamicAtlasFrame(packedFrame);
            }
        }
        var material = comp._materials[0];
        if (!material)
            return;
        if (material.getProperty('texture') !== frame._texture) {
            // texture was packed to dynamic atlas, should update uvs
            comp._vertsDirty = true;
            comp._updateMaterial();
        }
    };
    GTAssembler2D.prototype.updateUVs = function (comp) {
        // 4个顶点的uv坐标，对应左下、右下、左上、右上
        // 如果是cc.Sprite组件，这里取sprite._spriteFrame.uv;
        var uv = [0, 0, 1, 0, 0, 1, 1, 1];
        var uvOffset = this.uvOffset;
        var floatsPerVert = this.floatsPerVert;
        var verts = this._renderData.vDatas[0];
        // render data = verts = x|y|u|v|color|x|y|u|v|color|...
        // 填充render data中4个顶点的uv部分
        for (var i = 0; i < 4; i++) {
            var srcOffset = i * 2;
            var dstOffset = floatsPerVert * i + uvOffset;
            verts[dstOffset] = uv[srcOffset];
            verts[dstOffset + 1] = uv[srcOffset + 1];
        }
    };
    GTAssembler2D.prototype.updateVerts = function (comp) {
        var node = comp.node, cw = node.width, ch = node.height, appx = node.anchorX * cw, appy = node.anchorY * ch, l, b, r, t;
        l = -appx;
        b = -appy;
        r = cw - appx;
        t = ch - appy;
        var local = this._local;
        local[0] = l;
        local[1] = b;
        local[2] = r;
        local[3] = t;
        this.updateWorldVerts(comp);
    };
    GTAssembler2D.prototype.updateRenderData = function (comp) {
        if (comp._vertsDirty) {
            this.updateUVs(comp);
            this.updateVerts(comp);
            comp._vertsDirty = false;
        }
    };
    return GTAssembler2D;
}(cc.Assembler));
exports.default = GTAssembler2D;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvR1RBc3NlbWJsZXIyRC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsZ0RBQWdEO0FBQ2hELDRCQUE0QjtBQUM1QiwrQ0FBK0M7QUFDL0MsZ0VBQWdFOzs7Ozs7Ozs7Ozs7Ozs7QUFFaEU7Ozs7RUFJRTtBQUVGLFFBQVE7QUFDUixvSEFBb0g7QUFDcEg7SUFBMkMsaUNBQVk7SUFBdkQ7UUFDSSxlQUFlO1FBQ2YsV0FBVztRQUNYLHVCQUF1QjtRQUgzQixxRUEyUkM7UUF0UkcsbUJBQW1CO1FBQ25CLFVBQVU7UUFDViw4Q0FBOEM7UUFDOUMsd0VBQXdFO1FBQ3hFLG1FQUFtRTtRQUNuRSxxR0FBcUc7UUFDckcsTUFBTTtRQUNOLG9DQUFvQztRQUNwQyxrQ0FBa0M7UUFDbEMsNkJBQTZCO1FBQzdCLG1CQUFhLEdBQUcsQ0FBQyxDQUFDO1FBQ2xCLGtCQUFZLEdBQUcsQ0FBQyxDQUFDO1FBQ2pCLG1CQUFhLEdBQUcsQ0FBQyxDQUFDO1FBRWxCLG9CQUFvQjtRQUNwQixjQUFRLEdBQUcsQ0FBQyxDQUFDO1FBQ2IsaUJBQVcsR0FBRyxDQUFDLENBQUM7UUFFTixpQkFBVyxHQUFrQixJQUFJLENBQUM7UUFDbEMsWUFBTSxHQUFRLElBQUksQ0FBQyxDQUFVLDhDQUE4Qzs7SUFtUXpGLENBQUM7SUFqUUcsNEJBQUksR0FBSixVQUFLLElBQXdCO1FBQ3pCLGlCQUFNLElBQUksWUFBQyxJQUFJLENBQUMsQ0FBQztRQUVqQixtQ0FBbUM7UUFDbkMsOEJBQThCO1FBQzlCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxFQUFFLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDdkMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFNUIsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBRUQsc0JBQUkseUNBQWM7YUFBbEI7WUFDSSxPQUFPLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUNuRCxDQUFDOzs7T0FBQTtJQUVELGdDQUFRLEdBQVI7UUFDSSxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDO1FBQzVCLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQy9ELDRDQUE0QztRQUM1Qyw0QkFBNEI7SUFDaEMsQ0FBQztJQUVELGlDQUFTLEdBQVQ7UUFDSSxJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztRQUNqQixJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7SUFDM0IsQ0FBQztJQUVELG1DQUFXLEdBQVgsVUFBWSxJQUFJLEVBQUUsS0FBSztRQUNuQix3REFBd0Q7UUFDeEQsNkJBQTZCO1FBQzdCLElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQy9DLElBQUksQ0FBQyxTQUFTO1lBQUUsT0FBTztRQUN2QixLQUFLLEdBQUcsS0FBSyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7UUFDckQsSUFBSSxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUN2QyxJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDO1FBQ25DLEtBQUssSUFBSSxDQUFDLEdBQUcsV0FBVyxFQUFFLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLGFBQWEsRUFBRTtZQUN2RSxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDO1NBQ3hCO0lBQ0wsQ0FBQztJQUVELGlDQUFTLEdBQVQ7UUFDSSxZQUFZO1FBQ1osT0FBTyxFQUFFLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUM7SUFDM0MsQ0FBQztJQUVELHdDQUFnQixHQUFoQixVQUFpQixJQUFJO1FBQ2pCLElBQUksaUJBQWlCLEVBQUU7WUFDbkIsSUFBSSxDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3JDO2FBQU07WUFDSCxJQUFJLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDcEM7SUFDTCxDQUFDO0lBRUQsNkNBQXFCLEdBQXJCLFVBQXNCLElBQUk7UUFDdEIsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUN4QixJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUV2QyxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztRQUNwQyxJQUFJLE9BQU8sR0FBRyxNQUFNLENBQUMsQ0FBQyxFQUNsQixDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUM5RCxFQUFFLEdBQUcsT0FBTyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsR0FBRyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7UUFFdkMsSUFBSSxFQUFFLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQzVCLEVBQUUsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVqQzs7Ozs7VUFLRTtRQUNGLGlEQUFpRDtRQUNqRCw2QkFBNkI7UUFDN0IsdUNBQXVDO1FBQ3ZDLElBQUksYUFBYSxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFN0Qsd0RBQXdEO1FBQ3hELDBCQUEwQjtRQUMxQixJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7UUFDZCxJQUFJLGFBQWEsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1FBQ3ZDLElBQUksYUFBYSxFQUFFO1lBQ2YsY0FBYztZQUNkLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDO1lBQ3ZCLEtBQUssQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztZQUN6QixLQUFLLElBQUksYUFBYSxDQUFDO1lBQ3ZCLGVBQWU7WUFDZixLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztZQUN2QixLQUFLLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7WUFDekIsS0FBSyxJQUFJLGFBQWEsQ0FBQztZQUN2QixXQUFXO1lBQ1gsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7WUFDdkIsS0FBSyxDQUFDLEtBQUssR0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDO1lBQ3pCLEtBQUssSUFBSSxhQUFhLENBQUM7WUFDdkIsWUFBWTtZQUNaLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDO1lBQ3ZCLEtBQUssQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztTQUM1QjthQUFNO1lBQ0gsNEJBQTRCO1lBQzVCLElBQUksRUFBRSxHQUFHLENBQUMsR0FBRyxFQUFFLEVBQUUsRUFBRSxHQUFHLENBQUMsR0FBRyxFQUFFLEVBQzVCLEVBQUUsR0FBRyxDQUFDLEdBQUcsRUFBRSxFQUFFLEVBQUUsR0FBRyxDQUFDLEdBQUcsRUFBRSxFQUN4QixFQUFFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsRUFBRSxFQUFFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsRUFDeEIsRUFBRSxHQUFHLENBQUMsR0FBRyxFQUFFLEVBQUUsRUFBRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUM7WUFFekIsY0FBYztZQUNkLDhCQUE4QjtZQUM5Qiw4QkFBOEI7WUFDOUIsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDO1lBQzVCLEtBQUssQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7WUFDOUIsS0FBSyxJQUFJLGFBQWEsQ0FBQztZQUN2QixlQUFlO1lBQ2YsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDO1lBQzVCLEtBQUssQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7WUFDOUIsS0FBSyxJQUFJLGFBQWEsQ0FBQztZQUN2QixXQUFXO1lBQ1gsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDO1lBQzVCLEtBQUssQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7WUFDOUIsS0FBSyxJQUFJLGFBQWEsQ0FBQztZQUN2QixZQUFZO1lBQ1osS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDO1lBQzVCLEtBQUssQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7U0FDakM7SUFDTCxDQUFDO0lBRUQsK0JBQStCO0lBQy9CLGtFQUFrRTtJQUNsRSw4Q0FBc0IsR0FBdEIsVUFBdUIsSUFBSTtRQUN2QixJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQ3hCLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDLElBQUksYUFBYSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7UUFFdkMsSUFBSSxFQUFFLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUNiLEVBQUUsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQ2IsRUFBRSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFDYixFQUFFLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRWxCLElBQUksS0FBSyxHQUFXLENBQUMsQ0FBQztRQUN0QixjQUFjO1FBQ2QsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUNsQixLQUFLLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUNwQixLQUFLLElBQUksYUFBYSxDQUFDO1FBQ3ZCLGVBQWU7UUFDZixLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ2xCLEtBQUssQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ3BCLEtBQUssSUFBSSxhQUFhLENBQUM7UUFDdkIsV0FBVztRQUNYLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUM7UUFDbEIsS0FBSyxDQUFDLEtBQUssR0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7UUFDcEIsS0FBSyxJQUFJLGFBQWEsQ0FBQztRQUN2QixZQUFZO1FBQ1osS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUNsQixLQUFLLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztJQUN4QixDQUFDO0lBRUQsMkNBQTJDO0lBQzNDLG1DQUFXLEdBQVgsVUFBWSxJQUFJLEVBQUUsUUFBUTtRQUN0QixJQUFJLFFBQVEsQ0FBQyxhQUFhLEVBQUU7WUFDeEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDO1NBQy9CO1FBRUQsSUFBSSxVQUFVLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQztRQUNsQyxJQUFJLEtBQUssR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ2pDLElBQUksS0FBSyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFakMsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLFNBQVMsRUFBQyxZQUFZLENBQUMsQ0FBQztRQUMxQyxJQUFJLFVBQVUsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBRXZFLGdFQUFnRTtRQUVoRSxnQkFBZ0I7UUFDaEIsSUFBSSxZQUFZLEdBQUcsVUFBVSxDQUFDLFVBQVUsSUFBSSxDQUFDLEVBQ3pDLElBQUksR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDO1FBRXpCLElBQUksS0FBSyxDQUFDLE1BQU0sR0FBRyxZQUFZLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUMzQyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLEdBQUcsWUFBWSxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUM7U0FDekU7YUFBTTtZQUNILElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLFlBQVksQ0FBQyxDQUFDO1NBQ2pDO1FBRUQsZUFBZTtRQUNmLElBQUksSUFBSSxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQ3BCLFlBQVksR0FBRyxVQUFVLENBQUMsWUFBWSxFQUN0QyxRQUFRLEdBQUcsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFhLHNDQUFzQztRQUMxRixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzFDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxHQUFHLFFBQVEsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDOUM7SUFDTCxDQUFDO0lBRUQsMENBQWtCLEdBQWxCLFVBQW1CLElBQUksRUFBRSxLQUFLO1FBQzFCLElBQUksT0FBTztZQUFFLE9BQU87UUFFcEIsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLElBQUksRUFBRSxDQUFDLG1CQUFtQixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFO1lBQ3ZFLElBQUksV0FBVyxHQUFHLEVBQUUsQ0FBQyxtQkFBbUIsQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNsRSxZQUFZO1lBQ1osSUFBSSxXQUFXLEVBQUU7Z0JBQ2IsS0FBSyxDQUFDLHFCQUFxQixDQUFDLFdBQVcsQ0FBQyxDQUFDO2FBQzVDO1NBQ0o7UUFDRCxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ2xDLElBQUksQ0FBQyxRQUFRO1lBQUUsT0FBTztRQUV0QixJQUFJLFFBQVEsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLEtBQUssS0FBSyxDQUFDLFFBQVEsRUFBRTtZQUNwRCx5REFBeUQ7WUFDekQsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7WUFDeEIsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1NBQzFCO0lBQ0wsQ0FBQztJQUVTLGlDQUFTLEdBQW5CLFVBQW9CLElBQXdCO1FBQ3hDLDBCQUEwQjtRQUMxQiw0Q0FBNEM7UUFDNUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDbEMsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQztRQUM3QixJQUFJLGFBQWEsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1FBQ3ZDLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRXZDLHdEQUF3RDtRQUN4RCwwQkFBMEI7UUFDMUIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUN4QixJQUFJLFNBQVMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3RCLElBQUksU0FBUyxHQUFHLGFBQWEsR0FBRyxDQUFDLEdBQUcsUUFBUSxDQUFDO1lBQzdDLEtBQUssQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDakMsS0FBSyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxDQUFDO1NBQzVDO0lBQ0wsQ0FBQztJQUVTLG1DQUFXLEdBQXJCLFVBQXNCLElBQXdCO1FBQzFDLElBQUksSUFBSSxHQUFZLElBQUksQ0FBQyxJQUFJLEVBQ3pCLEVBQUUsR0FBVyxJQUFJLENBQUMsS0FBSyxFQUN2QixFQUFFLEdBQVcsSUFBSSxDQUFDLE1BQU0sRUFDeEIsSUFBSSxHQUFXLElBQUksQ0FBQyxPQUFPLEdBQUcsRUFBRSxFQUNoQyxJQUFJLEdBQVcsSUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLEVBQ2hDLENBQVMsRUFDVCxDQUFTLEVBQ1QsQ0FBUyxFQUNULENBQVMsQ0FBQztRQUVkLENBQUMsR0FBRyxDQUFFLElBQUksQ0FBQztRQUNYLENBQUMsR0FBRyxDQUFFLElBQUksQ0FBQztRQUNYLENBQUMsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDO1FBQ2QsQ0FBQyxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFFZCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQ3hCLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDYixLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2IsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNiLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDYixJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDaEMsQ0FBQztJQUVTLHdDQUFnQixHQUExQixVQUEyQixJQUF3QjtRQUMvQyxJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUU7WUFDbEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNyQixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO1NBQzVCO0lBQ0wsQ0FBQztJQUNMLG9CQUFDO0FBQUQsQ0EzUkEsQUEyUkMsQ0EzUjBDLEVBQUUsQ0FBQyxTQUFTLEdBMlJ0RCIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIENvcHlyaWdodCAyMDIwIENhbyBHYW90aW5nPGNhb2d0YWFAZ21haWwuY29tPlxuLy8gaHR0cHM6Ly9jYW9ndGFhLmdpdGh1Yi5pb1xuLy8gVGhpcyBmaWxlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS5cbi8vIExpY2Vuc2UgdGV4dCBhdmFpbGFibGUgYXQgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVRcblxuLypcbiAqIERhdGU6IDIwMjAtMDctMTMgMDI6NDQ6MTdcbiAqIExhc3RFZGl0b3JzOiBHVDxjYW9ndGFhQGdtYWlsLmNvbT5cbiAqIExhc3RFZGl0VGltZTogMjAyMC0wNy0yMiAxNDowNDo0M1xuKi8gXG5cbi8vIOiHquWumuS5iea4suafk1xuLy8gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9hZHZhbmNlZC10b3BpY3MvY3VzdG9tLXJlbmRlci5odG1sIyVFOCU4NyVBQSVFNSVBRSU5QSVFNCVCOSU4OS1hc3NlbWJsZXJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEdUQXNzZW1ibGVyMkQgZXh0ZW5kcyBjYy5Bc3NlbWJsZXIge1xuICAgIC8vIOavj+S4qjJk5riy5p+T5Y2V5YWD6YeM55qE5pyJOlxuICAgIC8vIDTkuKrpobbngrnlsZ7mgKfmlbDmja5cbiAgICAvLyA25Liq6aG254K557Si5byVIC0+IOS4ieinkuWJluWIhuaIkDLkuKrkuInop5LlvaJcblxuICAgIC8vIOavj+S4qumhtueCueWxnuaAp+eUsTXkuKozMuS9jeaVsOaNrue7hOaIkFxuICAgIC8vIOmhtueCueWxnuaAp+WjsOaYjjpcbiAgICAvLyB2YXIgdmZtdFBvc1V2Q29sb3IgPSBuZXcgZ2Z4LlZlcnRleEZvcm1hdChbXG4gICAgLy8gICAgIHsgbmFtZTogZ2Z4LkFUVFJfUE9TSVRJT04sIHR5cGU6IGdmeC5BVFRSX1RZUEVfRkxPQVQzMiwgbnVtOiAyIH0sXG4gICAgLy8gICAgIHsgbmFtZTogZ2Z4LkFUVFJfVVYwLCB0eXBlOiBnZnguQVRUUl9UWVBFX0ZMT0FUMzIsIG51bTogMiB9LFxuICAgIC8vICAgICB7IG5hbWU6IGdmeC5BVFRSX0NPTE9SLCB0eXBlOiBnZnguQVRUUl9UWVBFX1VJTlQ4LCBudW06IDQsIG5vcm1hbGl6ZTogdHJ1ZSB9LCAgICAgICAvLyA05LiqdWludDhcbiAgICAvLyBdKTtcbiAgICAvLyDpobbngrnlsZ7mgKfmlbDmja7mjpLliJfvvIzmr4/kuIDmoLzmmK8zMuS9jSAoZmxvYXQzMi91aW50MzIpXG4gICAgLy8geHx5fHV8dnxjb2xvcnx4fHl8dXx2fGNvbG9yfC4uLlxuICAgIC8vIOWFtuS4rXV25Zyo5LiA57uE5pWw5o2u5Lit55qE5YGP56e75pivMu+8jGNvbG9y55qE5YGP56e75pivNFxuICAgIHZlcnRpY2VzQ291bnQgPSA0O1xuICAgIGluZGljZXNDb3VudCA9IDY7XG4gICAgZmxvYXRzUGVyVmVydCA9IDU7XG5cbiAgICAvLyB2ZGF0YSBvZmZzZXQgaW5mb1xuICAgIHV2T2Zmc2V0ID0gMjtcbiAgICBjb2xvck9mZnNldCA9IDQ7XG4gICAgXG4gICAgcHJvdGVjdGVkIF9yZW5kZXJEYXRhOiBjYy5SZW5kZXJEYXRhID0gbnVsbDtcbiAgICBwcm90ZWN0ZWQgX2xvY2FsOiBhbnkgPSBudWxsOyAgICAgICAgICAvLyDkuK3pl7Tnu5PmnpzjgIJbbCxiLHIsdF3jgIJub2Rl5a+56LGh5bem5LiL44CB5Y+z5LiK6aG254K555qE5pys5Zyw5Z2Q5qCH77yM5Y2z55u45a+55LqO6ZSa54K555qE5YGP56e7XG5cbiAgICBpbml0KGNvbXA6IGNjLlJlbmRlckNvbXBvbmVudCkge1xuICAgICAgICBzdXBlci5pbml0KGNvbXApO1xuXG4gICAgICAgIC8vIGNjLkFzc2VtYmxlcjJE55qE5Yid5aeL5YyW5pS+5ZyoY29uc3RydWN0b3Lph4xcbiAgICAgICAgLy8g5q2k5aSE5oqK5Yid5aeL5YyW5pS+5ZyoaW5pdOmHjO+8jOS7peS+v+aIkOWRmOWPmOmHj+iDveWkn+acieacuuS8muS/ruaUuVxuICAgICAgICB0aGlzLl9yZW5kZXJEYXRhID0gbmV3IGNjLlJlbmRlckRhdGEoKTtcbiAgICAgICAgdGhpcy5fcmVuZGVyRGF0YS5pbml0KHRoaXMpO1xuXG4gICAgICAgIHRoaXMuaW5pdExvY2FsKCk7XG4gICAgICAgIHRoaXMuaW5pdERhdGEoKTtcbiAgICB9XG5cbiAgICBnZXQgdmVydGljZXNGbG9hdHMoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnZlcnRpY2VzQ291bnQgKiB0aGlzLmZsb2F0c1BlclZlcnQ7XG4gICAgfVxuXG4gICAgaW5pdERhdGEoKSB7XG4gICAgICAgIGxldCBkYXRhID0gdGhpcy5fcmVuZGVyRGF0YTtcbiAgICAgICAgZGF0YS5jcmVhdGVRdWFkRGF0YSgwLCB0aGlzLnZlcnRpY2VzRmxvYXRzLCB0aGlzLmluZGljZXNDb3VudCk7XG4gICAgICAgIC8vIGNyZWF0ZVF1YWREYXRh5YaF6YOo5Lya6LCD55SoaW5pdFF1YWRJbmRpY2Vz5Yid5aeL5YyW57Si5byV5L+h5oGvXG4gICAgICAgIC8vIOWmguaenOaYr+eUqOeUqGZsZXhidWZmZXLliJvlu7rliJnpnIDopoHoh6rlt7HliJ3lp4vljJZcbiAgICB9XG5cbiAgICBpbml0TG9jYWwoKSB7XG4gICAgICAgIHRoaXMuX2xvY2FsID0gW107XG4gICAgICAgIHRoaXMuX2xvY2FsLmxlbmd0aCA9IDQ7XG4gICAgfVxuXG4gICAgdXBkYXRlQ29sb3IoY29tcCwgY29sb3IpIHtcbiAgICAgICAgLy8gcmVuZGVyIGRhdGEgPSB2ZXJ0cyA9IHh8eXx1fHZ8Y29sb3J8eHx5fHV8dnxjb2xvcnwuLi5cbiAgICAgICAgLy8g5aGr5YWFcmVuZGVyIGRhdGHkuK005Liq6aG254K555qEY29sb3Lpg6jliIZcbiAgICAgICAgbGV0IHVpbnRWZXJ0cyA9IHRoaXMuX3JlbmRlckRhdGEudWludFZEYXRhc1swXTtcbiAgICAgICAgaWYgKCF1aW50VmVydHMpIHJldHVybjtcbiAgICAgICAgY29sb3IgPSBjb2xvciAhPSBudWxsID8gY29sb3IgOiBjb21wLm5vZGUuY29sb3IuX3ZhbDtcbiAgICAgICAgbGV0IGZsb2F0c1BlclZlcnQgPSB0aGlzLmZsb2F0c1BlclZlcnQ7XG4gICAgICAgIGxldCBjb2xvck9mZnNldCA9IHRoaXMuY29sb3JPZmZzZXQ7XG4gICAgICAgIGZvciAobGV0IGkgPSBjb2xvck9mZnNldCwgbCA9IHVpbnRWZXJ0cy5sZW5ndGg7IGkgPCBsOyBpICs9IGZsb2F0c1BlclZlcnQpIHtcbiAgICAgICAgICAgIHVpbnRWZXJ0c1tpXSA9IGNvbG9yO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgZ2V0QnVmZmVyKCkge1xuICAgICAgICAvL0B0cy1pZ25vcmVcbiAgICAgICAgcmV0dXJuIGNjLnJlbmRlcmVyLl9oYW5kbGUuX21lc2hCdWZmZXI7XG4gICAgfVxuXG4gICAgdXBkYXRlV29ybGRWZXJ0cyhjb21wKSB7XG4gICAgICAgIGlmIChDQ19OQVRJVkVSRU5ERVJFUikge1xuICAgICAgICAgICAgdGhpcy51cGRhdGVXb3JsZFZlcnRzTmF0aXZlKGNvbXApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy51cGRhdGVXb3JsZFZlcnRzV2ViR0woY29tcCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICB1cGRhdGVXb3JsZFZlcnRzV2ViR0woY29tcCkge1xuICAgICAgICBsZXQgbG9jYWwgPSB0aGlzLl9sb2NhbDtcbiAgICAgICAgbGV0IHZlcnRzID0gdGhpcy5fcmVuZGVyRGF0YS52RGF0YXNbMF07XG5cbiAgICAgICAgbGV0IG1hdHJpeCA9IGNvbXAubm9kZS5fd29ybGRNYXRyaXg7XG4gICAgICAgIGxldCBtYXRyaXhtID0gbWF0cml4Lm0sXG4gICAgICAgICAgICBhID0gbWF0cml4bVswXSwgYiA9IG1hdHJpeG1bMV0sIGMgPSBtYXRyaXhtWzRdLCBkID0gbWF0cml4bVs1XSxcbiAgICAgICAgICAgIHR4ID0gbWF0cml4bVsxMl0sIHR5ID0gbWF0cml4bVsxM107XG5cbiAgICAgICAgbGV0IHZsID0gbG9jYWxbMF0sIHZyID0gbG9jYWxbMl0sXG4gICAgICAgICAgICB2YiA9IGxvY2FsWzFdLCB2dCA9IGxvY2FsWzNdO1xuICAgICAgICBcbiAgICAgICAgLypcbiAgICAgICAgbTAwID0gMSwgbTAxID0gMCwgbTAyID0gMCwgbTAzID0gMCxcbiAgICAgICAgbTA0ID0gMCwgbTA1ID0gMSwgbTA2ID0gMCwgbTA3ID0gMCxcbiAgICAgICAgbTA4ID0gMCwgbTA5ID0gMCwgbTEwID0gMSwgbTExID0gMCxcbiAgICAgICAgbTEyID0gMCwgbTEzID0gMCwgbTE0ID0gMCwgbTE1ID0gMVxuICAgICAgICAqL1xuICAgICAgICAvLyBbYSxiLGMsZF0gPSBfd29ybGRNYXRyaXhbMSwyLDQsNV0gPT0gWzEsMCwwLDFdXG4gICAgICAgIC8vIF93b3JsZE1hdHJpeFsxMiwxM13mmK94eeeahOW5s+enu+mHj1xuICAgICAgICAvLyDljbPkuJbnlYznn6npmLXnmoTlt6bkuIrop5IyeDLmmK/ljZXlhYPnn6npmLXvvIzor7TmmI7lnKgyROWcuuaZr+WGheayoeacieWHuueOsOaXi+i9rOaIluiAhee8qeaUvlxuICAgICAgICBsZXQganVzdFRyYW5zbGF0ZSA9IGEgPT09IDEgJiYgYiA9PT0gMCAmJiBjID09PSAwICYmIGQgPT09IDE7XG5cbiAgICAgICAgLy8gcmVuZGVyIGRhdGEgPSB2ZXJ0cyA9IHh8eXx1fHZ8Y29sb3J8eHx5fHV8dnxjb2xvcnwuLi5cbiAgICAgICAgLy8g5aGr5YWFcmVuZGVyIGRhdGHkuK005Liq6aG254K555qEeHnpg6jliIZcbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgbGV0IGZsb2F0c1BlclZlcnQgPSB0aGlzLmZsb2F0c1BlclZlcnQ7XG4gICAgICAgIGlmIChqdXN0VHJhbnNsYXRlKSB7XG4gICAgICAgICAgICAvLyBsZWZ0IGJvdHRvbVxuICAgICAgICAgICAgdmVydHNbaW5kZXhdID0gdmwgKyB0eDtcbiAgICAgICAgICAgIHZlcnRzW2luZGV4KzFdID0gdmIgKyB0eTtcbiAgICAgICAgICAgIGluZGV4ICs9IGZsb2F0c1BlclZlcnQ7XG4gICAgICAgICAgICAvLyByaWdodCBib3R0b21cbiAgICAgICAgICAgIHZlcnRzW2luZGV4XSA9IHZyICsgdHg7XG4gICAgICAgICAgICB2ZXJ0c1tpbmRleCsxXSA9IHZiICsgdHk7XG4gICAgICAgICAgICBpbmRleCArPSBmbG9hdHNQZXJWZXJ0O1xuICAgICAgICAgICAgLy8gbGVmdCB0b3BcbiAgICAgICAgICAgIHZlcnRzW2luZGV4XSA9IHZsICsgdHg7XG4gICAgICAgICAgICB2ZXJ0c1tpbmRleCsxXSA9IHZ0ICsgdHk7XG4gICAgICAgICAgICBpbmRleCArPSBmbG9hdHNQZXJWZXJ0O1xuICAgICAgICAgICAgLy8gcmlnaHQgdG9wXG4gICAgICAgICAgICB2ZXJ0c1tpbmRleF0gPSB2ciArIHR4O1xuICAgICAgICAgICAgdmVydHNbaW5kZXgrMV0gPSB2dCArIHR5O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gNOWvuXh55YiG5Yir5LmY5LulIFsyLDJd5Lu/5bCE55+p6Zi177yM54S25ZCOK+W5s+enu+mHj1xuICAgICAgICAgICAgbGV0IGFsID0gYSAqIHZsLCBhciA9IGEgKiB2cixcbiAgICAgICAgICAgIGJsID0gYiAqIHZsLCBiciA9IGIgKiB2cixcbiAgICAgICAgICAgIGNiID0gYyAqIHZiLCBjdCA9IGMgKiB2dCxcbiAgICAgICAgICAgIGRiID0gZCAqIHZiLCBkdCA9IGQgKiB2dDtcblxuICAgICAgICAgICAgLy8gbGVmdCBib3R0b21cbiAgICAgICAgICAgIC8vIG5ld3ggPSB2bCAqIGEgKyB2YiAqIGMgKyB0eFxuICAgICAgICAgICAgLy8gbmV3eSA9IHZsICogYiArIHZiICogZCArIHR5XG4gICAgICAgICAgICB2ZXJ0c1tpbmRleF0gPSBhbCArIGNiICsgdHg7XG4gICAgICAgICAgICB2ZXJ0c1tpbmRleCsxXSA9IGJsICsgZGIgKyB0eTtcbiAgICAgICAgICAgIGluZGV4ICs9IGZsb2F0c1BlclZlcnQ7XG4gICAgICAgICAgICAvLyByaWdodCBib3R0b21cbiAgICAgICAgICAgIHZlcnRzW2luZGV4XSA9IGFyICsgY2IgKyB0eDtcbiAgICAgICAgICAgIHZlcnRzW2luZGV4KzFdID0gYnIgKyBkYiArIHR5O1xuICAgICAgICAgICAgaW5kZXggKz0gZmxvYXRzUGVyVmVydDtcbiAgICAgICAgICAgIC8vIGxlZnQgdG9wXG4gICAgICAgICAgICB2ZXJ0c1tpbmRleF0gPSBhbCArIGN0ICsgdHg7XG4gICAgICAgICAgICB2ZXJ0c1tpbmRleCsxXSA9IGJsICsgZHQgKyB0eTtcbiAgICAgICAgICAgIGluZGV4ICs9IGZsb2F0c1BlclZlcnQ7XG4gICAgICAgICAgICAvLyByaWdodCB0b3BcbiAgICAgICAgICAgIHZlcnRzW2luZGV4XSA9IGFyICsgY3QgKyB0eDtcbiAgICAgICAgICAgIHZlcnRzW2luZGV4KzFdID0gYnIgKyBkdCArIHR5O1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLy8gbmF0aXZl5Zy65pmv5LiL5L2/55So55qEdXBkYXRlV29ybGRWZXJ0c1xuICAgIC8vIGNvcHkgZnJvbSBcXGpzYi1hZGFwdGVyLW1hc3RlclxcZW5naW5lXFxhc3NlbWJsZXJzXFxhc3NlbWJsZXItMmQuanNcbiAgICB1cGRhdGVXb3JsZFZlcnRzTmF0aXZlKGNvbXApIHtcbiAgICAgICAgbGV0IGxvY2FsID0gdGhpcy5fbG9jYWw7XG4gICAgICAgIGxldCB2ZXJ0cyA9IHRoaXMuX3JlbmRlckRhdGEudkRhdGFzWzBdO1xuICAgICAgICBsZXQgZmxvYXRzUGVyVmVydCA9IHRoaXMuZmxvYXRzUGVyVmVydDtcbiAgICAgIFxuICAgICAgICBsZXQgdmwgPSBsb2NhbFswXSxcbiAgICAgICAgICAgIHZyID0gbG9jYWxbMl0sXG4gICAgICAgICAgICB2YiA9IGxvY2FsWzFdLFxuICAgICAgICAgICAgdnQgPSBsb2NhbFszXTtcbiAgICAgIFxuICAgICAgICBsZXQgaW5kZXg6IG51bWJlciA9IDA7XG4gICAgICAgIC8vIGxlZnQgYm90dG9tXG4gICAgICAgIHZlcnRzW2luZGV4XSA9IHZsO1xuICAgICAgICB2ZXJ0c1tpbmRleCsxXSA9IHZiO1xuICAgICAgICBpbmRleCArPSBmbG9hdHNQZXJWZXJ0O1xuICAgICAgICAvLyByaWdodCBib3R0b21cbiAgICAgICAgdmVydHNbaW5kZXhdID0gdnI7XG4gICAgICAgIHZlcnRzW2luZGV4KzFdID0gdmI7XG4gICAgICAgIGluZGV4ICs9IGZsb2F0c1BlclZlcnQ7XG4gICAgICAgIC8vIGxlZnQgdG9wXG4gICAgICAgIHZlcnRzW2luZGV4XSA9IHZsO1xuICAgICAgICB2ZXJ0c1tpbmRleCsxXSA9IHZ0O1xuICAgICAgICBpbmRleCArPSBmbG9hdHNQZXJWZXJ0O1xuICAgICAgICAvLyByaWdodCB0b3BcbiAgICAgICAgdmVydHNbaW5kZXhdID0gdnI7XG4gICAgICAgIHZlcnRzW2luZGV4KzFdID0gdnQ7XG4gICAgfVxuXG4gICAgLy8g5bCG5YeG5aSH5aW955qE6aG254K55pWw5o2u5aGr5YWF6L+bIFZlcnRleEJ1ZmZlciDlkowgSW5kaWNlQnVmZmVyXG4gICAgZmlsbEJ1ZmZlcnMoY29tcCwgcmVuZGVyZXIpIHtcbiAgICAgICAgaWYgKHJlbmRlcmVyLndvcmxkTWF0RGlydHkpIHtcbiAgICAgICAgICAgIHRoaXMudXBkYXRlV29ybGRWZXJ0cyhjb21wKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGxldCByZW5kZXJEYXRhID0gdGhpcy5fcmVuZGVyRGF0YTtcbiAgICAgICAgbGV0IHZEYXRhID0gcmVuZGVyRGF0YS52RGF0YXNbMF07XG4gICAgICAgIGxldCBpRGF0YSA9IHJlbmRlckRhdGEuaURhdGFzWzBdO1xuXG4gICAgICAgIGxldCBidWZmZXIgPSB0aGlzLmdldEJ1ZmZlcigvKnJlbmRlcmVyKi8pO1xuICAgICAgICBsZXQgb2Zmc2V0SW5mbyA9IGJ1ZmZlci5yZXF1ZXN0KHRoaXMudmVydGljZXNDb3VudCwgdGhpcy5pbmRpY2VzQ291bnQpO1xuXG4gICAgICAgIC8vIGJ1ZmZlciBkYXRhIG1heSBiZSByZWFsbG9jLCBuZWVkIGdldCByZWZlcmVuY2UgYWZ0ZXIgcmVxdWVzdC5cblxuICAgICAgICAvLyBmaWxsIHZlcnRpY2VzXG4gICAgICAgIGxldCB2ZXJ0ZXhPZmZzZXQgPSBvZmZzZXRJbmZvLmJ5dGVPZmZzZXQgPj4gMixcbiAgICAgICAgICAgIHZidWYgPSBidWZmZXIuX3ZEYXRhO1xuXG4gICAgICAgIGlmICh2RGF0YS5sZW5ndGggKyB2ZXJ0ZXhPZmZzZXQgPiB2YnVmLmxlbmd0aCkge1xuICAgICAgICAgICAgdmJ1Zi5zZXQodkRhdGEuc3ViYXJyYXkoMCwgdmJ1Zi5sZW5ndGggLSB2ZXJ0ZXhPZmZzZXQpLCB2ZXJ0ZXhPZmZzZXQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdmJ1Zi5zZXQodkRhdGEsIHZlcnRleE9mZnNldCk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBmaWxsIGluZGljZXNcbiAgICAgICAgbGV0IGlidWYgPSBidWZmZXIuX2lEYXRhLFxuICAgICAgICAgICAgaW5kaWNlT2Zmc2V0ID0gb2Zmc2V0SW5mby5pbmRpY2VPZmZzZXQsXG4gICAgICAgICAgICB2ZXJ0ZXhJZCA9IG9mZnNldEluZm8udmVydGV4T2Zmc2V0OyAgICAgICAgICAgICAvLyB2ZXJ0ZXhJZOaYr+W3sue7j+WcqGJ1ZmZlcumHjOeahOmhtueCueaVsO+8jOS5n+aYr+W9k+WJjemhtueCueW6j+WPt+eahOWfuuaVsFxuICAgICAgICBmb3IgKGxldCBpID0gMCwgbCA9IGlEYXRhLmxlbmd0aDsgaSA8IGw7IGkrKykge1xuICAgICAgICAgICAgaWJ1ZltpbmRpY2VPZmZzZXQrK10gPSB2ZXJ0ZXhJZCArIGlEYXRhW2ldO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcGFja1RvRHluYW1pY0F0bGFzKGNvbXAsIGZyYW1lKSB7XG4gICAgICAgIGlmIChDQ19URVNUKSByZXR1cm47XG4gICAgICAgIFxuICAgICAgICBpZiAoIWZyYW1lLl9vcmlnaW5hbCAmJiBjYy5keW5hbWljQXRsYXNNYW5hZ2VyICYmIGZyYW1lLl90ZXh0dXJlLnBhY2thYmxlKSB7XG4gICAgICAgICAgICBsZXQgcGFja2VkRnJhbWUgPSBjYy5keW5hbWljQXRsYXNNYW5hZ2VyLmluc2VydFNwcml0ZUZyYW1lKGZyYW1lKTtcbiAgICAgICAgICAgIC8vQHRzLWlnbm9yZVxuICAgICAgICAgICAgaWYgKHBhY2tlZEZyYW1lKSB7XG4gICAgICAgICAgICAgICAgZnJhbWUuX3NldER5bmFtaWNBdGxhc0ZyYW1lKHBhY2tlZEZyYW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBsZXQgbWF0ZXJpYWwgPSBjb21wLl9tYXRlcmlhbHNbMF07XG4gICAgICAgIGlmICghbWF0ZXJpYWwpIHJldHVybjtcbiAgICAgICAgXG4gICAgICAgIGlmIChtYXRlcmlhbC5nZXRQcm9wZXJ0eSgndGV4dHVyZScpICE9PSBmcmFtZS5fdGV4dHVyZSkge1xuICAgICAgICAgICAgLy8gdGV4dHVyZSB3YXMgcGFja2VkIHRvIGR5bmFtaWMgYXRsYXMsIHNob3VsZCB1cGRhdGUgdXZzXG4gICAgICAgICAgICBjb21wLl92ZXJ0c0RpcnR5ID0gdHJ1ZTtcbiAgICAgICAgICAgIGNvbXAuX3VwZGF0ZU1hdGVyaWFsKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwcm90ZWN0ZWQgdXBkYXRlVVZzKGNvbXA6IGNjLlJlbmRlckNvbXBvbmVudCkge1xuICAgICAgICAvLyA05Liq6aG254K555qEdXblnZDmoIfvvIzlr7nlupTlt6bkuIvjgIHlj7PkuIvjgIHlt6bkuIrjgIHlj7PkuIpcbiAgICAgICAgLy8g5aaC5p6c5pivY2MuU3ByaXRl57uE5Lu277yM6L+Z6YeM5Y+Wc3ByaXRlLl9zcHJpdGVGcmFtZS51djtcbiAgICAgICAgbGV0IHV2ID0gWzAsIDAsIDEsIDAsIDAsIDEsIDEsIDFdO1xuICAgICAgICBsZXQgdXZPZmZzZXQgPSB0aGlzLnV2T2Zmc2V0O1xuICAgICAgICBsZXQgZmxvYXRzUGVyVmVydCA9IHRoaXMuZmxvYXRzUGVyVmVydDtcbiAgICAgICAgbGV0IHZlcnRzID0gdGhpcy5fcmVuZGVyRGF0YS52RGF0YXNbMF07XG5cbiAgICAgICAgLy8gcmVuZGVyIGRhdGEgPSB2ZXJ0cyA9IHh8eXx1fHZ8Y29sb3J8eHx5fHV8dnxjb2xvcnwuLi5cbiAgICAgICAgLy8g5aGr5YWFcmVuZGVyIGRhdGHkuK005Liq6aG254K555qEdXbpg6jliIZcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCA0OyBpKyspIHtcbiAgICAgICAgICAgIGxldCBzcmNPZmZzZXQgPSBpICogMjtcbiAgICAgICAgICAgIGxldCBkc3RPZmZzZXQgPSBmbG9hdHNQZXJWZXJ0ICogaSArIHV2T2Zmc2V0O1xuICAgICAgICAgICAgdmVydHNbZHN0T2Zmc2V0XSA9IHV2W3NyY09mZnNldF07XG4gICAgICAgICAgICB2ZXJ0c1tkc3RPZmZzZXQgKyAxXSA9IHV2W3NyY09mZnNldCArIDFdO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIHVwZGF0ZVZlcnRzKGNvbXA6IGNjLlJlbmRlckNvbXBvbmVudCkge1xuICAgICAgICBsZXQgbm9kZTogY2MuTm9kZSA9IGNvbXAubm9kZSxcbiAgICAgICAgICAgIGN3OiBudW1iZXIgPSBub2RlLndpZHRoLFxuICAgICAgICAgICAgY2g6IG51bWJlciA9IG5vZGUuaGVpZ2h0LFxuICAgICAgICAgICAgYXBweDogbnVtYmVyID0gbm9kZS5hbmNob3JYICogY3csXG4gICAgICAgICAgICBhcHB5OiBudW1iZXIgPSBub2RlLmFuY2hvclkgKiBjaCxcbiAgICAgICAgICAgIGw6IG51bWJlcixcbiAgICAgICAgICAgIGI6IG51bWJlciwgXG4gICAgICAgICAgICByOiBudW1iZXIsXG4gICAgICAgICAgICB0OiBudW1iZXI7XG5cbiAgICAgICAgbCA9IC0gYXBweDtcbiAgICAgICAgYiA9IC0gYXBweTtcbiAgICAgICAgciA9IGN3IC0gYXBweDtcbiAgICAgICAgdCA9IGNoIC0gYXBweTtcblxuICAgICAgICBsZXQgbG9jYWwgPSB0aGlzLl9sb2NhbDtcbiAgICAgICAgbG9jYWxbMF0gPSBsO1xuICAgICAgICBsb2NhbFsxXSA9IGI7XG4gICAgICAgIGxvY2FsWzJdID0gcjtcbiAgICAgICAgbG9jYWxbM10gPSB0O1xuICAgICAgICB0aGlzLnVwZGF0ZVdvcmxkVmVydHMoY29tcCk7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIHVwZGF0ZVJlbmRlckRhdGEoY29tcDogY2MuUmVuZGVyQ29tcG9uZW50KSB7XG4gICAgICAgIGlmIChjb21wLl92ZXJ0c0RpcnR5KSB7XG4gICAgICAgICAgICB0aGlzLnVwZGF0ZVVWcyhjb21wKTtcbiAgICAgICAgICAgIHRoaXMudXBkYXRlVmVydHMoY29tcCk7XG4gICAgICAgICAgICBjb21wLl92ZXJ0c0RpcnR5ID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9XG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/Avatar/AvatarSprite.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b1649Wc9Q1OSLLcuayZnPTw', 'AvatarSprite');
// Shader/Avatar/AvatarSprite.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-21 17:27:48
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:14:18
*/
var AvatarAssembler_1 = require("./AvatarAssembler");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var AvatarSprite = /** @class */ (function (_super) {
    __extends(AvatarSprite, _super);
    function AvatarSprite() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    AvatarSprite.prototype._resetAssembler = function () {
        this.setVertsDirty();
        var assembler = this._assembler = new AvatarAssembler_1.default();
        assembler.init(this);
    };
    AvatarSprite = __decorate([
        ccclass
    ], AvatarSprite);
    return AvatarSprite;
}(cc.Sprite));
exports.default = AvatarSprite;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvQXZhdGFyL0F2YXRhclNwcml0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsZ0RBQWdEO0FBQ2hELDRCQUE0QjtBQUM1QiwrQ0FBK0M7QUFDL0MsZ0VBQWdFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFaEU7Ozs7RUFJRTtBQUdGLHFEQUFnRDtBQUUxQyxJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUcxQztJQUEwQyxnQ0FBUztJQUFuRDs7SUFNQSxDQUFDO0lBTEcsc0NBQWUsR0FBZjtRQUNJLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNyQixJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUkseUJBQWUsRUFBRSxDQUFDO1FBQ3hELFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDekIsQ0FBQztJQUxnQixZQUFZO1FBRGhDLE9BQU87T0FDYSxZQUFZLENBTWhDO0lBQUQsbUJBQUM7Q0FORCxBQU1DLENBTnlDLEVBQUUsQ0FBQyxNQUFNLEdBTWxEO2tCQU5vQixZQUFZIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gQ29weXJpZ2h0IDIwMjAgQ2FvIEdhb3Rpbmc8Y2FvZ3RhYUBnbWFpbC5jb20+XG4vLyBodHRwczovL2Nhb2d0YWEuZ2l0aHViLmlvXG4vLyBUaGlzIGZpbGUgaXMgbGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLlxuLy8gTGljZW5zZSB0ZXh0IGF2YWlsYWJsZSBhdCBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVFxuXG4vKlxuICogRGF0ZTogMjAyMC0wNy0yMSAxNzoyNzo0OFxuICogTGFzdEVkaXRvcnM6IEdUPGNhb2d0YWFAZ21haWwuY29tPlxuICogTGFzdEVkaXRUaW1lOiAyMDIwLTA3LTIyIDE0OjE0OjE4XG4qLyBcblxuXG5pbXBvcnQgQXZhdGFyQXNzZW1ibGVyIGZyb20gXCIuL0F2YXRhckFzc2VtYmxlclwiO1xuXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEF2YXRhclNwcml0ZSBleHRlbmRzIGNjLlNwcml0ZSB7XG4gICAgX3Jlc2V0QXNzZW1ibGVyKCkge1xuICAgICAgICB0aGlzLnNldFZlcnRzRGlydHkoKTtcbiAgICAgICAgbGV0IGFzc2VtYmxlciA9IHRoaXMuX2Fzc2VtYmxlciA9IG5ldyBBdmF0YXJBc3NlbWJsZXIoKTtcbiAgICAgICAgYXNzZW1ibGVyLmluaXQodGhpcyk7XG4gICAgfVxufVxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/GTAutoFitSpriteAssembler2D.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'df6cf6PM09M+rsn47qcGazx', 'GTAutoFitSpriteAssembler2D');
// Shader/GTAutoFitSpriteAssembler2D.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-21 16:23:10
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:04:52
*/
var GTSimpleSpriteAssembler2D_1 = require("./GTSimpleSpriteAssembler2D");
var GTAutoFitSpriteAssembler2D = /** @class */ (function (_super) {
    __extends(GTAutoFitSpriteAssembler2D, _super);
    function GTAutoFitSpriteAssembler2D() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._uv = [];
        return _this;
    }
    GTAutoFitSpriteAssembler2D.prototype.updateUVs = function (sprite) {
        var rect = sprite._spriteFrame.getRect();
        var node = sprite.node;
        if (!rect.width || !rect.height || !node.width || !node.height) {
            _super.prototype.updateUVs.call(this, sprite);
            return;
        }
        Object.assign(this._uv, sprite._spriteFrame.uv);
        var uv = this._uv;
        var wscale = rect.width / node.width;
        var hscale = rect.height / node.height;
        var ratio = 1.0;
        var isRotated = sprite._spriteFrame.isRotated();
        var l = uv[0], r = uv[2], b = uv[1], t = uv[5];
        if (isRotated) {
            // cc图集里的旋转总是顺时针旋转90度，以原左下角为中心。（旋转后左下角变为左上角）
            l = uv[1];
            r = uv[3];
            b = uv[0];
            t = uv[4];
        }
        // 图片在等比缩放的前提下自适应容器大小
        if (wscale > hscale) {
            // fit height
            ratio = hscale / wscale;
            var ro = isRotated ? 1 : 0;
            var c = (l + r) * 0.5;
            var half = (r - l) * 0.5 * ratio;
            l = uv[0 + ro] = uv[4 + ro] = c - half;
            r = uv[2 + ro] = uv[6 + ro] = c + half;
        }
        else {
            // fit width
            ratio = wscale / hscale;
            var ro = isRotated ? -1 : 0;
            var c = (b + t) * 0.5;
            var half = (b - t) * 0.5 * ratio;
            b = uv[1 + ro] = uv[3 + ro] = c + half;
            t = uv[5 + ro] = uv[7 + ro] = c - half;
        }
        var uvOffset = this.uvOffset;
        var floatsPerVert = this.floatsPerVert;
        var verts = this._renderData.vDatas[0];
        for (var i = 0; i < 4; i++) {
            var srcOffset = i * 2;
            var dstOffset = floatsPerVert * i + uvOffset;
            verts[dstOffset] = uv[srcOffset];
            verts[dstOffset + 1] = uv[srcOffset + 1];
        }
    };
    return GTAutoFitSpriteAssembler2D;
}(GTSimpleSpriteAssembler2D_1.default));
exports.default = GTAutoFitSpriteAssembler2D;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvR1RBdXRvRml0U3ByaXRlQXNzZW1ibGVyMkQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLGdEQUFnRDtBQUNoRCw0QkFBNEI7QUFDNUIsK0NBQStDO0FBQy9DLGdFQUFnRTs7Ozs7Ozs7Ozs7Ozs7O0FBRWhFOzs7O0VBSUU7QUFFRix5RUFBb0U7QUFFcEU7SUFBd0QsOENBQXlCO0lBQWpGO1FBQUEscUVBMERDO1FBekRhLFNBQUcsR0FBRyxFQUFFLENBQUM7O0lBeUR2QixDQUFDO0lBdkRHLDhDQUFTLEdBQVQsVUFBVSxNQUFNO1FBQ1osSUFBSSxJQUFJLEdBQVksTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUNsRCxJQUFJLElBQUksR0FBWSxNQUFNLENBQUMsSUFBSSxDQUFDO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQzVELGlCQUFNLFNBQVMsWUFBQyxNQUFNLENBQUMsQ0FBQztZQUN4QixPQUFPO1NBQ1Y7UUFFRCxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUVoRCxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDO1FBQ2xCLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUNyQyxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7UUFDdkMsSUFBSSxLQUFLLEdBQVcsR0FBRyxDQUFDO1FBQ3hCLElBQUksU0FBUyxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDaEQsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUNULENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQ1QsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFDVCxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRWQsSUFBSSxTQUFTLEVBQUU7WUFDWCw0Q0FBNEM7WUFDNUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdEIsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDekI7UUFFRCxxQkFBcUI7UUFDckIsSUFBSSxNQUFNLEdBQUcsTUFBTSxFQUFFO1lBQ2pCLGFBQWE7WUFDYixLQUFLLEdBQUcsTUFBTSxHQUFHLE1BQU0sQ0FBQztZQUN4QixJQUFJLEVBQUUsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzNCLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztZQUNwQixJQUFJLElBQUksR0FBRyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsS0FBSyxDQUFDO1lBQy9CLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxHQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQztZQUNuQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsR0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxHQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUM7U0FDdEM7YUFBTTtZQUNILFlBQVk7WUFDWixLQUFLLEdBQUcsTUFBTSxHQUFHLE1BQU0sQ0FBQztZQUN4QixJQUFJLEVBQUUsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDNUIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO1lBQ3BCLElBQUksSUFBSSxHQUFHLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxLQUFLLENBQUM7WUFDL0IsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsR0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDO1lBQ25DLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxHQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQztTQUN0QztRQUVELElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7UUFDN0IsSUFBSSxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUN2QyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2QyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3hCLElBQUksU0FBUyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDdEIsSUFBSSxTQUFTLEdBQUcsYUFBYSxHQUFHLENBQUMsR0FBRyxRQUFRLENBQUM7WUFDN0MsS0FBSyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNqQyxLQUFLLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDNUM7SUFDTCxDQUFDO0lBQ0wsaUNBQUM7QUFBRCxDQTFEQSxBQTBEQyxDQTFEdUQsbUNBQXlCLEdBMERoRiIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIENvcHlyaWdodCAyMDIwIENhbyBHYW90aW5nPGNhb2d0YWFAZ21haWwuY29tPlxuLy8gaHR0cHM6Ly9jYW9ndGFhLmdpdGh1Yi5pb1xuLy8gVGhpcyBmaWxlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS5cbi8vIExpY2Vuc2UgdGV4dCBhdmFpbGFibGUgYXQgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVRcblxuLypcbiAqIERhdGU6IDIwMjAtMDctMjEgMTY6MjM6MTBcbiAqIExhc3RFZGl0b3JzOiBHVDxjYW9ndGFhQGdtYWlsLmNvbT5cbiAqIExhc3RFZGl0VGltZTogMjAyMC0wNy0yMiAxNDowNDo1MlxuKi8gXG5cbmltcG9ydCBHVFNpbXBsZVNwcml0ZUFzc2VtYmxlcjJEIGZyb20gXCIuL0dUU2ltcGxlU3ByaXRlQXNzZW1ibGVyMkRcIjtcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgR1RBdXRvRml0U3ByaXRlQXNzZW1ibGVyMkQgZXh0ZW5kcyBHVFNpbXBsZVNwcml0ZUFzc2VtYmxlcjJEIHtcbiAgICBwcm90ZWN0ZWQgX3V2ID0gW107XG5cbiAgICB1cGRhdGVVVnMoc3ByaXRlKSB7XG4gICAgICAgIGxldCByZWN0OiBjYy5SZWN0ID0gc3ByaXRlLl9zcHJpdGVGcmFtZS5nZXRSZWN0KCk7XG4gICAgICAgIGxldCBub2RlOiBjYy5Ob2RlID0gc3ByaXRlLm5vZGU7XG4gICAgICAgIGlmICghcmVjdC53aWR0aCB8fCAhcmVjdC5oZWlnaHQgfHwgIW5vZGUud2lkdGggfHwgIW5vZGUuaGVpZ2h0KSB7XG4gICAgICAgICAgICBzdXBlci51cGRhdGVVVnMoc3ByaXRlKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIE9iamVjdC5hc3NpZ24odGhpcy5fdXYsIHNwcml0ZS5fc3ByaXRlRnJhbWUudXYpO1xuXG4gICAgICAgIGxldCB1diA9IHRoaXMuX3V2O1xuICAgICAgICBsZXQgd3NjYWxlID0gcmVjdC53aWR0aCAvIG5vZGUud2lkdGg7XG4gICAgICAgIGxldCBoc2NhbGUgPSByZWN0LmhlaWdodCAvIG5vZGUuaGVpZ2h0O1xuICAgICAgICBsZXQgcmF0aW86IG51bWJlciA9IDEuMDtcbiAgICAgICAgbGV0IGlzUm90YXRlZCA9IHNwcml0ZS5fc3ByaXRlRnJhbWUuaXNSb3RhdGVkKCk7XG4gICAgICAgIGxldCBsID0gdXZbMF0sXG4gICAgICAgICAgICByID0gdXZbMl0sXG4gICAgICAgICAgICBiID0gdXZbMV0sXG4gICAgICAgICAgICB0ID0gdXZbNV07XG4gICAgICAgIFxuICAgICAgICBpZiAoaXNSb3RhdGVkKSB7XG4gICAgICAgICAgICAvLyBjY+WbvumbhumHjOeahOaXi+i9rOaAu+aYr+mhuuaXtumSiOaXi+i9rDkw5bqm77yM5Lul5Y6f5bem5LiL6KeS5Li65Lit5b+D44CC77yI5peL6L2s5ZCO5bem5LiL6KeS5Y+Y5Li65bem5LiK6KeS77yJXG4gICAgICAgICAgICBsID0gdXZbMV07ICByID0gdXZbM107XG4gICAgICAgICAgICBiID0gdXZbMF07ICB0ID0gdXZbNF07XG4gICAgICAgIH1cblxuICAgICAgICAvLyDlm77niYflnKjnrYnmr5TnvKnmlL7nmoTliY3mj5DkuIvoh6rpgILlupTlrrnlmajlpKflsI9cbiAgICAgICAgaWYgKHdzY2FsZSA+IGhzY2FsZSkge1xuICAgICAgICAgICAgLy8gZml0IGhlaWdodFxuICAgICAgICAgICAgcmF0aW8gPSBoc2NhbGUgLyB3c2NhbGU7XG4gICAgICAgICAgICBsZXQgcm8gPSBpc1JvdGF0ZWQgPyAxIDogMDtcbiAgICAgICAgICAgIGxldCBjID0gKGwrcikgKiAwLjU7XG4gICAgICAgICAgICBsZXQgaGFsZiA9IChyLWwpICogMC41ICogcmF0aW87XG4gICAgICAgICAgICBsID0gdXZbMCtyb10gPSB1dls0K3JvXSA9IGMgLSBoYWxmO1xuICAgICAgICAgICAgciA9IHV2WzIrcm9dID0gdXZbNityb10gPSBjICsgaGFsZjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIGZpdCB3aWR0aFxuICAgICAgICAgICAgcmF0aW8gPSB3c2NhbGUgLyBoc2NhbGU7XG4gICAgICAgICAgICBsZXQgcm8gPSBpc1JvdGF0ZWQgPyAtMSA6IDA7XG4gICAgICAgICAgICBsZXQgYyA9IChiK3QpICogMC41O1xuICAgICAgICAgICAgbGV0IGhhbGYgPSAoYi10KSAqIDAuNSAqIHJhdGlvO1xuICAgICAgICAgICAgYiA9IHV2WzErcm9dID0gdXZbMytyb10gPSBjICsgaGFsZjtcbiAgICAgICAgICAgIHQgPSB1dls1K3JvXSA9IHV2Wzcrcm9dID0gYyAtIGhhbGY7XG4gICAgICAgIH1cblxuICAgICAgICBsZXQgdXZPZmZzZXQgPSB0aGlzLnV2T2Zmc2V0O1xuICAgICAgICBsZXQgZmxvYXRzUGVyVmVydCA9IHRoaXMuZmxvYXRzUGVyVmVydDtcbiAgICAgICAgbGV0IHZlcnRzID0gdGhpcy5fcmVuZGVyRGF0YS52RGF0YXNbMF07XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgNDsgaSsrKSB7XG4gICAgICAgICAgICBsZXQgc3JjT2Zmc2V0ID0gaSAqIDI7XG4gICAgICAgICAgICBsZXQgZHN0T2Zmc2V0ID0gZmxvYXRzUGVyVmVydCAqIGkgKyB1dk9mZnNldDtcbiAgICAgICAgICAgIHZlcnRzW2RzdE9mZnNldF0gPSB1dltzcmNPZmZzZXRdO1xuICAgICAgICAgICAgdmVydHNbZHN0T2Zmc2V0ICsgMV0gPSB1dltzcmNPZmZzZXQgKyAxXTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/Scene/SceneMetaBalls.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '5d511arYq1Fy75gm6m2P7X0', 'SceneMetaBalls');
// Scripts/Scene/SceneMetaBalls.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-13 02:44:16
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:01:57
*/
var MetaBallsRenderer_1 = require("../../Shader/MetaBalls/MetaBallsRenderer");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SceneMetaBalls = /** @class */ (function (_super) {
    __extends(SceneMetaBalls, _super);
    function SceneMetaBalls() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.waterRendererCamera = null;
        _this.waterRenderer = null;
        _this.waterRendererPass2 = null;
        _this.metaBallsRenderer = null;
        _this.particleBox = null;
        _this._world = null;
        _this._particles = null;
        _this._particleGroup = null;
        return _this;
    }
    SceneMetaBalls.prototype.onLoad = function () {
        if (!CC_EDITOR) {
            this.SetupWorld();
        }
        var texture = new cc.RenderTexture();
        var size = this.waterRendererPass2.node.getContentSize();
        texture.initWithSize(size.width, size.height);
        var spriteFrame = new cc.SpriteFrame();
        spriteFrame.setTexture(texture);
        this.waterRendererCamera.targetTexture = texture;
        this.waterRendererPass2.spriteFrame = spriteFrame;
    };
    SceneMetaBalls.prototype.SetupWorld = function () {
        // enable physics manager
        var physicsManager = cc.director.getPhysicsManager();
        physicsManager.enabled = true;
        var world = this._world = physicsManager._world; // new b2.World(new b2.Vec2(0, -15.0));
        var psd = new b2.ParticleSystemDef();
        psd.radius = 0.35;
        // psd.dampingStrength = 1.5;
        psd.viscousStrength = 0;
        this._particles = world.CreateParticleSystem(psd);
    };
    SceneMetaBalls.prototype.CreateParticlesGroup = function () {
        var PTM_RATIO = cc.PhysicsManager.PTM_RATIO;
        var boxSize = this.particleBox.getContentSize();
        var boxPos = this.particleBox.getPosition();
        var size = cc.winSize;
        var box = new b2.PolygonShape();
        // https://google.github.io/liquidfun/API-Ref/html/classb2_polygon_shape.html#a890690250115483da6c7d69829be087e
        // Build vertices to represent an oriented box.
        // box的大小影响粒子的数量
        box.SetAsBox(boxSize.width / 2 / PTM_RATIO, boxSize.height / 2 / PTM_RATIO);
        var particleGroupDef = new b2.ParticleGroupDef();
        particleGroupDef.shape = box;
        particleGroupDef.flags = b2.waterParticle;
        particleGroupDef.position.Set((boxPos.x + size.width / 2) / PTM_RATIO, (boxPos.y + size.height / 2) / PTM_RATIO);
        this._particleGroup = this._particles.CreateParticleGroup(particleGroupDef);
        this.metaBallsRenderer.SetParticles(this._particles);
        var vertsCount = this._particles.GetParticleCount();
        console.log(vertsCount);
    };
    SceneMetaBalls.prototype.GenerateWater = function () {
        this.ResetParticleGroup();
        // re-create particles in next tick
        // otherwise old particle system is not correctly released
        // this is a non-repeat schedule
        var that = this;
        cc.director.getScheduler().schedule(function () {
            that.CreateParticlesGroup();
        }, this.node, 0, 0, 0, false);
    };
    SceneMetaBalls.prototype.ResetParticleGroup = function () {
        if (this._particleGroup != null) {
            this._particleGroup.DestroyParticles(false);
            this._particles.DestroyParticleGroup(this._particleGroup);
            this._particleGroup = null;
        }
    };
    __decorate([
        property(cc.Camera)
    ], SceneMetaBalls.prototype, "waterRendererCamera", void 0);
    __decorate([
        property(cc.Node)
    ], SceneMetaBalls.prototype, "waterRenderer", void 0);
    __decorate([
        property(cc.Sprite)
    ], SceneMetaBalls.prototype, "waterRendererPass2", void 0);
    __decorate([
        property(MetaBallsRenderer_1.default)
    ], SceneMetaBalls.prototype, "metaBallsRenderer", void 0);
    __decorate([
        property(cc.Node)
    ], SceneMetaBalls.prototype, "particleBox", void 0);
    SceneMetaBalls = __decorate([
        ccclass
    ], SceneMetaBalls);
    return SceneMetaBalls;
}(cc.Component));
exports.default = SceneMetaBalls;
var enableLowLevelOptimize = true;
if (enableLowLevelOptimize) {
    cc.game.once(cc.game.EVENT_ENGINE_INITED, function () {
        // b2ParticleSystem.prototype.FindContacts_Reference = function (contacts) {
        //@ts-ignore
        b2.ParticleSystem.prototype.FindContacts_Reference = function (contacts) {
            if (!this.m_flagsBuffer.data) {
                throw new Error();
            }
            if (!this.m_positionBuffer.data) {
                throw new Error();
            }
            var pos_data = this.m_positionBuffer.data;
            var squaredDiameter = this.m_squaredDiameter;
            var inverseDiameter = this.m_inverseDiameter;
            // DEBUG: b2Assert(contacts === this.m_contactBuffer);
            var beginProxy = 0;
            var endProxy = this.m_proxyBuffer.count;
            this.m_contactBuffer.count = 0;
            // let contactBuffer = this.m_contactBuffer;
            var proxyData = this.m_proxyBuffer.data;
            //@ts-ignore
            var computeRelativeTag = b2.ParticleSystem.computeRelativeTag;
            // var AddContact = this.AddContact2.bind(this);
            var dataA;
            var tagA = 0;
            var indexA = 0;
            var rightTag = 0;
            var dataB;
            var pos_data = this.m_positionBuffer.data;
            var flagBufferData = this.m_flagsBuffer.data;
            var flagBufferDataA;
            var indexB = 0;
            var pos_dataA;
            var pos_dataB;
            var ax = 0, ay = 0, bx = 0, by = 0, dx = 0, dy = 0;
            var distBtParticlesSq = 0;
            var bottomLeftTag = 0;
            var bottomRightTag = 0;
            var isFin = isFinite;
            for (var a = beginProxy, c = beginProxy; a < endProxy; ++a) {
                dataA = proxyData[a];
                tagA = dataA.tag;
                indexA = dataA.index;
                pos_dataA = pos_data[indexA];
                flagBufferDataA = flagBufferData[indexA];
                rightTag = computeRelativeTag(tagA, 1, 0);
                for (var b = a + 1; b < endProxy; ++b) {
                    dataB = proxyData[b];
                    if (rightTag < dataB.tag) {
                        break;
                    }
                    // ------- AddContact(indexA, proxyData[b].index, contactBuffer);
                    indexB = dataB.index;
                    // pos_dataA = pos_data[indexA];
                    pos_dataB = pos_data[indexB];
                    // DEBUG: b2Assert(contacts === this.m_contactBuffer);
                    ///b2Vec2 d = m_positionBuffer.data[b] - m_positionBuffer.data[a];
                    bx = pos_dataB.x;
                    by = pos_dataB.y;
                    ax = pos_dataA.x;
                    ay = pos_dataA.y;
                    dx = bx - ax;
                    dy = by - ay;
                    // var d = b2.Vec2.SubVV(pos_data[b], pos_data[a], s_d);
                    distBtParticlesSq = dx * dx + dy * dy;
                    // var distBtParticlesSq = b2.Vec2.DotVV(d, d);
                    if (distBtParticlesSq < squaredDiameter) {
                        var invD = 1 / Math.sqrt(distBtParticlesSq);
                        // var invD = b2.InvSqrt(distBtParticlesSq);
                        if (!isFin(invD)) {
                            invD = 1.98177537e+019;
                        }
                        ///b2ParticleContact& contact = contacts.Append();
                        var contact = this.m_contactBuffer.data[this.m_contactBuffer.Append()];
                        contact.indexA = indexA;
                        contact.indexB = indexB;
                        contact.flags = flagBufferDataA | flagBufferData[indexB];
                        contact.weight = 1 - distBtParticlesSq * invD * inverseDiameter;
                        ///contact.SetNormal(invD * d);
                        contact.normal.x = invD * dx;
                        contact.normal.y = invD * dy;
                        // b2.Vec2.MulSV(invD, d, contact.normal);
                    }
                    // end ------- AddContact(indexA, proxyData[b].index, contactBuffer);
                }
                bottomLeftTag = computeRelativeTag(tagA, -1, 1);
                for (; c < endProxy; ++c) {
                    if (bottomLeftTag <= proxyData[c].tag) {
                        break;
                    }
                }
                bottomRightTag = computeRelativeTag(tagA, 1, 1);
                for (var b = c; b < endProxy; ++b) {
                    dataB = proxyData[b];
                    if (bottomRightTag < dataB.tag) {
                        break;
                    }
                    // ------- AddContact(indexA, proxyData[b].index, contactBuffer);
                    indexB = dataB.index;
                    // pos_dataA = pos_data[indexA];
                    pos_dataB = pos_data[indexB];
                    // DEBUG: b2Assert(contacts === this.m_contactBuffer);
                    ///b2Vec2 d = m_positionBuffer.data[b] - m_positionBuffer.data[a];
                    bx = pos_dataB.x;
                    by = pos_dataB.y;
                    ax = pos_dataA.x;
                    ay = pos_dataA.y;
                    dx = bx - ax;
                    dy = by - ay;
                    // var d = b2.Vec2.SubVV(pos_data[b], pos_data[a], s_d);
                    distBtParticlesSq = dx * dx + dy * dy;
                    // var distBtParticlesSq = b2.Vec2.DotVV(d, d);
                    if (distBtParticlesSq < squaredDiameter) {
                        var invD = 1 / Math.sqrt(distBtParticlesSq);
                        // var invD = b2.InvSqrt(distBtParticlesSq);
                        if (!isFin(invD)) {
                            invD = 1.98177537e+019;
                        }
                        ///b2ParticleContact& contact = contacts.Append();
                        var contact = this.m_contactBuffer.data[this.m_contactBuffer.Append()];
                        contact.indexA = indexA;
                        contact.indexB = indexB;
                        contact.flags = flagBufferDataA | flagBufferData[indexB];
                        contact.weight = 1 - distBtParticlesSq * invD * inverseDiameter;
                        ///contact.SetNormal(invD * d);
                        contact.normal.x = invD * dx;
                        contact.normal.y = invD * dy;
                        // b2.Vec2.MulSV(invD, d, contact.normal);
                    }
                    // end ------- AddContact(indexA, proxyData[b].index, contactBuffer);
                }
            }
        };
    });
}

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHRzL1NjZW5lL1NjZW5lTWV0YUJhbGxzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxnREFBZ0Q7QUFDaEQsNEJBQTRCO0FBQzVCLCtDQUErQztBQUMvQyxnRUFBZ0U7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVoRTs7OztFQUlFO0FBR0YsOEVBQXlFO0FBRW5FLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQTRDLGtDQUFZO0lBQXhEO1FBQUEscUVBaUdDO1FBL0ZBLHlCQUFtQixHQUFjLElBQUksQ0FBQztRQUd0QyxtQkFBYSxHQUFZLElBQUksQ0FBQztRQUc5Qix3QkFBa0IsR0FBYyxJQUFJLENBQUM7UUFHckMsdUJBQWlCLEdBQXNCLElBQUksQ0FBQztRQUc1QyxpQkFBVyxHQUFZLElBQUksQ0FBQztRQUVsQixZQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ2QsZ0JBQVUsR0FBRyxJQUFJLENBQUM7UUFDbEIsb0JBQWMsR0FBRyxJQUFJLENBQUM7O0lBK0VqQyxDQUFDO0lBN0VBLCtCQUFNLEdBQU47UUFDQyxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2YsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1NBQ2xCO1FBRUQsSUFBTSxPQUFPLEdBQUcsSUFBSSxFQUFFLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDdkMsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUNuRCxPQUFPLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRTlDLElBQU0sV0FBVyxHQUFHLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3pDLFdBQVcsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDaEMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLGFBQWEsR0FBRyxPQUFPLENBQUM7UUFDakQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7SUFDekQsQ0FBQztJQUVELG1DQUFVLEdBQVY7UUFDQyx5QkFBeUI7UUFDekIsSUFBSSxjQUFjLEdBQUcsRUFBRSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsRUFBRSxDQUFBO1FBQ3BELGNBQWMsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBRTlCLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFBLHVDQUF1QztRQUN2RixJQUFJLEdBQUcsR0FBRyxJQUFJLEVBQUUsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQ3JDLEdBQUcsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ2xCLDZCQUE2QjtRQUM3QixHQUFHLENBQUMsZUFBZSxHQUFHLENBQUMsQ0FBQztRQUV4QixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRUQsNkNBQW9CLEdBQXBCO1FBQ0MsSUFBSSxTQUFTLEdBQUcsRUFBRSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUM7UUFDNUMsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUNoRCxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQzVDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUM7UUFDdEIsSUFBSSxHQUFHLEdBQUcsSUFBSSxFQUFFLENBQUMsWUFBWSxFQUFFLENBQUM7UUFFaEMsK0dBQStHO1FBQy9HLCtDQUErQztRQUMvQyxnQkFBZ0I7UUFDaEIsR0FBRyxDQUFDLFFBQVEsQ0FDWCxPQUFPLENBQUMsS0FBSyxHQUFHLENBQUMsR0FBRyxTQUFTLEVBQzdCLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxDQUFBO1FBRWhDLElBQUksZ0JBQWdCLEdBQUcsSUFBSSxFQUFFLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUNqRCxnQkFBZ0IsQ0FBQyxLQUFLLEdBQUcsR0FBRyxDQUFDO1FBQzdCLGdCQUFnQixDQUFDLEtBQUssR0FBRyxFQUFFLENBQUMsYUFBYSxDQUFDO1FBQzFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQzVCLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxHQUFHLFNBQVMsRUFDckMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLENBQUM7UUFFekMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFDNUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFFckQsSUFBSSxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQ3BELE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDekIsQ0FBQztJQUVFLHNDQUFhLEdBQWI7UUFDRixJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUUxQixtQ0FBbUM7UUFDbkMsMERBQTBEO1FBQzFELGdDQUFnQztRQUNoQyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUM7UUFDaEIsRUFBRSxDQUFDLFFBQVEsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxRQUFRLENBQUM7WUFDbkMsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7UUFDN0IsQ0FBQyxFQUFFLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDL0IsQ0FBQztJQUVFLDJDQUFrQixHQUFsQjtRQUNGLElBQUksSUFBSSxDQUFDLGNBQWMsSUFBSSxJQUFJLEVBQUU7WUFDaEMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUM1QyxJQUFJLENBQUMsVUFBVSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUUxRCxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQztTQUMzQjtJQUNDLENBQUM7SUE5Rko7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQzsrREFDa0I7SUFHdEM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzt5REFDWTtJQUc5QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDOzhEQUNpQjtJQUdyQztRQURDLFFBQVEsQ0FBQywyQkFBaUIsQ0FBQzs2REFDZ0I7SUFHNUM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzt1REFDVTtJQWRSLGNBQWM7UUFEbEMsT0FBTztPQUNhLGNBQWMsQ0FpR2xDO0lBQUQscUJBQUM7Q0FqR0QsQUFpR0MsQ0FqRzJDLEVBQUUsQ0FBQyxTQUFTLEdBaUd2RDtrQkFqR29CLGNBQWM7QUFtR25DLElBQUksc0JBQXNCLEdBQUcsSUFBSSxDQUFDO0FBQ2xDLElBQUksc0JBQXNCLEVBQUU7SUFDM0IsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsRUFBRTtRQUN6Qyw0RUFBNEU7UUFDNUUsWUFBWTtRQUNaLEVBQUUsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLHNCQUFzQixHQUFHLFVBQVUsUUFBUTtZQUN0RSxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUU7Z0JBQzdCLE1BQU0sSUFBSSxLQUFLLEVBQUUsQ0FBQzthQUNsQjtZQUNELElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxFQUFFO2dCQUNoQyxNQUFNLElBQUksS0FBSyxFQUFFLENBQUM7YUFDbEI7WUFFRCxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDO1lBQzFDLElBQUksZUFBZSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztZQUM3QyxJQUFJLGVBQWUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUM7WUFFN0Msc0RBQXNEO1lBQ3RELElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztZQUNuQixJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQztZQUN4QyxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7WUFDL0IsNENBQTRDO1lBQzVDLElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDO1lBQ3hDLFlBQVk7WUFDWixJQUFJLGtCQUFrQixHQUFHLEVBQUUsQ0FBQyxjQUFjLENBQUMsa0JBQWtCLENBQUM7WUFDOUQsZ0RBQWdEO1lBRWhELElBQUksS0FBSyxDQUFDO1lBQ1YsSUFBSSxJQUFJLEdBQUcsQ0FBQyxDQUFDO1lBQ2IsSUFBSSxNQUFNLEdBQUcsQ0FBQyxDQUFDO1lBQ2YsSUFBSSxRQUFRLEdBQUcsQ0FBQyxDQUFDO1lBQ2pCLElBQUksS0FBSyxDQUFDO1lBRVYsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQztZQUMxQyxJQUFJLGNBQWMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQztZQUM3QyxJQUFJLGVBQWUsQ0FBQztZQUNwQixJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUM7WUFDZixJQUFJLFNBQVMsQ0FBQztZQUNkLElBQUksU0FBUyxDQUFDO1lBRWQsSUFBSSxFQUFFLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQztZQUNuRCxJQUFJLGlCQUFpQixHQUFHLENBQUMsQ0FBQztZQUUxQixJQUFJLGFBQWEsR0FBRyxDQUFDLENBQUM7WUFDdEIsSUFBSSxjQUFjLEdBQUcsQ0FBQyxDQUFDO1lBRXZCLElBQUksS0FBSyxHQUFHLFFBQVEsQ0FBQztZQUVyQixLQUFLLElBQUksQ0FBQyxHQUFHLFVBQVUsRUFBRSxDQUFDLEdBQUcsVUFBVSxFQUFFLENBQUMsR0FBRyxRQUFRLEVBQUUsRUFBRSxDQUFDLEVBQUU7Z0JBQzNELEtBQUssR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3JCLElBQUksR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDO2dCQUNqQixNQUFNLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQztnQkFDckIsU0FBUyxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDN0IsZUFBZSxHQUFHLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFFekMsUUFBUSxHQUFHLGtCQUFrQixDQUFDLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQzFDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxFQUFFLEVBQUUsQ0FBQyxFQUFFO29CQUN0QyxLQUFLLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNyQixJQUFJLFFBQVEsR0FBRyxLQUFLLENBQUMsR0FBRyxFQUFFO3dCQUN6QixNQUFNO3FCQUNOO29CQUVELGlFQUFpRTtvQkFDakUsTUFBTSxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUM7b0JBQ3JCLGdDQUFnQztvQkFDaEMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFFN0Isc0RBQXNEO29CQUN0RCxrRUFBa0U7b0JBRWxFLEVBQUUsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDO29CQUNqQixFQUFFLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQztvQkFDakIsRUFBRSxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUM7b0JBQ2pCLEVBQUUsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDO29CQUVqQixFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztvQkFDYixFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztvQkFDYix3REFBd0Q7b0JBRXhELGlCQUFpQixHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztvQkFDdEMsK0NBQStDO29CQUMvQyxJQUFJLGlCQUFpQixHQUFHLGVBQWUsRUFBRTt3QkFDeEMsSUFBSSxJQUFJLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQzt3QkFDNUMsNENBQTRDO3dCQUM1QyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFOzRCQUNqQixJQUFJLEdBQUcsZUFBZSxDQUFDO3lCQUN2Qjt3QkFDRCxrREFBa0Q7d0JBQ2xELElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQzt3QkFDdkUsT0FBTyxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7d0JBQ3hCLE9BQU8sQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO3dCQUN4QixPQUFPLENBQUMsS0FBSyxHQUFHLGVBQWUsR0FBRyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUM7d0JBQ3pELE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLGlCQUFpQixHQUFHLElBQUksR0FBRyxlQUFlLENBQUM7d0JBQ2hFLCtCQUErQjt3QkFFL0IsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQzt3QkFDN0IsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQzt3QkFDN0IsMENBQTBDO3FCQUMxQztvQkFDRCxxRUFBcUU7aUJBQ3JFO2dCQUNELGFBQWEsR0FBRyxrQkFBa0IsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hELE9BQU8sQ0FBQyxHQUFHLFFBQVEsRUFBRSxFQUFFLENBQUMsRUFBRTtvQkFDekIsSUFBSSxhQUFhLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRTt3QkFDdEMsTUFBTTtxQkFDTjtpQkFDRDtnQkFDRCxjQUFjLEdBQUcsa0JBQWtCLENBQUMsSUFBSSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDaEQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsRUFBRSxFQUFFLENBQUMsRUFBRTtvQkFDbEMsS0FBSyxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDckIsSUFBSSxjQUFjLEdBQUcsS0FBSyxDQUFDLEdBQUcsRUFBRTt3QkFDL0IsTUFBTTtxQkFDTjtvQkFFRCxpRUFBaUU7b0JBQ2pFLE1BQU0sR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDO29CQUNyQixnQ0FBZ0M7b0JBQ2hDLFNBQVMsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQzdCLHNEQUFzRDtvQkFDdEQsa0VBQWtFO29CQUVsRSxFQUFFLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQztvQkFDakIsRUFBRSxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUM7b0JBQ2pCLEVBQUUsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDO29CQUNqQixFQUFFLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQztvQkFFakIsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7b0JBQ2IsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7b0JBQ2Isd0RBQXdEO29CQUV4RCxpQkFBaUIsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7b0JBQ3RDLCtDQUErQztvQkFDL0MsSUFBSSxpQkFBaUIsR0FBRyxlQUFlLEVBQUU7d0JBQ3hDLElBQUksSUFBSSxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7d0JBQzVDLDRDQUE0Qzt3QkFDNUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRTs0QkFDakIsSUFBSSxHQUFHLGVBQWUsQ0FBQzt5QkFDdkI7d0JBQ0Qsa0RBQWtEO3dCQUNsRCxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7d0JBQ3ZFLE9BQU8sQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO3dCQUN4QixPQUFPLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQzt3QkFDeEIsT0FBTyxDQUFDLEtBQUssR0FBRyxlQUFlLEdBQUcsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDO3dCQUN6RCxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsR0FBRyxpQkFBaUIsR0FBRyxJQUFJLEdBQUcsZUFBZSxDQUFDO3dCQUNoRSwrQkFBK0I7d0JBRS9CLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7d0JBQzdCLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7d0JBQzdCLDBDQUEwQztxQkFDMUM7b0JBQ0QscUVBQXFFO2lCQUNyRTthQUNEO1FBQ0YsQ0FBQyxDQUFDO0lBQ0gsQ0FBQyxDQUFDLENBQUM7Q0FDSCIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIENvcHlyaWdodCAyMDIwIENhbyBHYW90aW5nPGNhb2d0YWFAZ21haWwuY29tPlxyXG4vLyBodHRwczovL2Nhb2d0YWEuZ2l0aHViLmlvXHJcbi8vIFRoaXMgZmlsZSBpcyBsaWNlbnNlZCB1bmRlciB0aGUgTUlUIExpY2Vuc2UuXHJcbi8vIExpY2Vuc2UgdGV4dCBhdmFpbGFibGUgYXQgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVRcclxuXHJcbi8qXHJcbiAqIERhdGU6IDIwMjAtMDctMTMgMDI6NDQ6MTZcclxuICogTGFzdEVkaXRvcnM6IEdUPGNhb2d0YWFAZ21haWwuY29tPlxyXG4gKiBMYXN0RWRpdFRpbWU6IDIwMjAtMDctMjIgMTQ6MDE6NTdcclxuKi8gXHJcblxyXG5cclxuaW1wb3J0IE1ldGFCYWxsc1JlbmRlcmVyIGZyb20gXCIuLi8uLi9TaGFkZXIvTWV0YUJhbGxzL01ldGFCYWxsc1JlbmRlcmVyXCI7XHJcblxyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgU2NlbmVNZXRhQmFsbHMgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG5cdEBwcm9wZXJ0eShjYy5DYW1lcmEpXHJcblx0d2F0ZXJSZW5kZXJlckNhbWVyYTogY2MuQ2FtZXJhID0gbnVsbDtcclxuXHJcblx0QHByb3BlcnR5KGNjLk5vZGUpXHJcblx0d2F0ZXJSZW5kZXJlcjogY2MuTm9kZSA9IG51bGw7XHJcblxyXG5cdEBwcm9wZXJ0eShjYy5TcHJpdGUpXHJcblx0d2F0ZXJSZW5kZXJlclBhc3MyOiBjYy5TcHJpdGUgPSBudWxsO1xyXG5cclxuXHRAcHJvcGVydHkoTWV0YUJhbGxzUmVuZGVyZXIpXHJcblx0bWV0YUJhbGxzUmVuZGVyZXI6IE1ldGFCYWxsc1JlbmRlcmVyID0gbnVsbDtcclxuXHJcblx0QHByb3BlcnR5KGNjLk5vZGUpXHJcblx0cGFydGljbGVCb3g6IGNjLk5vZGUgPSBudWxsO1xyXG5cclxuXHRwcm90ZWN0ZWQgX3dvcmxkID0gbnVsbDtcclxuXHRwcm90ZWN0ZWQgX3BhcnRpY2xlcyA9IG51bGw7XHJcblx0cHJvdGVjdGVkIF9wYXJ0aWNsZUdyb3VwID0gbnVsbDtcclxuXHJcblx0b25Mb2FkKCkge1xyXG5cdFx0aWYgKCFDQ19FRElUT1IpIHtcclxuXHRcdFx0dGhpcy5TZXR1cFdvcmxkKCk7XHJcblx0XHR9XHJcblxyXG5cdFx0Y29uc3QgdGV4dHVyZSA9IG5ldyBjYy5SZW5kZXJUZXh0dXJlKCk7XHJcblx0XHRsZXQgc2l6ZSA9IHRoaXMud2F0ZXJSZW5kZXJlclBhc3MyLm5vZGUuZ2V0Q29udGVudFNpemUoKTtcclxuICAgICAgICB0ZXh0dXJlLmluaXRXaXRoU2l6ZShzaXplLndpZHRoLCBzaXplLmhlaWdodCk7XHJcblx0XHRcclxuICAgICAgICBjb25zdCBzcHJpdGVGcmFtZSA9IG5ldyBjYy5TcHJpdGVGcmFtZSgpO1xyXG4gICAgICAgIHNwcml0ZUZyYW1lLnNldFRleHR1cmUodGV4dHVyZSk7XHJcbiAgICAgICAgdGhpcy53YXRlclJlbmRlcmVyQ2FtZXJhLnRhcmdldFRleHR1cmUgPSB0ZXh0dXJlO1xyXG4gICAgICAgIHRoaXMud2F0ZXJSZW5kZXJlclBhc3MyLnNwcml0ZUZyYW1lID0gc3ByaXRlRnJhbWU7XHJcblx0fVxyXG5cclxuXHRTZXR1cFdvcmxkKCkge1xyXG5cdFx0Ly8gZW5hYmxlIHBoeXNpY3MgbWFuYWdlclxyXG5cdFx0bGV0IHBoeXNpY3NNYW5hZ2VyID0gY2MuZGlyZWN0b3IuZ2V0UGh5c2ljc01hbmFnZXIoKVxyXG5cdFx0cGh5c2ljc01hbmFnZXIuZW5hYmxlZCA9IHRydWU7XHJcblxyXG5cdFx0bGV0IHdvcmxkID0gdGhpcy5fd29ybGQgPSBwaHlzaWNzTWFuYWdlci5fd29ybGQ7Ly8gbmV3IGIyLldvcmxkKG5ldyBiMi5WZWMyKDAsIC0xNS4wKSk7XHJcblx0XHR2YXIgcHNkID0gbmV3IGIyLlBhcnRpY2xlU3lzdGVtRGVmKCk7XHJcblx0XHRwc2QucmFkaXVzID0gMC4zNTtcclxuXHRcdC8vIHBzZC5kYW1waW5nU3RyZW5ndGggPSAxLjU7XHJcblx0XHRwc2QudmlzY291c1N0cmVuZ3RoID0gMDtcclxuXHJcblx0XHR0aGlzLl9wYXJ0aWNsZXMgPSB3b3JsZC5DcmVhdGVQYXJ0aWNsZVN5c3RlbShwc2QpO1xyXG5cdH1cclxuXHJcblx0Q3JlYXRlUGFydGljbGVzR3JvdXAoKSB7XHJcblx0XHRsZXQgUFRNX1JBVElPID0gY2MuUGh5c2ljc01hbmFnZXIuUFRNX1JBVElPO1xyXG5cdFx0dmFyIGJveFNpemUgPSB0aGlzLnBhcnRpY2xlQm94LmdldENvbnRlbnRTaXplKCk7XHJcblx0XHR2YXIgYm94UG9zID0gdGhpcy5wYXJ0aWNsZUJveC5nZXRQb3NpdGlvbigpO1xyXG5cdFx0dmFyIHNpemUgPSBjYy53aW5TaXplO1xyXG5cdFx0dmFyIGJveCA9IG5ldyBiMi5Qb2x5Z29uU2hhcGUoKTtcclxuXHJcblx0XHQvLyBodHRwczovL2dvb2dsZS5naXRodWIuaW8vbGlxdWlkZnVuL0FQSS1SZWYvaHRtbC9jbGFzc2IyX3BvbHlnb25fc2hhcGUuaHRtbCNhODkwNjkwMjUwMTE1NDgzZGE2YzdkNjk4MjliZTA4N2VcclxuXHRcdC8vIEJ1aWxkIHZlcnRpY2VzIHRvIHJlcHJlc2VudCBhbiBvcmllbnRlZCBib3guXHJcblx0XHQvLyBib3jnmoTlpKflsI/lvbHlk43nspLlrZDnmoTmlbDph49cclxuXHRcdGJveC5TZXRBc0JveChcclxuXHRcdFx0Ym94U2l6ZS53aWR0aCAvIDIgLyBQVE1fUkFUSU8sXHJcblx0XHRcdGJveFNpemUuaGVpZ2h0IC8gMiAvIFBUTV9SQVRJTylcclxuXHJcblx0XHR2YXIgcGFydGljbGVHcm91cERlZiA9IG5ldyBiMi5QYXJ0aWNsZUdyb3VwRGVmKCk7XHJcblx0XHRwYXJ0aWNsZUdyb3VwRGVmLnNoYXBlID0gYm94O1xyXG5cdFx0cGFydGljbGVHcm91cERlZi5mbGFncyA9IGIyLndhdGVyUGFydGljbGU7XHJcblx0XHRwYXJ0aWNsZUdyb3VwRGVmLnBvc2l0aW9uLlNldChcclxuXHRcdFx0KGJveFBvcy54ICsgc2l6ZS53aWR0aC8yKSAvIFBUTV9SQVRJTyxcclxuXHRcdFx0KGJveFBvcy55ICsgc2l6ZS5oZWlnaHQvMikgLyBQVE1fUkFUSU8pO1xyXG5cclxuXHRcdHRoaXMuX3BhcnRpY2xlR3JvdXAgPSB0aGlzLl9wYXJ0aWNsZXMuQ3JlYXRlUGFydGljbGVHcm91cChwYXJ0aWNsZUdyb3VwRGVmKTtcclxuXHRcdHRoaXMubWV0YUJhbGxzUmVuZGVyZXIuU2V0UGFydGljbGVzKHRoaXMuX3BhcnRpY2xlcyk7XHJcblxyXG5cdFx0bGV0IHZlcnRzQ291bnQgPSB0aGlzLl9wYXJ0aWNsZXMuR2V0UGFydGljbGVDb3VudCgpO1xyXG5cdFx0Y29uc29sZS5sb2codmVydHNDb3VudCk7XHJcblx0fVxyXG5cclxuICAgIEdlbmVyYXRlV2F0ZXIoKSB7XHJcblx0XHR0aGlzLlJlc2V0UGFydGljbGVHcm91cCgpO1xyXG5cclxuXHRcdC8vIHJlLWNyZWF0ZSBwYXJ0aWNsZXMgaW4gbmV4dCB0aWNrXHJcblx0XHQvLyBvdGhlcndpc2Ugb2xkIHBhcnRpY2xlIHN5c3RlbSBpcyBub3QgY29ycmVjdGx5IHJlbGVhc2VkXHJcblx0XHQvLyB0aGlzIGlzIGEgbm9uLXJlcGVhdCBzY2hlZHVsZVxyXG5cdFx0bGV0IHRoYXQgPSB0aGlzO1xyXG5cdFx0Y2MuZGlyZWN0b3IuZ2V0U2NoZWR1bGVyKCkuc2NoZWR1bGUoKCkgPT4ge1xyXG5cdFx0XHR0aGF0LkNyZWF0ZVBhcnRpY2xlc0dyb3VwKCk7XHJcblx0XHR9LCB0aGlzLm5vZGUsIDAsIDAsIDAsIGZhbHNlKTtcclxuXHR9XHJcblxyXG4gICAgUmVzZXRQYXJ0aWNsZUdyb3VwKCkge1xyXG5cdFx0aWYgKHRoaXMuX3BhcnRpY2xlR3JvdXAgIT0gbnVsbCkge1xyXG5cdFx0XHR0aGlzLl9wYXJ0aWNsZUdyb3VwLkRlc3Ryb3lQYXJ0aWNsZXMoZmFsc2UpO1xyXG5cdFx0XHR0aGlzLl9wYXJ0aWNsZXMuRGVzdHJveVBhcnRpY2xlR3JvdXAodGhpcy5fcGFydGljbGVHcm91cCk7XHJcblxyXG5cdFx0XHR0aGlzLl9wYXJ0aWNsZUdyb3VwID0gbnVsbDtcclxuXHRcdH1cclxuICAgIH1cclxufVxyXG5cclxudmFyIGVuYWJsZUxvd0xldmVsT3B0aW1pemUgPSB0cnVlO1xyXG5pZiAoZW5hYmxlTG93TGV2ZWxPcHRpbWl6ZSkge1xyXG5cdGNjLmdhbWUub25jZShjYy5nYW1lLkVWRU5UX0VOR0lORV9JTklURUQsICgpID0+IHtcclxuXHRcdC8vIGIyUGFydGljbGVTeXN0ZW0ucHJvdG90eXBlLkZpbmRDb250YWN0c19SZWZlcmVuY2UgPSBmdW5jdGlvbiAoY29udGFjdHMpIHtcclxuXHRcdC8vQHRzLWlnbm9yZVxyXG5cdFx0YjIuUGFydGljbGVTeXN0ZW0ucHJvdG90eXBlLkZpbmRDb250YWN0c19SZWZlcmVuY2UgPSBmdW5jdGlvbiAoY29udGFjdHMpIHtcclxuXHRcdFx0aWYgKCF0aGlzLm1fZmxhZ3NCdWZmZXIuZGF0YSkge1xyXG5cdFx0XHRcdHRocm93IG5ldyBFcnJvcigpO1xyXG5cdFx0XHR9XHJcblx0XHRcdGlmICghdGhpcy5tX3Bvc2l0aW9uQnVmZmVyLmRhdGEpIHtcclxuXHRcdFx0XHR0aHJvdyBuZXcgRXJyb3IoKTtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0dmFyIHBvc19kYXRhID0gdGhpcy5tX3Bvc2l0aW9uQnVmZmVyLmRhdGE7XHJcblx0XHRcdHZhciBzcXVhcmVkRGlhbWV0ZXIgPSB0aGlzLm1fc3F1YXJlZERpYW1ldGVyO1xyXG5cdFx0XHR2YXIgaW52ZXJzZURpYW1ldGVyID0gdGhpcy5tX2ludmVyc2VEaWFtZXRlcjtcclxuXHJcblx0XHRcdC8vIERFQlVHOiBiMkFzc2VydChjb250YWN0cyA9PT0gdGhpcy5tX2NvbnRhY3RCdWZmZXIpO1xyXG5cdFx0XHR2YXIgYmVnaW5Qcm94eSA9IDA7XHJcblx0XHRcdHZhciBlbmRQcm94eSA9IHRoaXMubV9wcm94eUJ1ZmZlci5jb3VudDtcclxuXHRcdFx0dGhpcy5tX2NvbnRhY3RCdWZmZXIuY291bnQgPSAwO1xyXG5cdFx0XHQvLyBsZXQgY29udGFjdEJ1ZmZlciA9IHRoaXMubV9jb250YWN0QnVmZmVyO1xyXG5cdFx0XHR2YXIgcHJveHlEYXRhID0gdGhpcy5tX3Byb3h5QnVmZmVyLmRhdGE7XHJcblx0XHRcdC8vQHRzLWlnbm9yZVxyXG5cdFx0XHR2YXIgY29tcHV0ZVJlbGF0aXZlVGFnID0gYjIuUGFydGljbGVTeXN0ZW0uY29tcHV0ZVJlbGF0aXZlVGFnO1xyXG5cdFx0XHQvLyB2YXIgQWRkQ29udGFjdCA9IHRoaXMuQWRkQ29udGFjdDIuYmluZCh0aGlzKTtcclxuXHJcblx0XHRcdHZhciBkYXRhQTtcclxuXHRcdFx0dmFyIHRhZ0EgPSAwO1xyXG5cdFx0XHR2YXIgaW5kZXhBID0gMDtcclxuXHRcdFx0dmFyIHJpZ2h0VGFnID0gMDtcclxuXHRcdFx0dmFyIGRhdGFCO1xyXG5cclxuXHRcdFx0dmFyIHBvc19kYXRhID0gdGhpcy5tX3Bvc2l0aW9uQnVmZmVyLmRhdGE7XHJcblx0XHRcdHZhciBmbGFnQnVmZmVyRGF0YSA9IHRoaXMubV9mbGFnc0J1ZmZlci5kYXRhO1xyXG5cdFx0XHR2YXIgZmxhZ0J1ZmZlckRhdGFBO1xyXG5cdFx0XHR2YXIgaW5kZXhCID0gMDtcclxuXHRcdFx0dmFyIHBvc19kYXRhQTtcclxuXHRcdFx0dmFyIHBvc19kYXRhQjtcclxuXHJcblx0XHRcdHZhciBheCA9IDAsIGF5ID0gMCwgYnggPSAwLCBieSA9IDAsIGR4ID0gMCwgZHkgPSAwO1xyXG5cdFx0XHR2YXIgZGlzdEJ0UGFydGljbGVzU3EgPSAwO1xyXG5cclxuXHRcdFx0dmFyIGJvdHRvbUxlZnRUYWcgPSAwO1xyXG5cdFx0XHR2YXIgYm90dG9tUmlnaHRUYWcgPSAwO1xyXG5cclxuXHRcdFx0dmFyIGlzRmluID0gaXNGaW5pdGU7XHJcblxyXG5cdFx0XHRmb3IgKHZhciBhID0gYmVnaW5Qcm94eSwgYyA9IGJlZ2luUHJveHk7IGEgPCBlbmRQcm94eTsgKythKSB7XHJcblx0XHRcdFx0ZGF0YUEgPSBwcm94eURhdGFbYV07XHJcblx0XHRcdFx0dGFnQSA9IGRhdGFBLnRhZztcclxuXHRcdFx0XHRpbmRleEEgPSBkYXRhQS5pbmRleDtcclxuXHRcdFx0XHRwb3NfZGF0YUEgPSBwb3NfZGF0YVtpbmRleEFdO1xyXG5cdFx0XHRcdGZsYWdCdWZmZXJEYXRhQSA9IGZsYWdCdWZmZXJEYXRhW2luZGV4QV07XHJcblxyXG5cdFx0XHRcdHJpZ2h0VGFnID0gY29tcHV0ZVJlbGF0aXZlVGFnKHRhZ0EsIDEsIDApO1xyXG5cdFx0XHRcdGZvciAodmFyIGIgPSBhICsgMTsgYiA8IGVuZFByb3h5OyArK2IpIHtcclxuXHRcdFx0XHRcdGRhdGFCID0gcHJveHlEYXRhW2JdO1xyXG5cdFx0XHRcdFx0aWYgKHJpZ2h0VGFnIDwgZGF0YUIudGFnKSB7XHJcblx0XHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHJcblx0XHRcdFx0XHQvLyAtLS0tLS0tIEFkZENvbnRhY3QoaW5kZXhBLCBwcm94eURhdGFbYl0uaW5kZXgsIGNvbnRhY3RCdWZmZXIpO1xyXG5cdFx0XHRcdFx0aW5kZXhCID0gZGF0YUIuaW5kZXg7XHJcblx0XHRcdFx0XHQvLyBwb3NfZGF0YUEgPSBwb3NfZGF0YVtpbmRleEFdO1xyXG5cdFx0XHRcdFx0cG9zX2RhdGFCID0gcG9zX2RhdGFbaW5kZXhCXTtcclxuXHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0Ly8gREVCVUc6IGIyQXNzZXJ0KGNvbnRhY3RzID09PSB0aGlzLm1fY29udGFjdEJ1ZmZlcik7XHJcblx0XHRcdFx0XHQvLy9iMlZlYzIgZCA9IG1fcG9zaXRpb25CdWZmZXIuZGF0YVtiXSAtIG1fcG9zaXRpb25CdWZmZXIuZGF0YVthXTtcclxuXHJcblx0XHRcdFx0XHRieCA9IHBvc19kYXRhQi54O1xyXG5cdFx0XHRcdFx0YnkgPSBwb3NfZGF0YUIueTtcclxuXHRcdFx0XHRcdGF4ID0gcG9zX2RhdGFBLng7XHJcblx0XHRcdFx0XHRheSA9IHBvc19kYXRhQS55O1xyXG5cclxuXHRcdFx0XHRcdGR4ID0gYnggLSBheDtcclxuXHRcdFx0XHRcdGR5ID0gYnkgLSBheTtcclxuXHRcdFx0XHRcdC8vIHZhciBkID0gYjIuVmVjMi5TdWJWVihwb3NfZGF0YVtiXSwgcG9zX2RhdGFbYV0sIHNfZCk7XHJcblxyXG5cdFx0XHRcdFx0ZGlzdEJ0UGFydGljbGVzU3EgPSBkeCAqIGR4ICsgZHkgKiBkeTtcclxuXHRcdFx0XHRcdC8vIHZhciBkaXN0QnRQYXJ0aWNsZXNTcSA9IGIyLlZlYzIuRG90VlYoZCwgZCk7XHJcblx0XHRcdFx0XHRpZiAoZGlzdEJ0UGFydGljbGVzU3EgPCBzcXVhcmVkRGlhbWV0ZXIpIHtcclxuXHRcdFx0XHRcdFx0dmFyIGludkQgPSAxIC8gTWF0aC5zcXJ0KGRpc3RCdFBhcnRpY2xlc1NxKTtcclxuXHRcdFx0XHRcdFx0Ly8gdmFyIGludkQgPSBiMi5JbnZTcXJ0KGRpc3RCdFBhcnRpY2xlc1NxKTtcclxuXHRcdFx0XHRcdFx0aWYgKCFpc0ZpbihpbnZEKSkge1xyXG5cdFx0XHRcdFx0XHRcdGludkQgPSAxLjk4MTc3NTM3ZSswMTk7XHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0Ly8vYjJQYXJ0aWNsZUNvbnRhY3QmIGNvbnRhY3QgPSBjb250YWN0cy5BcHBlbmQoKTtcclxuXHRcdFx0XHRcdFx0dmFyIGNvbnRhY3QgPSB0aGlzLm1fY29udGFjdEJ1ZmZlci5kYXRhW3RoaXMubV9jb250YWN0QnVmZmVyLkFwcGVuZCgpXTtcclxuXHRcdFx0XHRcdFx0Y29udGFjdC5pbmRleEEgPSBpbmRleEE7XHJcblx0XHRcdFx0XHRcdGNvbnRhY3QuaW5kZXhCID0gaW5kZXhCO1xyXG5cdFx0XHRcdFx0XHRjb250YWN0LmZsYWdzID0gZmxhZ0J1ZmZlckRhdGFBIHwgZmxhZ0J1ZmZlckRhdGFbaW5kZXhCXTtcclxuXHRcdFx0XHRcdFx0Y29udGFjdC53ZWlnaHQgPSAxIC0gZGlzdEJ0UGFydGljbGVzU3EgKiBpbnZEICogaW52ZXJzZURpYW1ldGVyO1xyXG5cdFx0XHRcdFx0XHQvLy9jb250YWN0LlNldE5vcm1hbChpbnZEICogZCk7XHJcblxyXG5cdFx0XHRcdFx0XHRjb250YWN0Lm5vcm1hbC54ID0gaW52RCAqIGR4O1xyXG5cdFx0XHRcdFx0XHRjb250YWN0Lm5vcm1hbC55ID0gaW52RCAqIGR5O1xyXG5cdFx0XHRcdFx0XHQvLyBiMi5WZWMyLk11bFNWKGludkQsIGQsIGNvbnRhY3Qubm9ybWFsKTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdC8vIGVuZCAtLS0tLS0tIEFkZENvbnRhY3QoaW5kZXhBLCBwcm94eURhdGFbYl0uaW5kZXgsIGNvbnRhY3RCdWZmZXIpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRib3R0b21MZWZ0VGFnID0gY29tcHV0ZVJlbGF0aXZlVGFnKHRhZ0EsIC0xLCAxKTtcclxuXHRcdFx0XHRmb3IgKDsgYyA8IGVuZFByb3h5OyArK2MpIHtcclxuXHRcdFx0XHRcdGlmIChib3R0b21MZWZ0VGFnIDw9IHByb3h5RGF0YVtjXS50YWcpIHtcclxuXHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdGJvdHRvbVJpZ2h0VGFnID0gY29tcHV0ZVJlbGF0aXZlVGFnKHRhZ0EsIDEsIDEpO1xyXG5cdFx0XHRcdGZvciAodmFyIGIgPSBjOyBiIDwgZW5kUHJveHk7ICsrYikge1xyXG5cdFx0XHRcdFx0ZGF0YUIgPSBwcm94eURhdGFbYl07XHJcblx0XHRcdFx0XHRpZiAoYm90dG9tUmlnaHRUYWcgPCBkYXRhQi50YWcpIHtcclxuXHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdC8vIC0tLS0tLS0gQWRkQ29udGFjdChpbmRleEEsIHByb3h5RGF0YVtiXS5pbmRleCwgY29udGFjdEJ1ZmZlcik7XHJcblx0XHRcdFx0XHRpbmRleEIgPSBkYXRhQi5pbmRleDtcclxuXHRcdFx0XHRcdC8vIHBvc19kYXRhQSA9IHBvc19kYXRhW2luZGV4QV07XHJcblx0XHRcdFx0XHRwb3NfZGF0YUIgPSBwb3NfZGF0YVtpbmRleEJdO1xyXG5cdFx0XHRcdFx0Ly8gREVCVUc6IGIyQXNzZXJ0KGNvbnRhY3RzID09PSB0aGlzLm1fY29udGFjdEJ1ZmZlcik7XHJcblx0XHRcdFx0XHQvLy9iMlZlYzIgZCA9IG1fcG9zaXRpb25CdWZmZXIuZGF0YVtiXSAtIG1fcG9zaXRpb25CdWZmZXIuZGF0YVthXTtcclxuXHJcblx0XHRcdFx0XHRieCA9IHBvc19kYXRhQi54O1xyXG5cdFx0XHRcdFx0YnkgPSBwb3NfZGF0YUIueTtcclxuXHRcdFx0XHRcdGF4ID0gcG9zX2RhdGFBLng7XHJcblx0XHRcdFx0XHRheSA9IHBvc19kYXRhQS55O1xyXG5cclxuXHRcdFx0XHRcdGR4ID0gYnggLSBheDtcclxuXHRcdFx0XHRcdGR5ID0gYnkgLSBheTtcclxuXHRcdFx0XHRcdC8vIHZhciBkID0gYjIuVmVjMi5TdWJWVihwb3NfZGF0YVtiXSwgcG9zX2RhdGFbYV0sIHNfZCk7XHJcblxyXG5cdFx0XHRcdFx0ZGlzdEJ0UGFydGljbGVzU3EgPSBkeCAqIGR4ICsgZHkgKiBkeTtcclxuXHRcdFx0XHRcdC8vIHZhciBkaXN0QnRQYXJ0aWNsZXNTcSA9IGIyLlZlYzIuRG90VlYoZCwgZCk7XHJcblx0XHRcdFx0XHRpZiAoZGlzdEJ0UGFydGljbGVzU3EgPCBzcXVhcmVkRGlhbWV0ZXIpIHtcclxuXHRcdFx0XHRcdFx0dmFyIGludkQgPSAxIC8gTWF0aC5zcXJ0KGRpc3RCdFBhcnRpY2xlc1NxKTtcclxuXHRcdFx0XHRcdFx0Ly8gdmFyIGludkQgPSBiMi5JbnZTcXJ0KGRpc3RCdFBhcnRpY2xlc1NxKTtcclxuXHRcdFx0XHRcdFx0aWYgKCFpc0ZpbihpbnZEKSkge1xyXG5cdFx0XHRcdFx0XHRcdGludkQgPSAxLjk4MTc3NTM3ZSswMTk7XHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0Ly8vYjJQYXJ0aWNsZUNvbnRhY3QmIGNvbnRhY3QgPSBjb250YWN0cy5BcHBlbmQoKTtcclxuXHRcdFx0XHRcdFx0dmFyIGNvbnRhY3QgPSB0aGlzLm1fY29udGFjdEJ1ZmZlci5kYXRhW3RoaXMubV9jb250YWN0QnVmZmVyLkFwcGVuZCgpXTtcclxuXHRcdFx0XHRcdFx0Y29udGFjdC5pbmRleEEgPSBpbmRleEE7XHJcblx0XHRcdFx0XHRcdGNvbnRhY3QuaW5kZXhCID0gaW5kZXhCO1xyXG5cdFx0XHRcdFx0XHRjb250YWN0LmZsYWdzID0gZmxhZ0J1ZmZlckRhdGFBIHwgZmxhZ0J1ZmZlckRhdGFbaW5kZXhCXTtcclxuXHRcdFx0XHRcdFx0Y29udGFjdC53ZWlnaHQgPSAxIC0gZGlzdEJ0UGFydGljbGVzU3EgKiBpbnZEICogaW52ZXJzZURpYW1ldGVyO1xyXG5cdFx0XHRcdFx0XHQvLy9jb250YWN0LlNldE5vcm1hbChpbnZEICogZCk7XHJcblxyXG5cdFx0XHRcdFx0XHRjb250YWN0Lm5vcm1hbC54ID0gaW52RCAqIGR4O1xyXG5cdFx0XHRcdFx0XHRjb250YWN0Lm5vcm1hbC55ID0gaW52RCAqIGR5O1xyXG5cdFx0XHRcdFx0XHQvLyBiMi5WZWMyLk11bFNWKGludkQsIGQsIGNvbnRhY3Qubm9ybWFsKTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdC8vIGVuZCAtLS0tLS0tIEFkZENvbnRhY3QoaW5kZXhBLCBwcm94eURhdGFbYl0uaW5kZXgsIGNvbnRhY3RCdWZmZXIpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0fTtcclxuXHR9KTtcclxufVxyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/EqualScallingSprite/EqualScalingSprite.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8b22518JLpEu6AXif9T1DNt', 'EqualScalingSprite');
// Shader/EqualScallingSprite/EqualScalingSprite.ts

"use strict";
/****************************************************************************
 Author: GT <caogtaa@gmail.com>
 https://caogtaa.github.io
****************************************************************************/
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var EqualScalingAssembler_1 = require("./EqualScalingAssembler");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var EqualScalingSprite = /** @class */ (function (_super) {
    __extends(EqualScalingSprite, _super);
    function EqualScalingSprite() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EqualScalingSprite.prototype._resetAssembler = function () {
        this.setVertsDirty();
        var assembler = this._assembler = new EqualScalingAssembler_1.default();
        assembler.init(this);
    };
    EqualScalingSprite = __decorate([
        ccclass
    ], EqualScalingSprite);
    return EqualScalingSprite;
}(cc.Sprite));
exports.default = EqualScalingSprite;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvRXF1YWxTY2FsbGluZ1Nwcml0ZS9FcXVhbFNjYWxpbmdTcHJpdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBOzs7NkVBRzZFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFN0UsaUVBQTREO0FBRXRELElBQUEsS0FBc0IsRUFBRSxDQUFDLFVBQVUsRUFBbEMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFpQixDQUFDO0FBRzFDO0lBQWdELHNDQUFTO0lBQXpEOztJQU1BLENBQUM7SUFMRyw0Q0FBZSxHQUFmO1FBQ0ksSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3JCLElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSwrQkFBcUIsRUFBRSxDQUFDO1FBQzlELFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDekIsQ0FBQztJQUxnQixrQkFBa0I7UUFEdEMsT0FBTztPQUNhLGtCQUFrQixDQU10QztJQUFELHlCQUFDO0NBTkQsQUFNQyxDQU4rQyxFQUFFLENBQUMsTUFBTSxHQU14RDtrQkFOb0Isa0JBQWtCIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiBBdXRob3I6IEdUIDxjYW9ndGFhQGdtYWlsLmNvbT5cbiBodHRwczovL2Nhb2d0YWEuZ2l0aHViLmlvXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuXG5pbXBvcnQgRXF1YWxTY2FsaW5nQXNzZW1ibGVyIGZyb20gXCIuL0VxdWFsU2NhbGluZ0Fzc2VtYmxlclwiO1xuXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEVxdWFsU2NhbGluZ1Nwcml0ZSBleHRlbmRzIGNjLlNwcml0ZSB7XG4gICAgX3Jlc2V0QXNzZW1ibGVyKCkge1xuICAgICAgICB0aGlzLnNldFZlcnRzRGlydHkoKTtcbiAgICAgICAgbGV0IGFzc2VtYmxlciA9IHRoaXMuX2Fzc2VtYmxlciA9IG5ldyBFcXVhbFNjYWxpbmdBc3NlbWJsZXIoKTtcbiAgICAgICAgYXNzZW1ibGVyLmluaXQodGhpcyk7XG4gICAgfVxufVxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/LayeredBatching/LayeredBatchingRootRenderer.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '7e264FDcplMY5rNb2sCjRtf', 'LayeredBatchingRootRenderer');
// Shader/LayeredBatching/LayeredBatchingRootRenderer.ts

"use strict";
/****************************************************************************
 Author: GT <caogtaa@gmail.com>
 https://caogtaa.github.io
****************************************************************************/
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var LayeredBatchingAssembler_1 = require("./LayeredBatchingAssembler");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var LayeredBatchingRootRenderer = /** @class */ (function (_super) {
    __extends(LayeredBatchingRootRenderer, _super);
    function LayeredBatchingRootRenderer() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    LayeredBatchingRootRenderer.prototype.onEnable = function () {
        _super.prototype.onEnable.call(this);
        if (!CC_EDITOR && !CC_NATIVERENDERER)
            this.node._renderFlag |= cc.RenderFlow.FLAG_POST_RENDER;
        // this.node._renderFlag |= cc.RenderFlow.FLAG_RENDER;
    };
    LayeredBatchingRootRenderer.prototype._resetAssembler = function () {
        this.setVertsDirty();
        var assembler = this._assembler = new LayeredBatchingAssembler_1.default();
        assembler.init(this);
    };
    LayeredBatchingRootRenderer = __decorate([
        ccclass
    ], LayeredBatchingRootRenderer);
    return LayeredBatchingRootRenderer;
}(cc.Sprite));
exports.default = LayeredBatchingRootRenderer;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvTGF5ZXJlZEJhdGNoaW5nL0xheWVyZWRCYXRjaGluZ1Jvb3RSZW5kZXJlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7Ozs2RUFHNkU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUU3RSx1RUFBa0U7QUFHNUQsSUFBQSxLQUFzQixFQUFFLENBQUMsVUFBVSxFQUFsQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWlCLENBQUM7QUFHMUM7SUFBeUQsK0NBQVM7SUFBbEU7O0lBY0EsQ0FBQztJQWJHLDhDQUFRLEdBQVI7UUFDSSxpQkFBTSxRQUFRLFdBQUUsQ0FBQztRQUNqQixJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsaUJBQWlCO1lBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxJQUFJLEVBQUUsQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUM7UUFFNUQsc0RBQXNEO0lBQzFELENBQUM7SUFFRCxxREFBZSxHQUFmO1FBQ0ksSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3JCLElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxrQ0FBd0IsRUFBRSxDQUFDO1FBQ2pFLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDekIsQ0FBQztJQWJnQiwyQkFBMkI7UUFEL0MsT0FBTztPQUNhLDJCQUEyQixDQWMvQztJQUFELGtDQUFDO0NBZEQsQUFjQyxDQWR3RCxFQUFFLENBQUMsTUFBTSxHQWNqRTtrQkFkb0IsMkJBQTJCIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiBBdXRob3I6IEdUIDxjYW9ndGFhQGdtYWlsLmNvbT5cbiBodHRwczovL2Nhb2d0YWEuZ2l0aHViLmlvXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuXG5pbXBvcnQgTGF5ZXJlZEJhdGNoaW5nQXNzZW1ibGVyIGZyb20gXCIuL0xheWVyZWRCYXRjaGluZ0Fzc2VtYmxlclwiO1xuXG5cbmNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xuXG5AY2NjbGFzc1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTGF5ZXJlZEJhdGNoaW5nUm9vdFJlbmRlcmVyIGV4dGVuZHMgY2MuU3ByaXRlIHtcbiAgICBvbkVuYWJsZSgpIHtcbiAgICAgICAgc3VwZXIub25FbmFibGUoKTtcbiAgICAgICAgaWYgKCFDQ19FRElUT1IgJiYgIUNDX05BVElWRVJFTkRFUkVSKVxuICAgICAgICAgICAgdGhpcy5ub2RlLl9yZW5kZXJGbGFnIHw9IGNjLlJlbmRlckZsb3cuRkxBR19QT1NUX1JFTkRFUjtcblxuICAgICAgICAvLyB0aGlzLm5vZGUuX3JlbmRlckZsYWcgfD0gY2MuUmVuZGVyRmxvdy5GTEFHX1JFTkRFUjtcbiAgICB9XG5cbiAgICBfcmVzZXRBc3NlbWJsZXIoKSB7XG4gICAgICAgIHRoaXMuc2V0VmVydHNEaXJ0eSgpO1xuICAgICAgICBsZXQgYXNzZW1ibGVyID0gdGhpcy5fYXNzZW1ibGVyID0gbmV3IExheWVyZWRCYXRjaGluZ0Fzc2VtYmxlcigpO1xuICAgICAgICBhc3NlbWJsZXIuaW5pdCh0aGlzKTtcbiAgICB9XG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/MovingBG/MovingBGSprite.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd6bb3Z+1ARGDapKZIvBpCUs', 'MovingBGSprite');
// Shader/MovingBG/MovingBGSprite.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-13 02:44:17
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:03:32
*/
var MovingBGAssembler_1 = require("./MovingBGAssembler");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var MovingBGSprite = /** @class */ (function (_super) {
    __extends(MovingBGSprite, _super);
    function MovingBGSprite() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._moveSpeed = cc.Vec2.ZERO;
        return _this;
    }
    Object.defineProperty(MovingBGSprite.prototype, "moveSpeed", {
        get: function () {
            return this._moveSpeed;
        },
        set: function (value) {
            this._moveSpeed = value;
            this.FlushProperties();
        },
        enumerable: false,
        configurable: true
    });
    MovingBGSprite.prototype.FlushProperties = function () {
        //@ts-ignore
        var assembler = this._assembler;
        if (!assembler)
            return;
        assembler.moveSpeed = this._moveSpeed;
        this.setVertsDirty();
    };
    MovingBGSprite.prototype.onEnable = function () {
        _super.prototype.onEnable.call(this);
    };
    // // 使用cc.Sprite默认逻辑
    MovingBGSprite.prototype._resetAssembler = function () {
        this.setVertsDirty();
        var assembler = this._assembler = new MovingBGAssembler_1.default();
        this.FlushProperties();
        assembler.init(this);
        //@ts-ignore
        this._updateColor(); // may be no need
    };
    __decorate([
        property(cc.Vec2)
    ], MovingBGSprite.prototype, "moveSpeed", null);
    __decorate([
        property(cc.Vec2)
    ], MovingBGSprite.prototype, "_moveSpeed", void 0);
    MovingBGSprite = __decorate([
        ccclass
    ], MovingBGSprite);
    return MovingBGSprite;
}(cc.Sprite));
exports.default = MovingBGSprite;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvTW92aW5nQkcvTW92aW5nQkdTcHJpdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLGdEQUFnRDtBQUNoRCw0QkFBNEI7QUFDNUIsK0NBQStDO0FBQy9DLGdFQUFnRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRWhFOzs7O0VBSUU7QUFFRix5REFBb0Q7QUFFOUMsSUFBQSxLQUFzQixFQUFFLENBQUMsVUFBVSxFQUFsQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWlCLENBQUM7QUFHMUM7SUFBNEMsa0NBQVM7SUFBckQ7UUFBQSxxRUFzQ0M7UUEzQkcsZ0JBQVUsR0FBWSxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQzs7SUEyQnZDLENBQUM7SUFwQ0csc0JBQUkscUNBQVM7YUFJYjtZQUNJLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQztRQUMzQixDQUFDO2FBTkQsVUFBYyxLQUFjO1lBQ3hCLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO1lBQ3hCLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUMzQixDQUFDOzs7T0FBQTtJQVFNLHdDQUFlLEdBQXRCO1FBQ0ksWUFBWTtRQUNaLElBQUksU0FBUyxHQUFzQixJQUFJLENBQUMsVUFBVSxDQUFDO1FBQ25ELElBQUksQ0FBQyxTQUFTO1lBQ1YsT0FBTztRQUVYLFNBQVMsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQztRQUN0QyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDekIsQ0FBQztJQUVELGlDQUFRLEdBQVI7UUFDSSxpQkFBTSxRQUFRLFdBQUUsQ0FBQztJQUNyQixDQUFDO0lBRUQscUJBQXFCO0lBQ3JCLHdDQUFlLEdBQWY7UUFDSSxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDckIsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLDJCQUFpQixFQUFFLENBQUM7UUFDMUQsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBRXZCLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFckIsWUFBWTtRQUNaLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFRLGlCQUFpQjtJQUNqRCxDQUFDO0lBbkNEO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7bURBSWpCO0lBTUQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQztzREFDaUI7SUFYbEIsY0FBYztRQURsQyxPQUFPO09BQ2EsY0FBYyxDQXNDbEM7SUFBRCxxQkFBQztDQXRDRCxBQXNDQyxDQXRDMkMsRUFBRSxDQUFDLE1BQU0sR0FzQ3BEO2tCQXRDb0IsY0FBYyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIENvcHlyaWdodCAyMDIwIENhbyBHYW90aW5nPGNhb2d0YWFAZ21haWwuY29tPlxuLy8gaHR0cHM6Ly9jYW9ndGFhLmdpdGh1Yi5pb1xuLy8gVGhpcyBmaWxlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS5cbi8vIExpY2Vuc2UgdGV4dCBhdmFpbGFibGUgYXQgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVRcblxuLypcbiAqIERhdGU6IDIwMjAtMDctMTMgMDI6NDQ6MTdcbiAqIExhc3RFZGl0b3JzOiBHVDxjYW9ndGFhQGdtYWlsLmNvbT5cbiAqIExhc3RFZGl0VGltZTogMjAyMC0wNy0yMiAxNDowMzozMlxuKi8gXG5cbmltcG9ydCBNb3ZpbmdCR0Fzc2VtYmxlciBmcm9tIFwiLi9Nb3ZpbmdCR0Fzc2VtYmxlclwiO1xuXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE1vdmluZ0JHU3ByaXRlIGV4dGVuZHMgY2MuU3ByaXRlIHtcbiAgICBAcHJvcGVydHkoY2MuVmVjMilcbiAgICBzZXQgbW92ZVNwZWVkKHZhbHVlOiBjYy5WZWMyKSB7XG4gICAgICAgIHRoaXMuX21vdmVTcGVlZCA9IHZhbHVlO1xuICAgICAgICB0aGlzLkZsdXNoUHJvcGVydGllcygpO1xuICAgIH1cbiAgICBnZXQgbW92ZVNwZWVkKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fbW92ZVNwZWVkO1xuICAgIH1cblxuICAgIEBwcm9wZXJ0eShjYy5WZWMyKVxuICAgIF9tb3ZlU3BlZWQ6IGNjLlZlYzIgPSBjYy5WZWMyLlpFUk87XG5cbiAgICBwdWJsaWMgRmx1c2hQcm9wZXJ0aWVzKCkge1xuICAgICAgICAvL0B0cy1pZ25vcmVcbiAgICAgICAgbGV0IGFzc2VtYmxlcjogTW92aW5nQkdBc3NlbWJsZXIgPSB0aGlzLl9hc3NlbWJsZXI7XG4gICAgICAgIGlmICghYXNzZW1ibGVyKVxuICAgICAgICAgICAgcmV0dXJuO1xuXG4gICAgICAgIGFzc2VtYmxlci5tb3ZlU3BlZWQgPSB0aGlzLl9tb3ZlU3BlZWQ7XG4gICAgICAgIHRoaXMuc2V0VmVydHNEaXJ0eSgpO1xuICAgIH1cblxuICAgIG9uRW5hYmxlICgpIHtcbiAgICAgICAgc3VwZXIub25FbmFibGUoKTtcbiAgICB9XG5cbiAgICAvLyAvLyDkvb/nlKhjYy5TcHJpdGXpu5jorqTpgLvovpFcbiAgICBfcmVzZXRBc3NlbWJsZXIoKSB7XG4gICAgICAgIHRoaXMuc2V0VmVydHNEaXJ0eSgpO1xuICAgICAgICBsZXQgYXNzZW1ibGVyID0gdGhpcy5fYXNzZW1ibGVyID0gbmV3IE1vdmluZ0JHQXNzZW1ibGVyKCk7XG4gICAgICAgIHRoaXMuRmx1c2hQcm9wZXJ0aWVzKCk7XG5cbiAgICAgICAgYXNzZW1ibGVyLmluaXQodGhpcyk7XG5cbiAgICAgICAgLy9AdHMtaWdub3JlXG4gICAgICAgIHRoaXMuX3VwZGF0ZUNvbG9yKCk7ICAgICAgICAvLyBtYXkgYmUgbm8gbmVlZFxuICAgIH1cbn1cbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/SpriteMaskedAvatar/SpriteMaskedAvatarSprite.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '4c9d8O+Ld1Ofby5UG1PB2fH', 'SpriteMaskedAvatarSprite');
// Shader/SpriteMaskedAvatar/SpriteMaskedAvatarSprite.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-22 01:42:00
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:04:11
*/
var SpriteMaskedAvatarAssembler_1 = require("./SpriteMaskedAvatarAssembler");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SpriteMaskedAvatarSprite = /** @class */ (function (_super) {
    __extends(SpriteMaskedAvatarSprite, _super);
    function SpriteMaskedAvatarSprite() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._mask = null;
        _this._enableMask = true;
        return _this;
    }
    Object.defineProperty(SpriteMaskedAvatarSprite.prototype, "mask", {
        get: function () {
            return this._mask;
        },
        set: function (value) {
            this._mask = value;
            this.setVertsDirty();
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(SpriteMaskedAvatarSprite.prototype, "enableMask", {
        get: function () {
            return this._enableMask;
        },
        set: function (value) {
            this._enableMask = value;
            var mat = this.getMaterial(0);
            if (mat)
                mat.setProperty("enableMask", value ? 1.0 : 0.0);
        },
        enumerable: false,
        configurable: true
    });
    SpriteMaskedAvatarSprite.prototype._resetAssembler = function () {
        this.setVertsDirty();
        var assembler = this._assembler = new SpriteMaskedAvatarAssembler_1.default();
        assembler.init(this);
        var mask = this._mask;
        var mat = this.getMaterial(0);
        if (mat && mask) {
            mat.setProperty("mask", mask.getTexture());
            mat.setProperty("enableMask", this._enableMask ? 1.0 : 0.0);
        }
    };
    // 注意事项：业务上保证
    // 1. mask spriteFrame在使用前已经加载完毕，此处不会监听texture loaded
    // 2. mask 预先合图，此处不会监听动态合图事件
    SpriteMaskedAvatarSprite.prototype._validateRender = function () {
        //@ts-ignore
        _super.prototype._validateRender.call(this);
        var mask = this._mask;
        if (mask && mask.textureLoaded()) {
            return;
        }
        this.disableRender();
    };
    __decorate([
        property(cc.SpriteFrame)
    ], SpriteMaskedAvatarSprite.prototype, "mask", null);
    __decorate([
        property(cc.SpriteFrame)
    ], SpriteMaskedAvatarSprite.prototype, "_mask", void 0);
    __decorate([
        property(cc.Boolean)
    ], SpriteMaskedAvatarSprite.prototype, "enableMask", null);
    __decorate([
        property(cc.Boolean)
    ], SpriteMaskedAvatarSprite.prototype, "_enableMask", void 0);
    SpriteMaskedAvatarSprite = __decorate([
        ccclass
    ], SpriteMaskedAvatarSprite);
    return SpriteMaskedAvatarSprite;
}(cc.Sprite));
exports.default = SpriteMaskedAvatarSprite;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvU3ByaXRlTWFza2VkQXZhdGFyL1Nwcml0ZU1hc2tlZEF2YXRhclNwcml0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsZ0RBQWdEO0FBQ2hELDRCQUE0QjtBQUM1QiwrQ0FBK0M7QUFDL0MsZ0VBQWdFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFaEU7Ozs7RUFJRTtBQUVGLDZFQUF3RTtBQUVsRSxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUc1QztJQUFzRCw0Q0FBUztJQUEvRDtRQUFBLHFFQXNEQztRQTNDYSxXQUFLLEdBQW1CLElBQUksQ0FBQztRQWM3QixpQkFBVyxHQUFHLElBQUksQ0FBQzs7SUE2QmpDLENBQUM7SUFwREcsc0JBQUksMENBQUk7YUFJUjtZQUNJLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQztRQUN0QixDQUFDO2FBTkQsVUFBUyxLQUFxQjtZQUMxQixJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztZQUNuQixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDekIsQ0FBQzs7O09BQUE7SUFTRCxzQkFBSSxnREFBVTthQU1kO1lBQ0ksT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDO1FBQzVCLENBQUM7YUFSRCxVQUFlLEtBQWM7WUFDekIsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7WUFDekIsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM5QixJQUFJLEdBQUc7Z0JBQ0gsR0FBRyxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3pELENBQUM7OztPQUFBO0lBUUQsa0RBQWUsR0FBZjtRQUNJLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNyQixJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUkscUNBQTJCLEVBQUUsQ0FBQztRQUNwRSxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRXJCLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDdEIsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM5QixJQUFJLEdBQUcsSUFBSSxJQUFJLEVBQUU7WUFDYixHQUFHLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQztZQUMzQyxHQUFHLENBQUMsV0FBVyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQy9EO0lBQ0wsQ0FBQztJQUVELGFBQWE7SUFDYixxREFBcUQ7SUFDckQsNEJBQTRCO0lBQzVCLGtEQUFlLEdBQWY7UUFDSSxZQUFZO1FBQ1osaUJBQU0sZUFBZSxXQUFFLENBQUM7UUFFeEIsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUN0QixJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsYUFBYSxFQUFFLEVBQUU7WUFDOUIsT0FBTztTQUNWO1FBRUQsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUFuREQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQzt3REFJeEI7SUFNRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDOzJEQUNjO0lBR3ZDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUM7OERBTXBCO0lBTUQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQztpRUFDUTtJQXpCWix3QkFBd0I7UUFENUMsT0FBTztPQUNhLHdCQUF3QixDQXNENUM7SUFBRCwrQkFBQztDQXRERCxBQXNEQyxDQXREcUQsRUFBRSxDQUFDLE1BQU0sR0FzRDlEO2tCQXREb0Isd0JBQXdCIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gQ29weXJpZ2h0IDIwMjAgQ2FvIEdhb3Rpbmc8Y2FvZ3RhYUBnbWFpbC5jb20+XG4vLyBodHRwczovL2Nhb2d0YWEuZ2l0aHViLmlvXG4vLyBUaGlzIGZpbGUgaXMgbGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLlxuLy8gTGljZW5zZSB0ZXh0IGF2YWlsYWJsZSBhdCBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVFxuXG4vKlxuICogRGF0ZTogMjAyMC0wNy0yMiAwMTo0MjowMFxuICogTGFzdEVkaXRvcnM6IEdUPGNhb2d0YWFAZ21haWwuY29tPlxuICogTGFzdEVkaXRUaW1lOiAyMDIwLTA3LTIyIDE0OjA0OjExXG4qLyBcblxuaW1wb3J0IFNwcml0ZU1hc2tlZEF2YXRhckFzc2VtYmxlciBmcm9tIFwiLi9TcHJpdGVNYXNrZWRBdmF0YXJBc3NlbWJsZXJcIjtcblxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFNwcml0ZU1hc2tlZEF2YXRhclNwcml0ZSBleHRlbmRzIGNjLlNwcml0ZSB7XG4gICAgQHByb3BlcnR5KGNjLlNwcml0ZUZyYW1lKVxuICAgIHNldCBtYXNrKHZhbHVlOiBjYy5TcHJpdGVGcmFtZSkge1xuICAgICAgICB0aGlzLl9tYXNrID0gdmFsdWU7XG4gICAgICAgIHRoaXMuc2V0VmVydHNEaXJ0eSgpO1xuICAgIH1cbiAgICBnZXQgbWFzaygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX21hc2s7XG4gICAgfVxuXG4gICAgQHByb3BlcnR5KGNjLlNwcml0ZUZyYW1lKVxuICAgIHByb3RlY3RlZCBfbWFzazogY2MuU3ByaXRlRnJhbWUgPSBudWxsO1xuXG4gICAgQHByb3BlcnR5KGNjLkJvb2xlYW4pXG4gICAgc2V0IGVuYWJsZU1hc2sodmFsdWU6IGJvb2xlYW4pIHtcbiAgICAgICAgdGhpcy5fZW5hYmxlTWFzayA9IHZhbHVlO1xuICAgICAgICBsZXQgbWF0ID0gdGhpcy5nZXRNYXRlcmlhbCgwKTtcbiAgICAgICAgaWYgKG1hdClcbiAgICAgICAgICAgIG1hdC5zZXRQcm9wZXJ0eShcImVuYWJsZU1hc2tcIiwgdmFsdWUgPyAxLjAgOiAwLjApO1xuICAgIH1cbiAgICBnZXQgZW5hYmxlTWFzaygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2VuYWJsZU1hc2s7XG4gICAgfVxuXG4gICAgQHByb3BlcnR5KGNjLkJvb2xlYW4pXG4gICAgcHJvdGVjdGVkIF9lbmFibGVNYXNrID0gdHJ1ZTtcblxuICAgIF9yZXNldEFzc2VtYmxlcigpIHtcbiAgICAgICAgdGhpcy5zZXRWZXJ0c0RpcnR5KCk7XG4gICAgICAgIGxldCBhc3NlbWJsZXIgPSB0aGlzLl9hc3NlbWJsZXIgPSBuZXcgU3ByaXRlTWFza2VkQXZhdGFyQXNzZW1ibGVyKCk7XG4gICAgICAgIGFzc2VtYmxlci5pbml0KHRoaXMpO1xuXG4gICAgICAgIGxldCBtYXNrID0gdGhpcy5fbWFzaztcbiAgICAgICAgbGV0IG1hdCA9IHRoaXMuZ2V0TWF0ZXJpYWwoMCk7XG4gICAgICAgIGlmIChtYXQgJiYgbWFzaykge1xuICAgICAgICAgICAgbWF0LnNldFByb3BlcnR5KFwibWFza1wiLCBtYXNrLmdldFRleHR1cmUoKSk7XG4gICAgICAgICAgICBtYXQuc2V0UHJvcGVydHkoXCJlbmFibGVNYXNrXCIsIHRoaXMuX2VuYWJsZU1hc2sgPyAxLjAgOiAwLjApO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLy8g5rOo5oSP5LqL6aG577ya5Lia5Yqh5LiK5L+d6K+BXG4gICAgLy8gMS4gbWFzayBzcHJpdGVGcmFtZeWcqOS9v+eUqOWJjeW3sue7j+WKoOi9veWujOavle+8jOatpOWkhOS4jeS8muebkeWQrHRleHR1cmUgbG9hZGVkXG4gICAgLy8gMi4gbWFzayDpooTlhYjlkIjlm77vvIzmraTlpITkuI3kvJrnm5HlkKzliqjmgIHlkIjlm77kuovku7ZcbiAgICBfdmFsaWRhdGVSZW5kZXIoKSB7XG4gICAgICAgIC8vQHRzLWlnbm9yZVxuICAgICAgICBzdXBlci5fdmFsaWRhdGVSZW5kZXIoKTtcblxuICAgICAgICBsZXQgbWFzayA9IHRoaXMuX21hc2s7XG4gICAgICAgIGlmIChtYXNrICYmIG1hc2sudGV4dHVyZUxvYWRlZCgpKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLmRpc2FibGVSZW5kZXIoKTtcbiAgICB9XG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/Avatar/AvatarAssembler.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '45279iUvaxDYLwEzo4OPRTm', 'AvatarAssembler');
// Shader/Avatar/AvatarAssembler.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-21 17:27:48
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-23 16:46:05
*/
var GTAutoFitSpriteAssembler2D_1 = require("../GTAutoFitSpriteAssembler2D");
//@ts-ignore
var gfx = cc.gfx;
var vfmtCustom = new gfx.VertexFormat([
    { name: gfx.ATTR_POSITION, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: gfx.ATTR_UV0, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: "a_p", type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: "a_q", type: gfx.ATTR_TYPE_FLOAT32, num: 2 }
]);
var AvatarAssembler = /** @class */ (function (_super) {
    __extends(AvatarAssembler, _super);
    function AvatarAssembler() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.floatsPerVert = 8;
        return _this;
    }
    // todo: mixin this part
    AvatarAssembler.prototype.initData = function () {
        var data = this._renderData;
        // createFlexData支持创建指定格式的renderData
        data.createFlexData(0, this.verticesCount, this.indicesCount, this.getVfmt());
        // createFlexData不会填充顶点索引信息，手动补充一下
        var indices = data.iDatas[0];
        var count = indices.length / 6;
        for (var i = 0, idx = 0; i < count; i++) {
            var vertextID = i * 4;
            indices[idx++] = vertextID;
            indices[idx++] = vertextID + 1;
            indices[idx++] = vertextID + 2;
            indices[idx++] = vertextID + 1;
            indices[idx++] = vertextID + 3;
            indices[idx++] = vertextID + 2;
        }
    };
    AvatarAssembler.prototype.getVfmt = function () {
        return vfmtCustom;
    };
    AvatarAssembler.prototype.getBuffer = function () {
        //@ts-ignore
        return cc.renderer._handle.getBuffer("mesh", this.getVfmt());
    };
    AvatarAssembler.prototype.updateColor = function (comp, color) {
        // do nothing
    };
    AvatarAssembler.prototype.updateUVs = function (sprite) {
        _super.prototype.updateUVs.call(this, sprite);
        // this._uv可以用sprite._spriteFrame.uv代替
        // this._uv是spriteFrame对node大小自适应缩放后的uv
        var uv = this._uv;
        var isRotated = sprite._spriteFrame.isRotated();
        var l = uv[0], r = uv[2], b = uv[1], t = uv[5];
        if (isRotated) {
            // cc图集里的旋转总是顺时针旋转90度，以原左下角为中心。（旋转后左下角变为左上角）
            l = uv[1];
            r = uv[3];
            b = uv[0];
            t = uv[4];
        }
        var px = 1.0 / (r - l), qx = -l * px; // l / (l-r);
        var py = 1.0 / (b - t), qy = -t * py; // t / (t-b);
        var uvOffset = this.uvOffset;
        var floatsPerVert = this.floatsPerVert;
        var verts = this._renderData.vDatas[0];
        for (var i = 0; i < 4; i++) {
            var dstOffset = floatsPerVert * i + uvOffset;
            if (isRotated) {
                verts[dstOffset + 2] = py;
                verts[dstOffset + 3] = px;
                verts[dstOffset + 4] = qy;
                verts[dstOffset + 5] = qx;
            }
            else {
                verts[dstOffset + 2] = px;
                verts[dstOffset + 3] = py;
                verts[dstOffset + 4] = qx;
                verts[dstOffset + 5] = qy;
            }
        }
    };
    return AvatarAssembler;
}(GTAutoFitSpriteAssembler2D_1.default));
exports.default = AvatarAssembler;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvQXZhdGFyL0F2YXRhckFzc2VtYmxlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsZ0RBQWdEO0FBQ2hELDRCQUE0QjtBQUM1QiwrQ0FBK0M7QUFDL0MsZ0VBQWdFOzs7Ozs7Ozs7Ozs7Ozs7QUFFaEU7Ozs7RUFJRTtBQUdGLDRFQUF1RTtBQUV2RSxZQUFZO0FBQ1osSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQztBQUNqQixJQUFJLFVBQVUsR0FBRyxJQUFJLEdBQUcsQ0FBQyxZQUFZLENBQUM7SUFDbEMsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLGFBQWEsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLGlCQUFpQixFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQUU7SUFDaEUsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLGlCQUFpQixFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQUU7SUFDM0QsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsaUJBQWlCLEVBQUUsR0FBRyxFQUFFLENBQUMsRUFBRTtJQUNwRCxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxHQUFHLEVBQUUsQ0FBQyxFQUFFO0NBQ3ZELENBQUMsQ0FBQztBQUVIO0lBQTZDLG1DQUEwQjtJQUF2RTtRQUFBLHFFQThFQztRQTdFRyxtQkFBYSxHQUFHLENBQUMsQ0FBQzs7SUE2RXRCLENBQUM7SUEzRUcsd0JBQXdCO0lBQ3hCLGtDQUFRLEdBQVI7UUFDSSxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDO1FBQzVCLG9DQUFvQztRQUNwQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFFOUUsa0NBQWtDO1FBQ2xDLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0IsSUFBSSxLQUFLLEdBQUcsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDL0IsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3JDLElBQUksU0FBUyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDdEIsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDO1lBQzNCLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLFNBQVMsR0FBQyxDQUFDLENBQUM7WUFDN0IsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsU0FBUyxHQUFDLENBQUMsQ0FBQztZQUM3QixPQUFPLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxTQUFTLEdBQUMsQ0FBQyxDQUFDO1lBQzdCLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLFNBQVMsR0FBQyxDQUFDLENBQUM7WUFDN0IsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsU0FBUyxHQUFDLENBQUMsQ0FBQztTQUNoQztJQUNMLENBQUM7SUFFRCxpQ0FBTyxHQUFQO1FBQ0ksT0FBTyxVQUFVLENBQUM7SUFDdEIsQ0FBQztJQUVELG1DQUFTLEdBQVQ7UUFDSSxZQUFZO1FBQ1osT0FBTyxFQUFFLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFFRCxxQ0FBVyxHQUFYLFVBQVksSUFBSSxFQUFFLEtBQUs7UUFDbkIsYUFBYTtJQUNqQixDQUFDO0lBRUQsbUNBQVMsR0FBVCxVQUFVLE1BQU07UUFDWixpQkFBTSxTQUFTLFlBQUMsTUFBTSxDQUFDLENBQUM7UUFFeEIsc0NBQXNDO1FBQ3RDLHVDQUF1QztRQUN2QyxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDO1FBQ2xCLElBQUksU0FBUyxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDaEQsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUNULENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQ1QsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFDVCxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRWQsSUFBSSxTQUFTLEVBQUU7WUFDWCw0Q0FBNEM7WUFDNUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdEIsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDekI7UUFFRCxJQUFJLEVBQUUsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQ3BCLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBRyxhQUFhO1FBRTdCLElBQUksRUFBRSxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsRUFDcEIsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFHLGFBQWE7UUFFN0IsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQztRQUM3QixJQUFJLGFBQWEsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1FBQ3ZDLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDeEIsSUFBSSxTQUFTLEdBQUcsYUFBYSxHQUFHLENBQUMsR0FBRyxRQUFRLENBQUM7WUFDN0MsSUFBSSxTQUFTLEVBQUU7Z0JBQ1gsS0FBSyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7Z0JBQzFCLEtBQUssQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO2dCQUMxQixLQUFLLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFDMUIsS0FBSyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7YUFDN0I7aUJBQU07Z0JBQ0gsS0FBSyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7Z0JBQzFCLEtBQUssQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO2dCQUMxQixLQUFLLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFDMUIsS0FBSyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7YUFDN0I7U0FDSjtJQUNMLENBQUM7SUFDTCxzQkFBQztBQUFELENBOUVBLEFBOEVDLENBOUU0QyxvQ0FBMEIsR0E4RXRFIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gQ29weXJpZ2h0IDIwMjAgQ2FvIEdhb3Rpbmc8Y2FvZ3RhYUBnbWFpbC5jb20+XG4vLyBodHRwczovL2Nhb2d0YWEuZ2l0aHViLmlvXG4vLyBUaGlzIGZpbGUgaXMgbGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLlxuLy8gTGljZW5zZSB0ZXh0IGF2YWlsYWJsZSBhdCBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVFxuXG4vKlxuICogRGF0ZTogMjAyMC0wNy0yMSAxNzoyNzo0OFxuICogTGFzdEVkaXRvcnM6IEdUPGNhb2d0YWFAZ21haWwuY29tPlxuICogTGFzdEVkaXRUaW1lOiAyMDIwLTA3LTIzIDE2OjQ2OjA1XG4qLyBcblxuXG5pbXBvcnQgR1RBdXRvRml0U3ByaXRlQXNzZW1ibGVyMkQgZnJvbSBcIi4uL0dUQXV0b0ZpdFNwcml0ZUFzc2VtYmxlcjJEXCI7XG5cbi8vQHRzLWlnbm9yZVxubGV0IGdmeCA9IGNjLmdmeDtcbnZhciB2Zm10Q3VzdG9tID0gbmV3IGdmeC5WZXJ0ZXhGb3JtYXQoW1xuICAgIHsgbmFtZTogZ2Z4LkFUVFJfUE9TSVRJT04sIHR5cGU6IGdmeC5BVFRSX1RZUEVfRkxPQVQzMiwgbnVtOiAyIH0sXG4gICAgeyBuYW1lOiBnZnguQVRUUl9VVjAsIHR5cGU6IGdmeC5BVFRSX1RZUEVfRkxPQVQzMiwgbnVtOiAyIH0sXG4gICAgeyBuYW1lOiBcImFfcFwiLCB0eXBlOiBnZnguQVRUUl9UWVBFX0ZMT0FUMzIsIG51bTogMiB9LFxuICAgIHsgbmFtZTogXCJhX3FcIiwgdHlwZTogZ2Z4LkFUVFJfVFlQRV9GTE9BVDMyLCBudW06IDIgfVxuXSk7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEF2YXRhckFzc2VtYmxlciBleHRlbmRzIEdUQXV0b0ZpdFNwcml0ZUFzc2VtYmxlcjJEIHtcbiAgICBmbG9hdHNQZXJWZXJ0ID0gODtcblxuICAgIC8vIHRvZG86IG1peGluIHRoaXMgcGFydFxuICAgIGluaXREYXRhKCkge1xuICAgICAgICBsZXQgZGF0YSA9IHRoaXMuX3JlbmRlckRhdGE7XG4gICAgICAgIC8vIGNyZWF0ZUZsZXhEYXRh5pSv5oyB5Yib5bu65oyH5a6a5qC85byP55qEcmVuZGVyRGF0YVxuICAgICAgICBkYXRhLmNyZWF0ZUZsZXhEYXRhKDAsIHRoaXMudmVydGljZXNDb3VudCwgdGhpcy5pbmRpY2VzQ291bnQsIHRoaXMuZ2V0VmZtdCgpKTtcblxuICAgICAgICAvLyBjcmVhdGVGbGV4RGF0YeS4jeS8muWhq+WFhemhtueCuee0ouW8leS/oeaBr++8jOaJi+WKqOihpeWFheS4gOS4i1xuICAgICAgICBsZXQgaW5kaWNlcyA9IGRhdGEuaURhdGFzWzBdO1xuICAgICAgICBsZXQgY291bnQgPSBpbmRpY2VzLmxlbmd0aCAvIDY7XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBpZHggPSAwOyBpIDwgY291bnQ7IGkrKykge1xuICAgICAgICAgICAgbGV0IHZlcnRleHRJRCA9IGkgKiA0O1xuICAgICAgICAgICAgaW5kaWNlc1tpZHgrK10gPSB2ZXJ0ZXh0SUQ7XG4gICAgICAgICAgICBpbmRpY2VzW2lkeCsrXSA9IHZlcnRleHRJRCsxO1xuICAgICAgICAgICAgaW5kaWNlc1tpZHgrK10gPSB2ZXJ0ZXh0SUQrMjtcbiAgICAgICAgICAgIGluZGljZXNbaWR4KytdID0gdmVydGV4dElEKzE7XG4gICAgICAgICAgICBpbmRpY2VzW2lkeCsrXSA9IHZlcnRleHRJRCszO1xuICAgICAgICAgICAgaW5kaWNlc1tpZHgrK10gPSB2ZXJ0ZXh0SUQrMjtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGdldFZmbXQoKSB7XG4gICAgICAgIHJldHVybiB2Zm10Q3VzdG9tO1xuICAgIH1cblxuICAgIGdldEJ1ZmZlcigpIHtcbiAgICAgICAgLy9AdHMtaWdub3JlXG4gICAgICAgIHJldHVybiBjYy5yZW5kZXJlci5faGFuZGxlLmdldEJ1ZmZlcihcIm1lc2hcIiwgdGhpcy5nZXRWZm10KCkpO1xuICAgIH1cblxuICAgIHVwZGF0ZUNvbG9yKGNvbXAsIGNvbG9yKSB7XG4gICAgICAgIC8vIGRvIG5vdGhpbmdcbiAgICB9XG5cbiAgICB1cGRhdGVVVnMoc3ByaXRlKSB7XG4gICAgICAgIHN1cGVyLnVwZGF0ZVVWcyhzcHJpdGUpO1xuXG4gICAgICAgIC8vIHRoaXMuX3V25Y+v5Lul55Soc3ByaXRlLl9zcHJpdGVGcmFtZS51duS7o+abv1xuICAgICAgICAvLyB0aGlzLl91duaYr3Nwcml0ZUZyYW1l5a+5bm9kZeWkp+Wwj+iHqumAguW6lOe8qeaUvuWQjueahHV2XG4gICAgICAgIGxldCB1diA9IHRoaXMuX3V2O1xuICAgICAgICBsZXQgaXNSb3RhdGVkID0gc3ByaXRlLl9zcHJpdGVGcmFtZS5pc1JvdGF0ZWQoKTtcbiAgICAgICAgbGV0IGwgPSB1dlswXSxcbiAgICAgICAgICAgIHIgPSB1dlsyXSxcbiAgICAgICAgICAgIGIgPSB1dlsxXSxcbiAgICAgICAgICAgIHQgPSB1dls1XTtcbiAgICAgICAgXG4gICAgICAgIGlmIChpc1JvdGF0ZWQpIHtcbiAgICAgICAgICAgIC8vIGNj5Zu+6ZuG6YeM55qE5peL6L2s5oC75piv6aG65pe26ZKI5peL6L2sOTDluqbvvIzku6Xljp/lt6bkuIvop5LkuLrkuK3lv4PjgILvvIjml4vovazlkI7lt6bkuIvop5Llj5jkuLrlt6bkuIrop5LvvIlcbiAgICAgICAgICAgIGwgPSB1dlsxXTsgIHIgPSB1dlszXTtcbiAgICAgICAgICAgIGIgPSB1dlswXTsgIHQgPSB1dls0XTtcbiAgICAgICAgfVxuXG4gICAgICAgIGxldCBweCA9IDEuMCAvIChyLWwpLFxuICAgICAgICBxeCA9IC1sICogcHg7ICAgLy8gbCAvIChsLXIpO1xuXG4gICAgICAgIGxldCBweSA9IDEuMCAvIChiLXQpLFxuICAgICAgICBxeSA9IC10ICogcHk7ICAgLy8gdCAvICh0LWIpO1xuXG4gICAgICAgIGxldCB1dk9mZnNldCA9IHRoaXMudXZPZmZzZXQ7XG4gICAgICAgIGxldCBmbG9hdHNQZXJWZXJ0ID0gdGhpcy5mbG9hdHNQZXJWZXJ0O1xuICAgICAgICBsZXQgdmVydHMgPSB0aGlzLl9yZW5kZXJEYXRhLnZEYXRhc1swXTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCA0OyBpKyspIHtcbiAgICAgICAgICAgIGxldCBkc3RPZmZzZXQgPSBmbG9hdHNQZXJWZXJ0ICogaSArIHV2T2Zmc2V0O1xuICAgICAgICAgICAgaWYgKGlzUm90YXRlZCkge1xuICAgICAgICAgICAgICAgIHZlcnRzW2RzdE9mZnNldCArIDJdID0gcHk7XG4gICAgICAgICAgICAgICAgdmVydHNbZHN0T2Zmc2V0ICsgM10gPSBweDtcbiAgICAgICAgICAgICAgICB2ZXJ0c1tkc3RPZmZzZXQgKyA0XSA9IHF5O1xuICAgICAgICAgICAgICAgIHZlcnRzW2RzdE9mZnNldCArIDVdID0gcXg7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHZlcnRzW2RzdE9mZnNldCArIDJdID0gcHg7XG4gICAgICAgICAgICAgICAgdmVydHNbZHN0T2Zmc2V0ICsgM10gPSBweTtcbiAgICAgICAgICAgICAgICB2ZXJ0c1tkc3RPZmZzZXQgKyA0XSA9IHF4O1xuICAgICAgICAgICAgICAgIHZlcnRzW2RzdE9mZnNldCArIDVdID0gcXk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/EqualScallingSprite/EqualScalingAssembler.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e54e38Lmk1LtatjNGNMggDD', 'EqualScalingAssembler');
// Shader/EqualScallingSprite/EqualScalingAssembler.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-21 16:23:10
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:00:52
*/
var GTSimpleSpriteAssembler2D_1 = require("../GTSimpleSpriteAssembler2D");
var EqualScalingAssembler = /** @class */ (function (_super) {
    __extends(EqualScalingAssembler, _super);
    function EqualScalingAssembler() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._uv = [];
        return _this;
    }
    EqualScalingAssembler.prototype.updateUVs = function (sprite) {
        var rect = sprite._spriteFrame.getRect();
        var node = sprite.node;
        if (!rect.width || !rect.height || !node.width || !node.height) {
            _super.prototype.updateUVs.call(this, sprite);
            return;
        }
        Object.assign(this._uv, sprite._spriteFrame.uv);
        var uv = this._uv;
        var wscale = rect.width / node.width;
        var hscale = rect.height / node.height;
        var ratio = 1.0;
        if (wscale > hscale) {
            // fit height
            ratio = hscale / wscale;
            var ro = sprite._spriteFrame.isRotated() ? 1 : 0;
            var l = uv[0 + ro], r = uv[2 + ro];
            var c = (l + r) * 0.5;
            var half = (r - l) * 0.5 * ratio;
            uv[0 + ro] = uv[4 + ro] = c - half;
            uv[2 + ro] = uv[6 + ro] = c + half;
        }
        else {
            // fit width
            ratio = wscale / hscale;
            var ro = sprite._spriteFrame.isRotated() ? -1 : 0;
            var b = uv[1 + ro], t = uv[5 + ro];
            var c = (b + t) * 0.5;
            var half = (b - t) * 0.5 * ratio;
            uv[1 + ro] = uv[3 + ro] = c + half;
            uv[5 + ro] = uv[7 + ro] = c - half;
        }
        var uvOffset = this.uvOffset;
        var floatsPerVert = this.floatsPerVert;
        var verts = this._renderData.vDatas[0];
        for (var i = 0; i < 4; i++) {
            var srcOffset = i * 2;
            var dstOffset = floatsPerVert * i + uvOffset;
            verts[dstOffset] = uv[srcOffset];
            verts[dstOffset + 1] = uv[srcOffset + 1];
        }
    };
    return EqualScalingAssembler;
}(GTSimpleSpriteAssembler2D_1.default));
exports.default = EqualScalingAssembler;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvRXF1YWxTY2FsbGluZ1Nwcml0ZS9FcXVhbFNjYWxpbmdBc3NlbWJsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLGdEQUFnRDtBQUNoRCw0QkFBNEI7QUFDNUIsK0NBQStDO0FBQy9DLGdFQUFnRTs7Ozs7Ozs7Ozs7Ozs7O0FBRWhFOzs7O0VBSUU7QUFFRiwwRUFBcUU7QUFFckU7SUFBbUQseUNBQXlCO0lBQTVFO1FBQUEscUVBK0NDO1FBOUNXLFNBQUcsR0FBRyxFQUFFLENBQUM7O0lBOENyQixDQUFDO0lBNUNHLHlDQUFTLEdBQVQsVUFBVSxNQUFNO1FBQ1osSUFBSSxJQUFJLEdBQVksTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUNsRCxJQUFJLElBQUksR0FBWSxNQUFNLENBQUMsSUFBSSxDQUFDO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQzVELGlCQUFNLFNBQVMsWUFBQyxNQUFNLENBQUMsQ0FBQztZQUN4QixPQUFPO1NBQ1Y7UUFFRCxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUVoRCxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDO1FBQ2xCLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUNyQyxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7UUFDdkMsSUFBSSxLQUFLLEdBQVcsR0FBRyxDQUFDO1FBQ3hCLElBQUksTUFBTSxHQUFHLE1BQU0sRUFBRTtZQUNqQixhQUFhO1lBQ2IsS0FBSyxHQUFHLE1BQU0sR0FBRyxNQUFNLENBQUM7WUFDeEIsSUFBSSxFQUFFLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDakQsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsR0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsR0FBQyxFQUFFLENBQUMsQ0FBQztZQUMvQixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7WUFDcEIsSUFBSSxJQUFJLEdBQUcsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLEtBQUssQ0FBQztZQUMvQixFQUFFLENBQUMsQ0FBQyxHQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQztZQUMvQixFQUFFLENBQUMsQ0FBQyxHQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQztTQUNsQzthQUFNO1lBQ0gsWUFBWTtZQUNaLEtBQUssR0FBRyxNQUFNLEdBQUcsTUFBTSxDQUFDO1lBQ3hCLElBQUksRUFBRSxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbEQsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsR0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsR0FBQyxFQUFFLENBQUMsQ0FBQztZQUMvQixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7WUFDcEIsSUFBSSxJQUFJLEdBQUcsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLEtBQUssQ0FBQztZQUMvQixFQUFFLENBQUMsQ0FBQyxHQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQztZQUMvQixFQUFFLENBQUMsQ0FBQyxHQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQztTQUNsQztRQUVELElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7UUFDN0IsSUFBSSxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUN2QyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2QyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3hCLElBQUksU0FBUyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDdEIsSUFBSSxTQUFTLEdBQUcsYUFBYSxHQUFHLENBQUMsR0FBRyxRQUFRLENBQUM7WUFDN0MsS0FBSyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNqQyxLQUFLLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDNUM7SUFDTCxDQUFDO0lBQ0wsNEJBQUM7QUFBRCxDQS9DQSxBQStDQyxDQS9Da0QsbUNBQXlCLEdBK0MzRSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIENvcHlyaWdodCAyMDIwIENhbyBHYW90aW5nPGNhb2d0YWFAZ21haWwuY29tPlxuLy8gaHR0cHM6Ly9jYW9ndGFhLmdpdGh1Yi5pb1xuLy8gVGhpcyBmaWxlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS5cbi8vIExpY2Vuc2UgdGV4dCBhdmFpbGFibGUgYXQgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVRcblxuLypcbiAqIERhdGU6IDIwMjAtMDctMjEgMTY6MjM6MTBcbiAqIExhc3RFZGl0b3JzOiBHVDxjYW9ndGFhQGdtYWlsLmNvbT5cbiAqIExhc3RFZGl0VGltZTogMjAyMC0wNy0yMiAxNDowMDo1MlxuKi8gXG5cbmltcG9ydCBHVFNpbXBsZVNwcml0ZUFzc2VtYmxlcjJEIGZyb20gXCIuLi9HVFNpbXBsZVNwcml0ZUFzc2VtYmxlcjJEXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEVxdWFsU2NhbGluZ0Fzc2VtYmxlciBleHRlbmRzIEdUU2ltcGxlU3ByaXRlQXNzZW1ibGVyMkQge1xuICAgIHByaXZhdGUgX3V2ID0gW107XG5cbiAgICB1cGRhdGVVVnMoc3ByaXRlKSB7XG4gICAgICAgIGxldCByZWN0OiBjYy5SZWN0ID0gc3ByaXRlLl9zcHJpdGVGcmFtZS5nZXRSZWN0KCk7XG4gICAgICAgIGxldCBub2RlOiBjYy5Ob2RlID0gc3ByaXRlLm5vZGU7XG4gICAgICAgIGlmICghcmVjdC53aWR0aCB8fCAhcmVjdC5oZWlnaHQgfHwgIW5vZGUud2lkdGggfHwgIW5vZGUuaGVpZ2h0KSB7XG4gICAgICAgICAgICBzdXBlci51cGRhdGVVVnMoc3ByaXRlKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIE9iamVjdC5hc3NpZ24odGhpcy5fdXYsIHNwcml0ZS5fc3ByaXRlRnJhbWUudXYpO1xuXG4gICAgICAgIGxldCB1diA9IHRoaXMuX3V2O1xuICAgICAgICBsZXQgd3NjYWxlID0gcmVjdC53aWR0aCAvIG5vZGUud2lkdGg7XG4gICAgICAgIGxldCBoc2NhbGUgPSByZWN0LmhlaWdodCAvIG5vZGUuaGVpZ2h0O1xuICAgICAgICBsZXQgcmF0aW86IG51bWJlciA9IDEuMDtcbiAgICAgICAgaWYgKHdzY2FsZSA+IGhzY2FsZSkge1xuICAgICAgICAgICAgLy8gZml0IGhlaWdodFxuICAgICAgICAgICAgcmF0aW8gPSBoc2NhbGUgLyB3c2NhbGU7XG4gICAgICAgICAgICBsZXQgcm8gPSBzcHJpdGUuX3Nwcml0ZUZyYW1lLmlzUm90YXRlZCgpID8gMSA6IDA7XG4gICAgICAgICAgICBsZXQgbCA9IHV2WzArcm9dLCByID0gdXZbMityb107XG4gICAgICAgICAgICBsZXQgYyA9IChsK3IpICogMC41O1xuICAgICAgICAgICAgbGV0IGhhbGYgPSAoci1sKSAqIDAuNSAqIHJhdGlvO1xuICAgICAgICAgICAgdXZbMCtyb10gPSB1dls0K3JvXSA9IGMgLSBoYWxmO1xuICAgICAgICAgICAgdXZbMityb10gPSB1dls2K3JvXSA9IGMgKyBoYWxmO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gZml0IHdpZHRoXG4gICAgICAgICAgICByYXRpbyA9IHdzY2FsZSAvIGhzY2FsZTtcbiAgICAgICAgICAgIGxldCBybyA9IHNwcml0ZS5fc3ByaXRlRnJhbWUuaXNSb3RhdGVkKCkgPyAtMSA6IDA7XG4gICAgICAgICAgICBsZXQgYiA9IHV2WzErcm9dLCB0ID0gdXZbNStyb107XG4gICAgICAgICAgICBsZXQgYyA9IChiK3QpICogMC41O1xuICAgICAgICAgICAgbGV0IGhhbGYgPSAoYi10KSAqIDAuNSAqIHJhdGlvO1xuICAgICAgICAgICAgdXZbMStyb10gPSB1dlszK3JvXSA9IGMgKyBoYWxmO1xuICAgICAgICAgICAgdXZbNStyb10gPSB1dls3K3JvXSA9IGMgLSBoYWxmO1xuICAgICAgICB9XG5cbiAgICAgICAgbGV0IHV2T2Zmc2V0ID0gdGhpcy51dk9mZnNldDtcbiAgICAgICAgbGV0IGZsb2F0c1BlclZlcnQgPSB0aGlzLmZsb2F0c1BlclZlcnQ7XG4gICAgICAgIGxldCB2ZXJ0cyA9IHRoaXMuX3JlbmRlckRhdGEudkRhdGFzWzBdO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IDQ7IGkrKykge1xuICAgICAgICAgICAgbGV0IHNyY09mZnNldCA9IGkgKiAyO1xuICAgICAgICAgICAgbGV0IGRzdE9mZnNldCA9IGZsb2F0c1BlclZlcnQgKiBpICsgdXZPZmZzZXQ7XG4gICAgICAgICAgICB2ZXJ0c1tkc3RPZmZzZXRdID0gdXZbc3JjT2Zmc2V0XTtcbiAgICAgICAgICAgIHZlcnRzW2RzdE9mZnNldCArIDFdID0gdXZbc3JjT2Zmc2V0ICsgMV07XG4gICAgICAgIH1cbiAgICB9XG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/GTSimpleSpriteAssembler2D.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '3cf56xQ2eRKRpc+4MgUs5BS', 'GTSimpleSpriteAssembler2D');
// Shader/GTSimpleSpriteAssembler2D.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-21 16:23:10
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:04:52
*/
var GTAssembler2D_1 = require("./GTAssembler2D");
var GTSimpleSpriteAssembler2D = /** @class */ (function (_super) {
    __extends(GTSimpleSpriteAssembler2D, _super);
    function GTSimpleSpriteAssembler2D() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    // 这部分使用SimpleSpriteAssembler的内容
    GTSimpleSpriteAssembler2D.prototype.updateRenderData = function (sprite) {
        this.packToDynamicAtlas(sprite, sprite._spriteFrame);
        _super.prototype.updateRenderData.call(this, sprite);
    };
    GTSimpleSpriteAssembler2D.prototype.updateUVs = function (sprite) {
        var uv = sprite._spriteFrame.uv;
        var uvOffset = this.uvOffset;
        var floatsPerVert = this.floatsPerVert;
        var verts = this._renderData.vDatas[0];
        for (var i = 0; i < 4; i++) {
            var srcOffset = i * 2;
            var dstOffset = floatsPerVert * i + uvOffset;
            verts[dstOffset] = uv[srcOffset];
            verts[dstOffset + 1] = uv[srcOffset + 1];
        }
    };
    GTSimpleSpriteAssembler2D.prototype.updateVerts = function (sprite) {
        var node = sprite.node, cw = node.width, ch = node.height, appx = node.anchorX * cw, appy = node.anchorY * ch, l, b, r, t;
        if (sprite.trim) {
            l = -appx;
            b = -appy;
            r = cw - appx;
            t = ch - appy;
        }
        else {
            var frame = sprite.spriteFrame, ow = frame._originalSize.width, oh = frame._originalSize.height, rw = frame._rect.width, rh = frame._rect.height, offset = frame._offset, scaleX = cw / ow, scaleY = ch / oh;
            var trimLeft = offset.x + (ow - rw) / 2;
            var trimRight = offset.x - (ow - rw) / 2;
            var trimBottom = offset.y + (oh - rh) / 2;
            var trimTop = offset.y - (oh - rh) / 2;
            l = trimLeft * scaleX - appx;
            b = trimBottom * scaleY - appy;
            r = cw + trimRight * scaleX - appx;
            t = ch + trimTop * scaleY - appy;
        }
        var local = this._local;
        local[0] = l;
        local[1] = b;
        local[2] = r;
        local[3] = t;
        this.updateWorldVerts(sprite);
    };
    return GTSimpleSpriteAssembler2D;
}(GTAssembler2D_1.default));
exports.default = GTSimpleSpriteAssembler2D;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvR1RTaW1wbGVTcHJpdGVBc3NlbWJsZXIyRC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsZ0RBQWdEO0FBQ2hELDRCQUE0QjtBQUM1QiwrQ0FBK0M7QUFDL0MsZ0VBQWdFOzs7Ozs7Ozs7Ozs7Ozs7QUFFaEU7Ozs7RUFJRTtBQUVGLGlEQUE0QztBQUU1QztJQUF1RCw2Q0FBYTtJQUFwRTs7SUFzREEsQ0FBQztJQXJERyxnQ0FBZ0M7SUFDaEMsb0RBQWdCLEdBQWhCLFVBQWlCLE1BQWlCO1FBQzlCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ3JELGlCQUFNLGdCQUFnQixZQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFFRCw2Q0FBUyxHQUFULFVBQVUsTUFBTTtRQUNaLElBQUksRUFBRSxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1FBQ2hDLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7UUFDN0IsSUFBSSxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUN2QyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2QyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3hCLElBQUksU0FBUyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDdEIsSUFBSSxTQUFTLEdBQUcsYUFBYSxHQUFHLENBQUMsR0FBRyxRQUFRLENBQUM7WUFDN0MsS0FBSyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNqQyxLQUFLLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDNUM7SUFDTCxDQUFDO0lBRUQsK0NBQVcsR0FBWCxVQUFZLE1BQU07UUFDZCxJQUFJLElBQUksR0FBRyxNQUFNLENBQUMsSUFBSSxFQUNsQixFQUFFLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxFQUFFLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFDakMsSUFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLEdBQUcsRUFBRSxFQUFFLElBQUksR0FBRyxJQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsRUFDbEQsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ2YsSUFBSSxNQUFNLENBQUMsSUFBSSxFQUFFO1lBQ2IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ1YsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ1YsQ0FBQyxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUM7WUFDZCxDQUFDLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQztTQUNqQjthQUNJO1lBQ0QsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDLFdBQVcsRUFDMUIsRUFBRSxHQUFHLEtBQUssQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLEVBQUUsR0FBRyxLQUFLLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFDL0QsRUFBRSxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFDL0MsTUFBTSxHQUFHLEtBQUssQ0FBQyxPQUFPLEVBQ3RCLE1BQU0sR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFLE1BQU0sR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDO1lBQ3ZDLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3hDLElBQUksU0FBUyxHQUFHLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3pDLElBQUksVUFBVSxHQUFHLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzFDLElBQUksT0FBTyxHQUFHLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3ZDLENBQUMsR0FBRyxRQUFRLEdBQUcsTUFBTSxHQUFHLElBQUksQ0FBQztZQUM3QixDQUFDLEdBQUcsVUFBVSxHQUFHLE1BQU0sR0FBRyxJQUFJLENBQUM7WUFDL0IsQ0FBQyxHQUFHLEVBQUUsR0FBRyxTQUFTLEdBQUcsTUFBTSxHQUFHLElBQUksQ0FBQztZQUNuQyxDQUFDLEdBQUcsRUFBRSxHQUFHLE9BQU8sR0FBRyxNQUFNLEdBQUcsSUFBSSxDQUFDO1NBQ3BDO1FBRUQsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUN4QixLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2IsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNiLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDYixLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2IsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ2xDLENBQUM7SUFDTCxnQ0FBQztBQUFELENBdERBLEFBc0RDLENBdERzRCx1QkFBYSxHQXNEbkUiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDb3B5cmlnaHQgMjAyMCBDYW8gR2FvdGluZzxjYW9ndGFhQGdtYWlsLmNvbT5cbi8vIGh0dHBzOi8vY2FvZ3RhYS5naXRodWIuaW9cbi8vIFRoaXMgZmlsZSBpcyBsaWNlbnNlZCB1bmRlciB0aGUgTUlUIExpY2Vuc2UuXG4vLyBMaWNlbnNlIHRleHQgYXZhaWxhYmxlIGF0IGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlUXG5cbi8qXG4gKiBEYXRlOiAyMDIwLTA3LTIxIDE2OjIzOjEwXG4gKiBMYXN0RWRpdG9yczogR1Q8Y2FvZ3RhYUBnbWFpbC5jb20+XG4gKiBMYXN0RWRpdFRpbWU6IDIwMjAtMDctMjIgMTQ6MDQ6NTJcbiovIFxuXG5pbXBvcnQgR1RBc3NlbWJsZXIyRCBmcm9tIFwiLi9HVEFzc2VtYmxlcjJEXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEdUU2ltcGxlU3ByaXRlQXNzZW1ibGVyMkQgZXh0ZW5kcyBHVEFzc2VtYmxlcjJEIHtcbiAgICAvLyDov5npg6jliIbkvb/nlKhTaW1wbGVTcHJpdGVBc3NlbWJsZXLnmoTlhoXlrrlcbiAgICB1cGRhdGVSZW5kZXJEYXRhKHNwcml0ZTogY2MuU3ByaXRlKSB7XG4gICAgICAgIHRoaXMucGFja1RvRHluYW1pY0F0bGFzKHNwcml0ZSwgc3ByaXRlLl9zcHJpdGVGcmFtZSk7XG4gICAgICAgIHN1cGVyLnVwZGF0ZVJlbmRlckRhdGEoc3ByaXRlKTtcbiAgICB9XG5cbiAgICB1cGRhdGVVVnMoc3ByaXRlKSB7XG4gICAgICAgIGxldCB1diA9IHNwcml0ZS5fc3ByaXRlRnJhbWUudXY7XG4gICAgICAgIGxldCB1dk9mZnNldCA9IHRoaXMudXZPZmZzZXQ7XG4gICAgICAgIGxldCBmbG9hdHNQZXJWZXJ0ID0gdGhpcy5mbG9hdHNQZXJWZXJ0O1xuICAgICAgICBsZXQgdmVydHMgPSB0aGlzLl9yZW5kZXJEYXRhLnZEYXRhc1swXTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCA0OyBpKyspIHtcbiAgICAgICAgICAgIGxldCBzcmNPZmZzZXQgPSBpICogMjtcbiAgICAgICAgICAgIGxldCBkc3RPZmZzZXQgPSBmbG9hdHNQZXJWZXJ0ICogaSArIHV2T2Zmc2V0O1xuICAgICAgICAgICAgdmVydHNbZHN0T2Zmc2V0XSA9IHV2W3NyY09mZnNldF07XG4gICAgICAgICAgICB2ZXJ0c1tkc3RPZmZzZXQgKyAxXSA9IHV2W3NyY09mZnNldCArIDFdO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgdXBkYXRlVmVydHMoc3ByaXRlKSB7XG4gICAgICAgIGxldCBub2RlID0gc3ByaXRlLm5vZGUsXG4gICAgICAgICAgICBjdyA9IG5vZGUud2lkdGgsIGNoID0gbm9kZS5oZWlnaHQsXG4gICAgICAgICAgICBhcHB4ID0gbm9kZS5hbmNob3JYICogY3csIGFwcHkgPSBub2RlLmFuY2hvclkgKiBjaCxcbiAgICAgICAgICAgIGwsIGIsIHIsIHQ7XG4gICAgICAgIGlmIChzcHJpdGUudHJpbSkge1xuICAgICAgICAgICAgbCA9IC1hcHB4O1xuICAgICAgICAgICAgYiA9IC1hcHB5O1xuICAgICAgICAgICAgciA9IGN3IC0gYXBweDtcbiAgICAgICAgICAgIHQgPSBjaCAtIGFwcHk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBsZXQgZnJhbWUgPSBzcHJpdGUuc3ByaXRlRnJhbWUsXG4gICAgICAgICAgICAgICAgb3cgPSBmcmFtZS5fb3JpZ2luYWxTaXplLndpZHRoLCBvaCA9IGZyYW1lLl9vcmlnaW5hbFNpemUuaGVpZ2h0LFxuICAgICAgICAgICAgICAgIHJ3ID0gZnJhbWUuX3JlY3Qud2lkdGgsIHJoID0gZnJhbWUuX3JlY3QuaGVpZ2h0LFxuICAgICAgICAgICAgICAgIG9mZnNldCA9IGZyYW1lLl9vZmZzZXQsXG4gICAgICAgICAgICAgICAgc2NhbGVYID0gY3cgLyBvdywgc2NhbGVZID0gY2ggLyBvaDtcbiAgICAgICAgICAgIGxldCB0cmltTGVmdCA9IG9mZnNldC54ICsgKG93IC0gcncpIC8gMjtcbiAgICAgICAgICAgIGxldCB0cmltUmlnaHQgPSBvZmZzZXQueCAtIChvdyAtIHJ3KSAvIDI7XG4gICAgICAgICAgICBsZXQgdHJpbUJvdHRvbSA9IG9mZnNldC55ICsgKG9oIC0gcmgpIC8gMjtcbiAgICAgICAgICAgIGxldCB0cmltVG9wID0gb2Zmc2V0LnkgLSAob2ggLSByaCkgLyAyO1xuICAgICAgICAgICAgbCA9IHRyaW1MZWZ0ICogc2NhbGVYIC0gYXBweDtcbiAgICAgICAgICAgIGIgPSB0cmltQm90dG9tICogc2NhbGVZIC0gYXBweTtcbiAgICAgICAgICAgIHIgPSBjdyArIHRyaW1SaWdodCAqIHNjYWxlWCAtIGFwcHg7XG4gICAgICAgICAgICB0ID0gY2ggKyB0cmltVG9wICogc2NhbGVZIC0gYXBweTtcbiAgICAgICAgfVxuXG4gICAgICAgIGxldCBsb2NhbCA9IHRoaXMuX2xvY2FsO1xuICAgICAgICBsb2NhbFswXSA9IGw7XG4gICAgICAgIGxvY2FsWzFdID0gYjtcbiAgICAgICAgbG9jYWxbMl0gPSByO1xuICAgICAgICBsb2NhbFszXSA9IHQ7XG4gICAgICAgIHRoaXMudXBkYXRlV29ybGRWZXJ0cyhzcHJpdGUpO1xuICAgIH1cbn1cbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/MetaBalls/MetaBallsRenderer.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'db62dHiyKNNZJwjNHybzvIL', 'MetaBallsRenderer');
// Shader/MetaBalls/MetaBallsRenderer.ts

"use strict";
/****************************************************************************
 Author: GT <caogtaa@gmail.com>
 https://caogtaa.github.io
****************************************************************************/
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var MetaBallsAssembler_1 = require("./MetaBallsAssembler");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var MetaBallsRenderer = /** @class */ (function (_super) {
    __extends(MetaBallsRenderer, _super);
    function MetaBallsRenderer() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.materialWeb = null;
        _this.materialNative = null;
        return _this;
    }
    MetaBallsRenderer.prototype.onLoad = function () {
        if (CC_NATIVERENDERER) {
            this.materialNative && this.setMaterial(0, this.materialNative);
        }
        else {
            this.materialWeb && this.setMaterial(0, this.materialWeb);
        }
    };
    MetaBallsRenderer.prototype.SetParticles = function (particles) {
        //@ts-ignore
        this._assembler.particles = particles;
        var material = this.getMaterial(0);
        if (particles && material) {
            var PTM_RATIO = cc.PhysicsManager.PTM_RATIO;
            if (CC_NATIVERENDERER) {
                // native渲染时以节点anchor为世界空间原点
                material.setProperty("offset", [0.5, 0.5]);
            }
            else {
                // web默认以左下为世界空间原点。两个平台内shader内通过offset实现坐标统一
                material.setProperty("offset", [0.0, 0.0]);
            }
            // particles.GetRadius() * PTM_RATIO 是相对于场景(世界空间)的大小
            // particles.GetRadius() * PTM_RATIO / this.node.width 是相对于纹理的大小(纹理和屏幕同宽)，范围[0, 1]
            material.setProperty("radius", particles.GetRadius() * PTM_RATIO / this.node.width);
            material.setProperty("yratio", this.node.height / this.node.width);
            material.setProperty("reverseRes", [1.0 / this.node.width, 1.0 / this.node.height]);
        }
        this.setVertsDirty();
    };
    MetaBallsRenderer.prototype._resetAssembler = function () {
        this.setVertsDirty();
        var assembler = this._assembler = new MetaBallsAssembler_1.default();
        assembler.init(this);
    };
    MetaBallsRenderer.prototype.update = function () {
        this.setVertsDirty();
    };
    __decorate([
        property(cc.Material)
    ], MetaBallsRenderer.prototype, "materialWeb", void 0);
    __decorate([
        property(cc.Material)
    ], MetaBallsRenderer.prototype, "materialNative", void 0);
    MetaBallsRenderer = __decorate([
        ccclass
    ], MetaBallsRenderer);
    return MetaBallsRenderer;
}(cc.Sprite));
exports.default = MetaBallsRenderer;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvTWV0YUJhbGxzL01ldGFCYWxsc1JlbmRlcmVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTs7OzZFQUc2RTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRTdFLDJEQUFzRDtBQUVoRCxJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUcxQztJQUErQyxxQ0FBUztJQUF4RDtRQUFBLHFFQWdEQztRQTlDRyxpQkFBVyxHQUFnQixJQUFJLENBQUM7UUFHaEMsb0JBQWMsR0FBZ0IsSUFBSSxDQUFDOztJQTJDdkMsQ0FBQztJQXpDRyxrQ0FBTSxHQUFOO1FBQ0ksSUFBSSxpQkFBaUIsRUFBRTtZQUNuQixJQUFJLENBQUMsY0FBYyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztTQUNuRTthQUFNO1lBQ0gsSUFBSSxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7U0FDN0Q7SUFDTCxDQUFDO0lBRU0sd0NBQVksR0FBbkIsVUFBb0IsU0FBUztRQUN6QixZQUFZO1FBQ1osSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO1FBQ3RDLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbkMsSUFBSSxTQUFTLElBQUksUUFBUSxFQUFFO1lBQ3ZCLElBQUksU0FBUyxHQUFHLEVBQUUsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDO1lBQzVDLElBQUksaUJBQWlCLEVBQUU7Z0JBQ25CLDRCQUE0QjtnQkFDNUIsUUFBUSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQzthQUM5QztpQkFBTTtnQkFDSCw2Q0FBNkM7Z0JBQzdDLFFBQVEsQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7YUFDOUM7WUFFRCxvREFBb0Q7WUFDcEQsa0ZBQWtGO1lBQ2xGLFFBQVEsQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLFNBQVMsQ0FBQyxTQUFTLEVBQUUsR0FBRyxTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNwRixRQUFRLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ25FLFFBQVEsQ0FBQyxXQUFXLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLEdBQUcsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7U0FDdkY7UUFFRCxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDekIsQ0FBQztJQUVELDJDQUFlLEdBQWY7UUFDSSxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDckIsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLDRCQUFrQixFQUFFLENBQUM7UUFDM0QsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUN6QixDQUFDO0lBRUQsa0NBQU0sR0FBTjtRQUNJLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztJQUN6QixDQUFDO0lBN0NEO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUM7MERBQ1U7SUFHaEM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQzs2REFDYTtJQUxsQixpQkFBaUI7UUFEckMsT0FBTztPQUNhLGlCQUFpQixDQWdEckM7SUFBRCx3QkFBQztDQWhERCxBQWdEQyxDQWhEOEMsRUFBRSxDQUFDLE1BQU0sR0FnRHZEO2tCQWhEb0IsaUJBQWlCIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiBBdXRob3I6IEdUIDxjYW9ndGFhQGdtYWlsLmNvbT5cbiBodHRwczovL2Nhb2d0YWEuZ2l0aHViLmlvXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuXG5pbXBvcnQgTWV0YUJhbGxzQXNzZW1ibGVyIGZyb20gXCIuL01ldGFCYWxsc0Fzc2VtYmxlclwiO1xuXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE1ldGFCYWxsc1JlbmRlcmVyIGV4dGVuZHMgY2MuU3ByaXRlIHtcbiAgICBAcHJvcGVydHkoY2MuTWF0ZXJpYWwpXG4gICAgbWF0ZXJpYWxXZWI6IGNjLk1hdGVyaWFsID0gbnVsbDtcblxuICAgIEBwcm9wZXJ0eShjYy5NYXRlcmlhbClcbiAgICBtYXRlcmlhbE5hdGl2ZTogY2MuTWF0ZXJpYWwgPSBudWxsO1xuXG4gICAgb25Mb2FkKCkge1xuICAgICAgICBpZiAoQ0NfTkFUSVZFUkVOREVSRVIpIHtcbiAgICAgICAgICAgIHRoaXMubWF0ZXJpYWxOYXRpdmUgJiYgdGhpcy5zZXRNYXRlcmlhbCgwLCB0aGlzLm1hdGVyaWFsTmF0aXZlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMubWF0ZXJpYWxXZWIgJiYgdGhpcy5zZXRNYXRlcmlhbCgwLCB0aGlzLm1hdGVyaWFsV2ViKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHB1YmxpYyBTZXRQYXJ0aWNsZXMocGFydGljbGVzKSB7XG4gICAgICAgIC8vQHRzLWlnbm9yZVxuICAgICAgICB0aGlzLl9hc3NlbWJsZXIucGFydGljbGVzID0gcGFydGljbGVzO1xuICAgICAgICBsZXQgbWF0ZXJpYWwgPSB0aGlzLmdldE1hdGVyaWFsKDApO1xuICAgICAgICBpZiAocGFydGljbGVzICYmIG1hdGVyaWFsKSB7XG4gICAgICAgICAgICBsZXQgUFRNX1JBVElPID0gY2MuUGh5c2ljc01hbmFnZXIuUFRNX1JBVElPO1xuICAgICAgICAgICAgaWYgKENDX05BVElWRVJFTkRFUkVSKSB7XG4gICAgICAgICAgICAgICAgLy8gbmF0aXZl5riy5p+T5pe25Lul6IqC54K5YW5jaG9y5Li65LiW55WM56m66Ze05Y6f54K5XG4gICAgICAgICAgICAgICAgbWF0ZXJpYWwuc2V0UHJvcGVydHkoXCJvZmZzZXRcIiwgWzAuNSwgMC41XSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIHdlYum7mOiupOS7peW3puS4i+S4uuS4lueVjOepuumXtOWOn+eCueOAguS4pOS4quW5s+WPsOWGhXNoYWRlcuWGhemAmui/h29mZnNldOWunueOsOWdkOagh+e7n+S4gFxuICAgICAgICAgICAgICAgIG1hdGVyaWFsLnNldFByb3BlcnR5KFwib2Zmc2V0XCIsIFswLjAsIDAuMF0pO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBwYXJ0aWNsZXMuR2V0UmFkaXVzKCkgKiBQVE1fUkFUSU8g5piv55u45a+55LqO5Zy65pmvKOS4lueVjOepuumXtCnnmoTlpKflsI9cbiAgICAgICAgICAgIC8vIHBhcnRpY2xlcy5HZXRSYWRpdXMoKSAqIFBUTV9SQVRJTyAvIHRoaXMubm9kZS53aWR0aCDmmK/nm7jlr7nkuo7nurnnkIbnmoTlpKflsI8o57q555CG5ZKM5bGP5bmV5ZCM5a69Ke+8jOiMg+WbtFswLCAxXVxuICAgICAgICAgICAgbWF0ZXJpYWwuc2V0UHJvcGVydHkoXCJyYWRpdXNcIiwgcGFydGljbGVzLkdldFJhZGl1cygpICogUFRNX1JBVElPIC8gdGhpcy5ub2RlLndpZHRoKTtcbiAgICAgICAgICAgIG1hdGVyaWFsLnNldFByb3BlcnR5KFwieXJhdGlvXCIsIHRoaXMubm9kZS5oZWlnaHQgLyB0aGlzLm5vZGUud2lkdGgpO1xuICAgICAgICAgICAgbWF0ZXJpYWwuc2V0UHJvcGVydHkoXCJyZXZlcnNlUmVzXCIsIFsxLjAgLyB0aGlzLm5vZGUud2lkdGgsIDEuMCAvIHRoaXMubm9kZS5oZWlnaHRdKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuc2V0VmVydHNEaXJ0eSgpO1xuICAgIH1cblxuICAgIF9yZXNldEFzc2VtYmxlcigpIHtcbiAgICAgICAgdGhpcy5zZXRWZXJ0c0RpcnR5KCk7XG4gICAgICAgIGxldCBhc3NlbWJsZXIgPSB0aGlzLl9hc3NlbWJsZXIgPSBuZXcgTWV0YUJhbGxzQXNzZW1ibGVyKCk7XG4gICAgICAgIGFzc2VtYmxlci5pbml0KHRoaXMpO1xuICAgIH1cblxuICAgIHVwZGF0ZSgpIHtcbiAgICAgICAgdGhpcy5zZXRWZXJ0c0RpcnR5KCk7XG4gICAgfVxufVxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/MovingBG/MovingBGAssembler.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e1c35wY/WtDI4NVp88fW7Kq', 'MovingBGAssembler');
// Shader/MovingBG/MovingBGAssembler.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-13 02:44:17
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:03:25
*/
var GTSimpleSpriteAssembler2D_1 = require("../GTSimpleSpriteAssembler2D");
// 自定义顶点格式，在vfmtPosUvColor基础上，加入gfx.ATTR_UV1，去掉gfx.ATTR_COLOR
// 20200703 增加了uv2, uv3用于处理uv在图集里的映射
//@ts-ignore
var gfx = cc.gfx;
var vfmtCustom = new gfx.VertexFormat([
    { name: gfx.ATTR_POSITION, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: gfx.ATTR_UV0, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: gfx.ATTR_UV1, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: "a_p", type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: "a_q", type: gfx.ATTR_TYPE_FLOAT32, num: 2 } // 同上
]);
var VEC2_ZERO = cc.Vec2.ZERO;
var MovingBGAssembler = /** @class */ (function (_super) {
    __extends(MovingBGAssembler, _super);
    function MovingBGAssembler() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // 根据自定义顶点格式，调整下述常量
        _this.verticesCount = 4;
        _this.indicesCount = 6;
        _this.uvOffset = 2;
        _this.uv1Offset = 4;
        _this.uv2Offset = 6;
        _this.uv3Offset = 8;
        _this.floatsPerVert = 10;
        // 自定义数据，将被写入uv1的位置
        _this.moveSpeed = VEC2_ZERO;
        return _this;
    }
    MovingBGAssembler.prototype.initData = function () {
        var data = this._renderData;
        // createFlexData支持创建指定格式的renderData
        data.createFlexData(0, this.verticesCount, this.indicesCount, this.getVfmt());
        // createFlexData不会填充顶点索引信息，手动补充一下
        var indices = data.iDatas[0];
        var count = indices.length / 6;
        for (var i = 0, idx = 0; i < count; i++) {
            var vertextID = i * 4;
            indices[idx++] = vertextID;
            indices[idx++] = vertextID + 1;
            indices[idx++] = vertextID + 2;
            indices[idx++] = vertextID + 1;
            indices[idx++] = vertextID + 3;
            indices[idx++] = vertextID + 2;
        }
    };
    // 自定义格式以getVfmt()方式提供出去，除了当前assembler，render-flow的其他地方也会用到
    MovingBGAssembler.prototype.getVfmt = function () {
        return vfmtCustom;
    };
    // 重载getBuffer(), 返回一个能容纳自定义顶点数据的buffer
    // 默认fillBuffers()方法中会调用到
    MovingBGAssembler.prototype.getBuffer = function () {
        //@ts-ignore
        return cc.renderer._handle.getBuffer("mesh", this.getVfmt());
    };
    // pos数据没有变化，不用重载
    // updateVerts(sprite) {
    // }
    MovingBGAssembler.prototype.updateColor = function (sprite, color) {
        // 由于已经去掉了color字段，这里重载原方法，并且不做任何事
    };
    MovingBGAssembler.prototype.updateUVs = function (sprite) {
        _super.prototype.updateUVs.call(this, sprite);
        var uv = sprite._spriteFrame.uv;
        var uvOffset = this.uvOffset;
        var floatsPerVert = this.floatsPerVert;
        var verts = this._renderData.vDatas[0];
        var dstOffset;
        var l = uv[0], r = uv[2], t = uv[5], b = uv[1];
        // px, qx用于x轴的uv映射
        // py, qy同理，公式推导过程略...
        var px = 1.0 / (r - l), qx = -l * px; // l / (l-r);
        var py = 1.0 / (b - t), qy = -t * py; // t / (t-b);
        var sx = this.moveSpeed.x;
        var sy = this.moveSpeed.y;
        for (var i = 0; i < 4; ++i) {
            dstOffset = floatsPerVert * i + uvOffset;
            // fill uv1
            verts[dstOffset + 2] = sx;
            verts[dstOffset + 3] = sy;
            // fill uv2
            verts[dstOffset + 4] = px;
            verts[dstOffset + 5] = py;
            // fill uv3
            verts[dstOffset + 6] = qx;
            verts[dstOffset + 7] = qy;
        }
    };
    return MovingBGAssembler;
}(GTSimpleSpriteAssembler2D_1.default));
exports.default = MovingBGAssembler;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvTW92aW5nQkcvTW92aW5nQkdBc3NlbWJsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLGdEQUFnRDtBQUNoRCw0QkFBNEI7QUFDNUIsK0NBQStDO0FBQy9DLGdFQUFnRTs7Ozs7Ozs7Ozs7Ozs7O0FBRWhFOzs7O0VBSUU7QUFHRiwwRUFBcUU7QUFFckUsNkRBQTZEO0FBQzdELG9DQUFvQztBQUNwQyxZQUFZO0FBQ1osSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQztBQUNqQixJQUFJLFVBQVUsR0FBRyxJQUFJLEdBQUcsQ0FBQyxZQUFZLENBQUM7SUFDbEMsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLGFBQWEsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLGlCQUFpQixFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQUU7SUFDaEUsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLGlCQUFpQixFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQUU7SUFDM0QsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLGlCQUFpQixFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQUU7SUFDM0QsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsaUJBQWlCLEVBQUUsR0FBRyxFQUFFLENBQUMsRUFBRTtJQUNwRCxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQWdCLEtBQUs7Q0FDNUUsQ0FBQyxDQUFDO0FBRUgsSUFBTSxTQUFTLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7QUFFL0I7SUFBK0MscUNBQXlCO0lBQXhFO1FBQUEscUVBMEZDO1FBekZHLG1CQUFtQjtRQUNuQixtQkFBYSxHQUFHLENBQUMsQ0FBQztRQUNsQixrQkFBWSxHQUFHLENBQUMsQ0FBQztRQUNqQixjQUFRLEdBQUcsQ0FBQyxDQUFDO1FBQ2IsZUFBUyxHQUFHLENBQUMsQ0FBQztRQUNkLGVBQVMsR0FBRyxDQUFDLENBQUM7UUFDZCxlQUFTLEdBQUcsQ0FBQyxDQUFDO1FBQ2QsbUJBQWEsR0FBRyxFQUFFLENBQUM7UUFFbkIsbUJBQW1CO1FBQ1osZUFBUyxHQUFZLFNBQVMsQ0FBQzs7SUErRTFDLENBQUM7SUE5RUcsb0NBQVEsR0FBUjtRQUNJLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7UUFDNUIsb0NBQW9DO1FBQ3BDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztRQUU5RSxrQ0FBa0M7UUFDbEMsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM3QixJQUFJLEtBQUssR0FBRyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztRQUMvQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxHQUFHLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDckMsSUFBSSxTQUFTLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN0QixPQUFPLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxTQUFTLENBQUM7WUFDM0IsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsU0FBUyxHQUFDLENBQUMsQ0FBQztZQUM3QixPQUFPLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxTQUFTLEdBQUMsQ0FBQyxDQUFDO1lBQzdCLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLFNBQVMsR0FBQyxDQUFDLENBQUM7WUFDN0IsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsU0FBUyxHQUFDLENBQUMsQ0FBQztZQUM3QixPQUFPLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxTQUFTLEdBQUMsQ0FBQyxDQUFDO1NBQ2hDO0lBQ0wsQ0FBQztJQUVELDJEQUEyRDtJQUMzRCxtQ0FBTyxHQUFQO1FBQ0ksT0FBTyxVQUFVLENBQUM7SUFDdEIsQ0FBQztJQUVELHVDQUF1QztJQUN2Qyx5QkFBeUI7SUFDekIscUNBQVMsR0FBVDtRQUNJLFlBQVk7UUFDWixPQUFPLEVBQUUsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7SUFDakUsQ0FBQztJQUVELGlCQUFpQjtJQUNqQix3QkFBd0I7SUFDeEIsSUFBSTtJQUVKLHVDQUFXLEdBQVgsVUFBWSxNQUFNLEVBQUUsS0FBSztRQUNyQixpQ0FBaUM7SUFDckMsQ0FBQztJQUdELHFDQUFTLEdBQVQsVUFBVSxNQUFNO1FBQ1osaUJBQU0sU0FBUyxZQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3hCLElBQUksRUFBRSxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1FBQ2hDLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7UUFDN0IsSUFBSSxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUN2QyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2QyxJQUFJLFNBQVMsQ0FBQztRQUVkLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFDVCxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUNULENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQ1QsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVkLGtCQUFrQjtRQUNsQixzQkFBc0I7UUFDdEIsSUFBSSxFQUFFLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUNoQixFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUcsYUFBYTtRQUVqQyxJQUFJLEVBQUUsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQ2hCLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBRyxhQUFhO1FBRWpDLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO1FBQzFCLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO1FBQzFCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDeEIsU0FBUyxHQUFHLGFBQWEsR0FBRyxDQUFDLEdBQUcsUUFBUSxDQUFDO1lBQ3pDLFdBQVc7WUFDWCxLQUFLLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUMxQixLQUFLLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUUxQixXQUFXO1lBQ1gsS0FBSyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDMUIsS0FBSyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7WUFFMUIsV0FBVztZQUNYLEtBQUssQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQzFCLEtBQUssQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO1NBQzdCO0lBQ0wsQ0FBQztJQUNMLHdCQUFDO0FBQUQsQ0ExRkEsQUEwRkMsQ0ExRjhDLG1DQUF5QixHQTBGdkUiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDb3B5cmlnaHQgMjAyMCBDYW8gR2FvdGluZzxjYW9ndGFhQGdtYWlsLmNvbT5cbi8vIGh0dHBzOi8vY2FvZ3RhYS5naXRodWIuaW9cbi8vIFRoaXMgZmlsZSBpcyBsaWNlbnNlZCB1bmRlciB0aGUgTUlUIExpY2Vuc2UuXG4vLyBMaWNlbnNlIHRleHQgYXZhaWxhYmxlIGF0IGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlUXG5cbi8qXG4gKiBEYXRlOiAyMDIwLTA3LTEzIDAyOjQ0OjE3XG4gKiBMYXN0RWRpdG9yczogR1Q8Y2FvZ3RhYUBnbWFpbC5jb20+XG4gKiBMYXN0RWRpdFRpbWU6IDIwMjAtMDctMjIgMTQ6MDM6MjVcbiovIFxuXG5cbmltcG9ydCBHVFNpbXBsZVNwcml0ZUFzc2VtYmxlcjJEIGZyb20gXCIuLi9HVFNpbXBsZVNwcml0ZUFzc2VtYmxlcjJEXCI7XG5cbi8vIOiHquWumuS5iemhtueCueagvOW8j++8jOWcqHZmbXRQb3NVdkNvbG9y5Z+656GA5LiK77yM5Yqg5YWlZ2Z4LkFUVFJfVVYx77yM5Y675o6JZ2Z4LkFUVFJfQ09MT1Jcbi8vIDIwMjAwNzAzIOWinuWKoOS6hnV2MiwgdXYz55So5LqO5aSE55CGdXblnKjlm77pm4bph4znmoTmmKDlsIRcbi8vQHRzLWlnbm9yZVxubGV0IGdmeCA9IGNjLmdmeDtcbnZhciB2Zm10Q3VzdG9tID0gbmV3IGdmeC5WZXJ0ZXhGb3JtYXQoW1xuICAgIHsgbmFtZTogZ2Z4LkFUVFJfUE9TSVRJT04sIHR5cGU6IGdmeC5BVFRSX1RZUEVfRkxPQVQzMiwgbnVtOiAyIH0sXG4gICAgeyBuYW1lOiBnZnguQVRUUl9VVjAsIHR5cGU6IGdmeC5BVFRSX1RZUEVfRkxPQVQzMiwgbnVtOiAyIH0sICAgICAgICAvLyB0ZXh0dXJl57q555CGdXZcbiAgICB7IG5hbWU6IGdmeC5BVFRSX1VWMSwgdHlwZTogZ2Z4LkFUVFJfVFlQRV9GTE9BVDMyLCBudW06IDIgfSwgICAgICAgIC8vIHV2Me+8jOaOp+WItuWbvueJh+a7muWKqOaWueWQkSAmIOmAn+W6plxuICAgIHsgbmFtZTogXCJhX3BcIiwgdHlwZTogZ2Z4LkFUVFJfVFlQRV9GTE9BVDMyLCBudW06IDIgfSwgICAgICAgICAgICAgICAvLyB1diByZW1hcOWIsCBbMCwgMV3ljLrpl7TnlKjnmoTkuK3pl7Tlj5jph49cbiAgICB7IG5hbWU6IFwiYV9xXCIsIHR5cGU6IGdmeC5BVFRSX1RZUEVfRkxPQVQzMiwgbnVtOiAyIH0gICAgICAgICAgICAgICAgLy8g5ZCM5LiKXG5dKTtcblxuY29uc3QgVkVDMl9aRVJPID0gY2MuVmVjMi5aRVJPO1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNb3ZpbmdCR0Fzc2VtYmxlciBleHRlbmRzIEdUU2ltcGxlU3ByaXRlQXNzZW1ibGVyMkQge1xuICAgIC8vIOagueaNruiHquWumuS5iemhtueCueagvOW8j++8jOiwg+aVtOS4i+i/sOW4uOmHj1xuICAgIHZlcnRpY2VzQ291bnQgPSA0O1xuICAgIGluZGljZXNDb3VudCA9IDY7XG4gICAgdXZPZmZzZXQgPSAyO1xuICAgIHV2MU9mZnNldCA9IDQ7XG4gICAgdXYyT2Zmc2V0ID0gNjtcbiAgICB1djNPZmZzZXQgPSA4O1xuICAgIGZsb2F0c1BlclZlcnQgPSAxMDtcblxuICAgIC8vIOiHquWumuS5ieaVsOaNru+8jOWwhuiiq+WGmeWFpXV2MeeahOS9jee9rlxuICAgIHB1YmxpYyBtb3ZlU3BlZWQ6IGNjLlZlYzIgPSBWRUMyX1pFUk87XG4gICAgaW5pdERhdGEoKSB7XG4gICAgICAgIGxldCBkYXRhID0gdGhpcy5fcmVuZGVyRGF0YTtcbiAgICAgICAgLy8gY3JlYXRlRmxleERhdGHmlK/mjIHliJvlu7rmjIflrprmoLzlvI/nmoRyZW5kZXJEYXRhXG4gICAgICAgIGRhdGEuY3JlYXRlRmxleERhdGEoMCwgdGhpcy52ZXJ0aWNlc0NvdW50LCB0aGlzLmluZGljZXNDb3VudCwgdGhpcy5nZXRWZm10KCkpO1xuXG4gICAgICAgIC8vIGNyZWF0ZUZsZXhEYXRh5LiN5Lya5aGr5YWF6aG254K557Si5byV5L+h5oGv77yM5omL5Yqo6KGl5YWF5LiA5LiLXG4gICAgICAgIGxldCBpbmRpY2VzID0gZGF0YS5pRGF0YXNbMF07XG4gICAgICAgIGxldCBjb3VudCA9IGluZGljZXMubGVuZ3RoIC8gNjtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIGlkeCA9IDA7IGkgPCBjb3VudDsgaSsrKSB7XG4gICAgICAgICAgICBsZXQgdmVydGV4dElEID0gaSAqIDQ7XG4gICAgICAgICAgICBpbmRpY2VzW2lkeCsrXSA9IHZlcnRleHRJRDtcbiAgICAgICAgICAgIGluZGljZXNbaWR4KytdID0gdmVydGV4dElEKzE7XG4gICAgICAgICAgICBpbmRpY2VzW2lkeCsrXSA9IHZlcnRleHRJRCsyO1xuICAgICAgICAgICAgaW5kaWNlc1tpZHgrK10gPSB2ZXJ0ZXh0SUQrMTtcbiAgICAgICAgICAgIGluZGljZXNbaWR4KytdID0gdmVydGV4dElEKzM7XG4gICAgICAgICAgICBpbmRpY2VzW2lkeCsrXSA9IHZlcnRleHRJRCsyO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLy8g6Ieq5a6a5LmJ5qC85byP5LulZ2V0VmZtdCgp5pa55byP5o+Q5L6b5Ye65Y6777yM6Zmk5LqG5b2T5YmNYXNzZW1ibGVy77yMcmVuZGVyLWZsb3fnmoTlhbbku5blnLDmlrnkuZ/kvJrnlKjliLBcbiAgICBnZXRWZm10KCkge1xuICAgICAgICByZXR1cm4gdmZtdEN1c3RvbTtcbiAgICB9XG5cbiAgICAvLyDph43ovb1nZXRCdWZmZXIoKSwg6L+U5Zue5LiA5Liq6IO95a6557qz6Ieq5a6a5LmJ6aG254K55pWw5o2u55qEYnVmZmVyXG4gICAgLy8g6buY6K6kZmlsbEJ1ZmZlcnMoKeaWueazleS4reS8muiwg+eUqOWIsFxuICAgIGdldEJ1ZmZlcigpIHtcbiAgICAgICAgLy9AdHMtaWdub3JlXG4gICAgICAgIHJldHVybiBjYy5yZW5kZXJlci5faGFuZGxlLmdldEJ1ZmZlcihcIm1lc2hcIiwgdGhpcy5nZXRWZm10KCkpO1xuICAgIH1cblxuICAgIC8vIHBvc+aVsOaNruayoeacieWPmOWMlu+8jOS4jeeUqOmHjei9vVxuICAgIC8vIHVwZGF0ZVZlcnRzKHNwcml0ZSkge1xuICAgIC8vIH1cblxuICAgIHVwZGF0ZUNvbG9yKHNwcml0ZSwgY29sb3IpIHtcbiAgICAgICAgLy8g55Sx5LqO5bey57uP5Y675o6J5LqGY29sb3LlrZfmrrXvvIzov5nph4zph43ovb3ljp/mlrnms5XvvIzlubbkuJTkuI3lgZrku7vkvZXkuotcbiAgICB9XG5cblxuICAgIHVwZGF0ZVVWcyhzcHJpdGUpIHtcbiAgICAgICAgc3VwZXIudXBkYXRlVVZzKHNwcml0ZSk7XG4gICAgICAgIGxldCB1diA9IHNwcml0ZS5fc3ByaXRlRnJhbWUudXY7XG4gICAgICAgIGxldCB1dk9mZnNldCA9IHRoaXMudXZPZmZzZXQ7XG4gICAgICAgIGxldCBmbG9hdHNQZXJWZXJ0ID0gdGhpcy5mbG9hdHNQZXJWZXJ0O1xuICAgICAgICBsZXQgdmVydHMgPSB0aGlzLl9yZW5kZXJEYXRhLnZEYXRhc1swXTtcbiAgICAgICAgbGV0IGRzdE9mZnNldDtcblxuICAgICAgICBsZXQgbCA9IHV2WzBdLFxuICAgICAgICAgICAgciA9IHV2WzJdLFxuICAgICAgICAgICAgdCA9IHV2WzVdLFxuICAgICAgICAgICAgYiA9IHV2WzFdO1xuXG4gICAgICAgIC8vIHB4LCBxeOeUqOS6jnjovbTnmoR1duaYoOWwhFxuICAgICAgICAvLyBweSwgcXnlkIznkIbvvIzlhazlvI/mjqjlr7zov4fnqIvnlaUuLi5cbiAgICAgICAgbGV0IHB4ID0gMS4wIC8gKHItbCksXG4gICAgICAgICAgICBxeCA9IC1sICogcHg7ICAgLy8gbCAvIChsLXIpO1xuXG4gICAgICAgIGxldCBweSA9IDEuMCAvIChiLXQpLFxuICAgICAgICAgICAgcXkgPSAtdCAqIHB5OyAgIC8vIHQgLyAodC1iKTtcblxuICAgICAgICBsZXQgc3ggPSB0aGlzLm1vdmVTcGVlZC54O1xuICAgICAgICBsZXQgc3kgPSB0aGlzLm1vdmVTcGVlZC55O1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IDQ7ICsraSkge1xuICAgICAgICAgICAgZHN0T2Zmc2V0ID0gZmxvYXRzUGVyVmVydCAqIGkgKyB1dk9mZnNldDtcbiAgICAgICAgICAgIC8vIGZpbGwgdXYxXG4gICAgICAgICAgICB2ZXJ0c1tkc3RPZmZzZXQgKyAyXSA9IHN4O1xuICAgICAgICAgICAgdmVydHNbZHN0T2Zmc2V0ICsgM10gPSBzeTtcblxuICAgICAgICAgICAgLy8gZmlsbCB1djJcbiAgICAgICAgICAgIHZlcnRzW2RzdE9mZnNldCArIDRdID0gcHg7XG4gICAgICAgICAgICB2ZXJ0c1tkc3RPZmZzZXQgKyA1XSA9IHB5O1xuXG4gICAgICAgICAgICAvLyBmaWxsIHV2M1xuICAgICAgICAgICAgdmVydHNbZHN0T2Zmc2V0ICsgNl0gPSBxeDtcbiAgICAgICAgICAgIHZlcnRzW2RzdE9mZnNldCArIDddID0gcXk7XG4gICAgICAgIH1cbiAgICB9XG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/Helloworld.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '50f17991AxNx6ljR6LovrB0', 'Helloworld');
// Scripts/Helloworld.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Helloworld = /** @class */ (function (_super) {
    __extends(Helloworld, _super);
    function Helloworld() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.sp = null;
        _this.material = [];
        _this.curTime = 0;
        return _this;
    }
    Helloworld.prototype.start = function () {
        // init logic
    };
    Helloworld.prototype.changeProperty = function (time) {
        this.material[0].setProperty("time", time, 0, true);
    };
    Helloworld.prototype.update = function (dt) {
        this.curTime += dt;
        this.changeProperty(this.curTime);
    };
    __decorate([
        property(cc.Sprite)
    ], Helloworld.prototype, "sp", void 0);
    __decorate([
        property(cc.Material)
    ], Helloworld.prototype, "material", void 0);
    Helloworld = __decorate([
        ccclass
    ], Helloworld);
    return Helloworld;
}(cc.Component));
exports.default = Helloworld;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHRzL0hlbGxvd29ybGQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQU0sSUFBQSxLQUFzQixFQUFFLENBQUMsVUFBVSxFQUFsQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWlCLENBQUM7QUFHMUM7SUFBd0MsOEJBQVk7SUFBcEQ7UUFBQSxxRUF3QkM7UUFwQkcsUUFBRSxHQUFjLElBQUksQ0FBQztRQUdyQixjQUFRLEdBQWtCLEVBQUUsQ0FBQztRQUVyQixhQUFPLEdBQUcsQ0FBQyxDQUFDOztJQWV4QixDQUFDO0lBZEcsMEJBQUssR0FBTDtRQUNJLGFBQWE7SUFFakIsQ0FBQztJQUVELG1DQUFjLEdBQWQsVUFBZSxJQUFJO1FBQ2YsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRyxDQUFDLEVBQUcsSUFBSSxDQUFDLENBQUM7SUFDMUQsQ0FBQztJQUdELDJCQUFNLEdBQU4sVUFBTyxFQUFFO1FBQ0wsSUFBSSxDQUFDLE9BQU8sSUFBSSxFQUFFLENBQUM7UUFDbkIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQW5CRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDOzBDQUNDO0lBR3JCO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUM7Z0RBQ087SUFQWixVQUFVO1FBRDlCLE9BQU87T0FDYSxVQUFVLENBd0I5QjtJQUFELGlCQUFDO0NBeEJELEFBd0JDLENBeEJ1QyxFQUFFLENBQUMsU0FBUyxHQXdCbkQ7a0JBeEJvQixVQUFVIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3Qge2NjY2xhc3MsIHByb3BlcnR5fSA9IGNjLl9kZWNvcmF0b3I7XG5cbkBjY2NsYXNzXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBIZWxsb3dvcmxkIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcblxuICAgXG4gICAgQHByb3BlcnR5KGNjLlNwcml0ZSlcbiAgICBzcDogY2MuU3ByaXRlID0gbnVsbDtcblxuICAgIEBwcm9wZXJ0eShjYy5NYXRlcmlhbClcbiAgICBtYXRlcmlhbDogY2MuTWF0ZXJpYWxbXSA9IFtdO1xuXG4gICAgcHJpdmF0ZSBjdXJUaW1lID0gMDtcbiAgICBzdGFydCAoKSB7XG4gICAgICAgIC8vIGluaXQgbG9naWNcblxuICAgIH1cblxuICAgIGNoYW5nZVByb3BlcnR5KHRpbWUpe1xuICAgICAgICB0aGlzLm1hdGVyaWFsWzBdLnNldFByb3BlcnR5KFwidGltZVwiLCB0aW1lICwgMCAsIHRydWUpO1xuICAgIH1cblxuXG4gICAgdXBkYXRlKGR0KXtcbiAgICAgICAgdGhpcy5jdXJUaW1lICs9IGR0O1xuICAgICAgICB0aGlzLmNoYW5nZVByb3BlcnR5KHRoaXMuY3VyVGltZSk7XG4gICAgfVxufVxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/LayeredBatching/LayeredBatchingAssembler.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '9b7db/QlVpNR6BkHD3PCH0u', 'LayeredBatchingAssembler');
// Shader/LayeredBatching/LayeredBatchingAssembler.ts

"use strict";
/****************************************************************************
 Author: GT <caogtaa@gmail.com>
 https://caogtaa.github.io
****************************************************************************/
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var GTSimpleSpriteAssembler2D_1 = require("../GTSimpleSpriteAssembler2D");
// RenderFlow遍历过程中，需要防止子节点进入的函数
var RENDER_MASK = cc.RenderFlow.FLAG_RENDER | cc.RenderFlow.FLAG_POST_RENDER;
var PROP_DIRTY_MASK = cc.RenderFlow.FLAG_OPACITY | cc.RenderFlow.FLAG_WORLD_TRANSFORM;
// 通过开关控制仅在拥有该Assembler的根节点开启合批优化
// 用于避免该Assembler被嵌套使用
var BATCH_OPTIMIZE_SWITCH = true;
var LayeredBatchingAssembler = /** @class */ (function (_super) {
    __extends(LayeredBatchingAssembler, _super);
    function LayeredBatchingAssembler() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    LayeredBatchingAssembler.prototype.fillBuffers = function (comp, renderer) {
        _super.prototype.fillBuffers.call(this, comp, renderer);
        if (CC_EDITOR || CC_NATIVERENDERER)
            return;
        if (!BATCH_OPTIMIZE_SWITCH)
            return;
        var layer = [];
        this._layers = [layer];
        // 当前节点是自定义渲染的根节点，worldDirtyFlag属性将被逐层传递
        // 此处的dirtyFlag包含世界坐标变化、透明度变化。（参考render-flow.js的_children函数）
        var worldTransformFlag = renderer.worldMatDirty ? cc.RenderFlow.FLAG_WORLD_TRANSFORM : 0;
        var worldOpacityFlag = renderer.parentOpacityDirty ? cc.RenderFlow.FLAG_OPACITY_COLOR : 0;
        var dirtyFlag = worldTransformFlag | worldOpacityFlag;
        comp.node["__gtDirtyFlag"] = dirtyFlag;
        // BFS过程
        var queue = [];
        queue.push(comp.node);
        var depth = 0;
        var end = 1;
        var iter = 0;
        var gtRenderFlag;
        while (iter < queue.length) {
            var node = queue[iter++];
            dirtyFlag = node["__gtDirtyFlag"];
            for (var _i = 0, _a = node.children; _i < _a.length; _i++) {
                var c = _a[_i];
                if (!c._activeInHierarchy || c._opacity === 0)
                    continue;
                gtRenderFlag = c._renderFlag & RENDER_MASK;
                if (gtRenderFlag > 0) {
                    // 移除子节点的renderFlag，使renderFlow不执行它的RENDER函数
                    c["__gtRenderFlag"] = gtRenderFlag;
                    c._renderFlag &= ~gtRenderFlag;
                    layer.push(c);
                }
                // 逐层传递父节点的dirtyFlag
                c["__gtDirtyFlag"] = dirtyFlag | (c._renderFlag & PROP_DIRTY_MASK);
                queue.push(c);
            }
            if (iter == end) {
                // 完成当前层遍历，开始下一层遍历
                ++depth;
                end = queue.length;
                layer = [];
                this._layers.push(layer);
            }
        }
    };
    LayeredBatchingAssembler.prototype.postFillBuffers = function (comp, renderer) {
        // 记录worldMatDirty，函数退出时重置回去
        var originWorldMatDirty = renderer.worldMatDirty;
        if (!BATCH_OPTIMIZE_SWITCH || !this._layers)
            return;
        // off优化开关，避免嵌套
        BATCH_OPTIMIZE_SWITCH = false;
        var gtRenderFlag;
        var gtDirtyFlag;
        // 按层级遍历所有子节点
        for (var _i = 0, _a = this._layers; _i < _a.length; _i++) {
            var layer = _a[_i];
            if (layer.length == 0)
                continue;
            for (var _b = 0, layer_1 = layer; _b < layer_1.length; _b++) {
                var c = layer_1[_b];
                gtRenderFlag = c["__gtRenderFlag"];
                gtDirtyFlag = c["__gtDirtyFlag"];
                // 设置worldMatDirty，在引擎默认fillBuffers()中该变量用于判断是否更新世界坐标
                renderer.worldMatDirty = gtDirtyFlag > 0 ? 1 : 0;
                c._renderFlag |= gtRenderFlag;
                // 调用子节点RenderFlow的剩余部分
                cc.RenderFlow.flows[gtRenderFlag]._func(c);
            }
        }
        this._layers = null;
        BATCH_OPTIMIZE_SWITCH = true;
        renderer.worldMatDirty = originWorldMatDirty;
    };
    return LayeredBatchingAssembler;
}(GTSimpleSpriteAssembler2D_1.default));
exports.default = LayeredBatchingAssembler;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvTGF5ZXJlZEJhdGNoaW5nL0xheWVyZWRCYXRjaGluZ0Fzc2VtYmxlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7Ozs2RUFHNkU7Ozs7Ozs7Ozs7Ozs7OztBQUU3RSwwRUFBcUU7QUFFckUsK0JBQStCO0FBQy9CLElBQU0sV0FBVyxHQUFHLEVBQUUsQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUM7QUFDL0UsSUFBTSxlQUFlLEdBQUcsRUFBRSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQztBQUV4RixpQ0FBaUM7QUFDakMsc0JBQXNCO0FBQ3RCLElBQUkscUJBQXFCLEdBQVksSUFBSSxDQUFDO0FBRTFDO0lBQXNELDRDQUF5QjtJQUEvRTs7SUE4RkEsQ0FBQztJQTNGRyw4Q0FBVyxHQUFYLFVBQVksSUFBSSxFQUFFLFFBQVE7UUFDdEIsaUJBQU0sV0FBVyxZQUFDLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQztRQUVsQyxJQUFJLFNBQVMsSUFBSSxpQkFBaUI7WUFDOUIsT0FBTztRQUVYLElBQUksQ0FBQyxxQkFBcUI7WUFDdEIsT0FBTztRQUVYLElBQUksS0FBSyxHQUFHLEVBQUUsQ0FBQztRQUNmLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUV2Qix3Q0FBd0M7UUFDeEMsNERBQTREO1FBQzVELElBQUksa0JBQWtCLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3pGLElBQUksZ0JBQWdCLEdBQUcsUUFBUSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDMUYsSUFBSSxTQUFTLEdBQUcsa0JBQWtCLEdBQUcsZ0JBQWdCLENBQUM7UUFDdEQsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxTQUFTLENBQUM7UUFFdkMsUUFBUTtRQUNSLElBQUksS0FBSyxHQUFHLEVBQUUsQ0FBQztRQUNmLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRXRCLElBQUksS0FBSyxHQUFXLENBQUMsQ0FBQztRQUN0QixJQUFJLEdBQUcsR0FBVyxDQUFDLENBQUM7UUFDcEIsSUFBSSxJQUFJLEdBQVcsQ0FBQyxDQUFDO1FBQ3JCLElBQUksWUFBWSxDQUFDO1FBQ2pCLE9BQU8sSUFBSSxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUU7WUFDeEIsSUFBSSxJQUFJLEdBQUcsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7WUFDekIsU0FBUyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztZQUVsQyxLQUFjLFVBQWEsRUFBYixLQUFBLElBQUksQ0FBQyxRQUFRLEVBQWIsY0FBYSxFQUFiLElBQWEsRUFBRTtnQkFBeEIsSUFBSSxDQUFDLFNBQUE7Z0JBQ04sSUFBSSxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsSUFBSSxDQUFDLENBQUMsUUFBUSxLQUFLLENBQUM7b0JBQ3pDLFNBQVM7Z0JBRWIsWUFBWSxHQUFHLENBQUMsQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDO2dCQUMzQyxJQUFJLFlBQVksR0FBRyxDQUFDLEVBQUU7b0JBQ2xCLDRDQUE0QztvQkFDNUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsWUFBWSxDQUFDO29CQUNuQyxDQUFDLENBQUMsV0FBVyxJQUFJLENBQUMsWUFBWSxDQUFDO29CQUMvQixLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNqQjtnQkFFRCxvQkFBb0I7Z0JBQ3BCLENBQUMsQ0FBQyxlQUFlLENBQUMsR0FBRyxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUMsV0FBVyxHQUFHLGVBQWUsQ0FBQyxDQUFDO2dCQUNuRSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ2pCO1lBRUQsSUFBSSxJQUFJLElBQUksR0FBRyxFQUFFO2dCQUNiLGtCQUFrQjtnQkFDbEIsRUFBRyxLQUFLLENBQUM7Z0JBQ1QsR0FBRyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUM7Z0JBQ25CLEtBQUssR0FBRyxFQUFFLENBQUM7Z0JBQ1gsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDNUI7U0FDSjtJQUNMLENBQUM7SUFFRCxrREFBZSxHQUFmLFVBQWdCLElBQUksRUFBRSxRQUFRO1FBQzFCLDRCQUE0QjtRQUM1QixJQUFJLG1CQUFtQixHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUM7UUFDakQsSUFBSSxDQUFDLHFCQUFxQixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU87WUFDdkMsT0FBTztRQUVYLGVBQWU7UUFDZixxQkFBcUIsR0FBRyxLQUFLLENBQUM7UUFDOUIsSUFBSSxZQUFZLENBQUM7UUFDakIsSUFBSSxXQUFXLENBQUM7UUFFaEIsYUFBYTtRQUNiLEtBQWtCLFVBQVksRUFBWixLQUFBLElBQUksQ0FBQyxPQUFPLEVBQVosY0FBWSxFQUFaLElBQVksRUFBRTtZQUEzQixJQUFJLEtBQUssU0FBQTtZQUNWLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxDQUFDO2dCQUNqQixTQUFTO1lBRWIsS0FBYyxVQUFLLEVBQUwsZUFBSyxFQUFMLG1CQUFLLEVBQUwsSUFBSyxFQUFFO2dCQUFoQixJQUFJLENBQUMsY0FBQTtnQkFDTixZQUFZLEdBQUcsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUM7Z0JBQ25DLFdBQVcsR0FBRyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUM7Z0JBRWpDLHFEQUFxRDtnQkFDckQsUUFBUSxDQUFDLGFBQWEsR0FBRyxXQUFXLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDakQsQ0FBQyxDQUFDLFdBQVcsSUFBSSxZQUFZLENBQUM7Z0JBRTlCLHVCQUF1QjtnQkFDdkIsRUFBRSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzlDO1NBQ0o7UUFFRCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztRQUNwQixxQkFBcUIsR0FBRyxJQUFJLENBQUM7UUFDN0IsUUFBUSxDQUFDLGFBQWEsR0FBRyxtQkFBbUIsQ0FBQztJQUNqRCxDQUFDO0lBQ0wsK0JBQUM7QUFBRCxDQTlGQSxBQThGQyxDQTlGcUQsbUNBQXlCLEdBOEY5RSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gQXV0aG9yOiBHVCA8Y2FvZ3RhYUBnbWFpbC5jb20+XG4gaHR0cHM6Ly9jYW9ndGFhLmdpdGh1Yi5pb1xuKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cblxuaW1wb3J0IEdUU2ltcGxlU3ByaXRlQXNzZW1ibGVyMkQgZnJvbSBcIi4uL0dUU2ltcGxlU3ByaXRlQXNzZW1ibGVyMkRcIjtcblxuLy8gUmVuZGVyRmxvd+mBjeWOhui/h+eoi+S4re+8jOmcgOimgemYsuatouWtkOiKgueCuei/m+WFpeeahOWHveaVsFxuY29uc3QgUkVOREVSX01BU0sgPSBjYy5SZW5kZXJGbG93LkZMQUdfUkVOREVSIHwgY2MuUmVuZGVyRmxvdy5GTEFHX1BPU1RfUkVOREVSO1xuY29uc3QgUFJPUF9ESVJUWV9NQVNLID0gY2MuUmVuZGVyRmxvdy5GTEFHX09QQUNJVFkgfCBjYy5SZW5kZXJGbG93LkZMQUdfV09STERfVFJBTlNGT1JNO1xuXG4vLyDpgJrov4flvIDlhbPmjqfliLbku4XlnKjmi6XmnInor6VBc3NlbWJsZXLnmoTmoLnoioLngrnlvIDlkK/lkIjmibnkvJjljJZcbi8vIOeUqOS6jumBv+WFjeivpUFzc2VtYmxlcuiiq+W1jOWll+S9v+eUqFxubGV0IEJBVENIX09QVElNSVpFX1NXSVRDSDogYm9vbGVhbiA9IHRydWU7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIExheWVyZWRCYXRjaGluZ0Fzc2VtYmxlciBleHRlbmRzIEdUU2ltcGxlU3ByaXRlQXNzZW1ibGVyMkQge1xuICAgIHByb3RlY3RlZCBfbGF5ZXJzOiBBcnJheTxBcnJheTxjYy5Ob2RlPj47XG5cbiAgICBmaWxsQnVmZmVycyhjb21wLCByZW5kZXJlcikge1xuICAgICAgICBzdXBlci5maWxsQnVmZmVycyhjb21wLCByZW5kZXJlcik7XG5cbiAgICAgICAgaWYgKENDX0VESVRPUiB8fCBDQ19OQVRJVkVSRU5ERVJFUilcbiAgICAgICAgICAgIHJldHVybjtcblxuICAgICAgICBpZiAoIUJBVENIX09QVElNSVpFX1NXSVRDSClcbiAgICAgICAgICAgIHJldHVybjtcblxuICAgICAgICBsZXQgbGF5ZXIgPSBbXTtcbiAgICAgICAgdGhpcy5fbGF5ZXJzID0gW2xheWVyXTtcblxuICAgICAgICAvLyDlvZPliY3oioLngrnmmK/oh6rlrprkuYnmuLLmn5PnmoTmoLnoioLngrnvvIx3b3JsZERpcnR5RmxhZ+WxnuaAp+Wwhuiiq+mAkOWxguS8oOmAklxuICAgICAgICAvLyDmraTlpITnmoRkaXJ0eUZsYWfljIXlkKvkuJbnlYzlnZDmoIflj5jljJbjgIHpgI/mmI7luqblj5jljJbjgILvvIjlj4LogINyZW5kZXItZmxvdy5qc+eahF9jaGlsZHJlbuWHveaVsO+8iVxuICAgICAgICBsZXQgd29ybGRUcmFuc2Zvcm1GbGFnID0gcmVuZGVyZXIud29ybGRNYXREaXJ0eSA/IGNjLlJlbmRlckZsb3cuRkxBR19XT1JMRF9UUkFOU0ZPUk0gOiAwO1xuICAgICAgICBsZXQgd29ybGRPcGFjaXR5RmxhZyA9IHJlbmRlcmVyLnBhcmVudE9wYWNpdHlEaXJ0eSA/IGNjLlJlbmRlckZsb3cuRkxBR19PUEFDSVRZX0NPTE9SIDogMDtcbiAgICAgICAgbGV0IGRpcnR5RmxhZyA9IHdvcmxkVHJhbnNmb3JtRmxhZyB8IHdvcmxkT3BhY2l0eUZsYWc7XG4gICAgICAgIGNvbXAubm9kZVtcIl9fZ3REaXJ0eUZsYWdcIl0gPSBkaXJ0eUZsYWc7XG5cbiAgICAgICAgLy8gQkZT6L+H56iLXG4gICAgICAgIGxldCBxdWV1ZSA9IFtdO1xuICAgICAgICBxdWV1ZS5wdXNoKGNvbXAubm9kZSk7XG5cbiAgICAgICAgbGV0IGRlcHRoOiBudW1iZXIgPSAwO1xuICAgICAgICBsZXQgZW5kOiBudW1iZXIgPSAxO1xuICAgICAgICBsZXQgaXRlcjogbnVtYmVyID0gMDtcbiAgICAgICAgbGV0IGd0UmVuZGVyRmxhZztcbiAgICAgICAgd2hpbGUgKGl0ZXIgPCBxdWV1ZS5sZW5ndGgpIHtcbiAgICAgICAgICAgIGxldCBub2RlID0gcXVldWVbaXRlcisrXTtcbiAgICAgICAgICAgIGRpcnR5RmxhZyA9IG5vZGVbXCJfX2d0RGlydHlGbGFnXCJdO1xuXG4gICAgICAgICAgICBmb3IgKGxldCBjIG9mIG5vZGUuY2hpbGRyZW4pIHtcbiAgICAgICAgICAgICAgICBpZiAoIWMuX2FjdGl2ZUluSGllcmFyY2h5IHx8IGMuX29wYWNpdHkgPT09IDApXG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuXG4gICAgICAgICAgICAgICAgZ3RSZW5kZXJGbGFnID0gYy5fcmVuZGVyRmxhZyAmIFJFTkRFUl9NQVNLO1xuICAgICAgICAgICAgICAgIGlmIChndFJlbmRlckZsYWcgPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIOenu+mZpOWtkOiKgueCueeahHJlbmRlckZsYWfvvIzkvb9yZW5kZXJGbG935LiN5omn6KGM5a6D55qEUkVOREVS5Ye95pWwXG4gICAgICAgICAgICAgICAgICAgIGNbXCJfX2d0UmVuZGVyRmxhZ1wiXSA9IGd0UmVuZGVyRmxhZztcbiAgICAgICAgICAgICAgICAgICAgYy5fcmVuZGVyRmxhZyAmPSB+Z3RSZW5kZXJGbGFnO1xuICAgICAgICAgICAgICAgICAgICBsYXllci5wdXNoKGMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAvLyDpgJDlsYLkvKDpgJLniLboioLngrnnmoRkaXJ0eUZsYWdcbiAgICAgICAgICAgICAgICBjW1wiX19ndERpcnR5RmxhZ1wiXSA9IGRpcnR5RmxhZyB8IChjLl9yZW5kZXJGbGFnICYgUFJPUF9ESVJUWV9NQVNLKTtcbiAgICAgICAgICAgICAgICBxdWV1ZS5wdXNoKGMpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoaXRlciA9PSBlbmQpIHtcbiAgICAgICAgICAgICAgICAvLyDlrozmiJDlvZPliY3lsYLpgY3ljobvvIzlvIDlp4vkuIvkuIDlsYLpgY3ljoZcbiAgICAgICAgICAgICAgICArKyBkZXB0aDtcbiAgICAgICAgICAgICAgICBlbmQgPSBxdWV1ZS5sZW5ndGg7XG4gICAgICAgICAgICAgICAgbGF5ZXIgPSBbXTtcbiAgICAgICAgICAgICAgICB0aGlzLl9sYXllcnMucHVzaChsYXllcik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwb3N0RmlsbEJ1ZmZlcnMoY29tcCwgcmVuZGVyZXIpIHtcbiAgICAgICAgLy8g6K6w5b2Vd29ybGRNYXREaXJ0ee+8jOWHveaVsOmAgOWHuuaXtumHjee9ruWbnuWOu1xuICAgICAgICBsZXQgb3JpZ2luV29ybGRNYXREaXJ0eSA9IHJlbmRlcmVyLndvcmxkTWF0RGlydHk7XG4gICAgICAgIGlmICghQkFUQ0hfT1BUSU1JWkVfU1dJVENIIHx8ICF0aGlzLl9sYXllcnMpXG4gICAgICAgICAgICByZXR1cm47XG5cbiAgICAgICAgLy8gb2Zm5LyY5YyW5byA5YWz77yM6YG/5YWN5bWM5aWXXG4gICAgICAgIEJBVENIX09QVElNSVpFX1NXSVRDSCA9IGZhbHNlO1xuICAgICAgICBsZXQgZ3RSZW5kZXJGbGFnO1xuICAgICAgICBsZXQgZ3REaXJ0eUZsYWc7XG5cbiAgICAgICAgLy8g5oyJ5bGC57qn6YGN5Y6G5omA5pyJ5a2Q6IqC54K5XG4gICAgICAgIGZvciAobGV0IGxheWVyIG9mIHRoaXMuX2xheWVycykge1xuICAgICAgICAgICAgaWYgKGxheWVyLmxlbmd0aCA9PSAwKVxuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuXG4gICAgICAgICAgICBmb3IgKGxldCBjIG9mIGxheWVyKSB7XG4gICAgICAgICAgICAgICAgZ3RSZW5kZXJGbGFnID0gY1tcIl9fZ3RSZW5kZXJGbGFnXCJdO1xuICAgICAgICAgICAgICAgIGd0RGlydHlGbGFnID0gY1tcIl9fZ3REaXJ0eUZsYWdcIl07XG5cbiAgICAgICAgICAgICAgICAvLyDorr7nva53b3JsZE1hdERpcnR577yM5Zyo5byV5pOO6buY6K6kZmlsbEJ1ZmZlcnMoKeS4reivpeWPmOmHj+eUqOS6juWIpOaWreaYr+WQpuabtOaWsOS4lueVjOWdkOagh1xuICAgICAgICAgICAgICAgIHJlbmRlcmVyLndvcmxkTWF0RGlydHkgPSBndERpcnR5RmxhZyA+IDAgPyAxIDogMDtcbiAgICAgICAgICAgICAgICBjLl9yZW5kZXJGbGFnIHw9IGd0UmVuZGVyRmxhZztcblxuICAgICAgICAgICAgICAgIC8vIOiwg+eUqOWtkOiKgueCuVJlbmRlckZsb3fnmoTliankvZnpg6jliIZcbiAgICAgICAgICAgICAgICBjYy5SZW5kZXJGbG93LmZsb3dzW2d0UmVuZGVyRmxhZ10uX2Z1bmMoYyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLl9sYXllcnMgPSBudWxsO1xuICAgICAgICBCQVRDSF9PUFRJTUlaRV9TV0lUQ0ggPSB0cnVlO1xuICAgICAgICByZW5kZXJlci53b3JsZE1hdERpcnR5ID0gb3JpZ2luV29ybGRNYXREaXJ0eTtcbiAgICB9XG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Shader/SpriteMaskedAvatar/SpriteMaskedAvatarAssembler.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'da46czoLEBHc711TNBTITkZ', 'SpriteMaskedAvatarAssembler');
// Shader/SpriteMaskedAvatar/SpriteMaskedAvatarAssembler.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-22 20:19:16
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-23 16:45:31
*/
var GTAutoFitSpriteAssembler2D_1 = require("../GTAutoFitSpriteAssembler2D");
//@ts-ignore
var gfx = cc.gfx;
var vfmtPosUvUv = new gfx.VertexFormat([
    { name: gfx.ATTR_POSITION, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: gfx.ATTR_UV0, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: "a_mask_uv", type: gfx.ATTR_TYPE_FLOAT32, num: 2 }
]);
var SpriteMaskedAvatarAssembler = /** @class */ (function (_super) {
    __extends(SpriteMaskedAvatarAssembler, _super);
    function SpriteMaskedAvatarAssembler() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.maskUvOffset = 4;
        _this.floatsPerVert = 6;
        return _this;
    }
    // todo: mixin this part
    SpriteMaskedAvatarAssembler.prototype.initData = function () {
        var data = this._renderData;
        // createFlexData支持创建指定格式的renderData
        data.createFlexData(0, this.verticesCount, this.indicesCount, this.getVfmt());
        // createFlexData不会填充顶点索引信息，手动补充一下
        var indices = data.iDatas[0];
        var count = indices.length / 6;
        for (var i = 0, idx = 0; i < count; i++) {
            var vertextID = i * 4;
            indices[idx++] = vertextID;
            indices[idx++] = vertextID + 1;
            indices[idx++] = vertextID + 2;
            indices[idx++] = vertextID + 1;
            indices[idx++] = vertextID + 3;
            indices[idx++] = vertextID + 2;
        }
    };
    SpriteMaskedAvatarAssembler.prototype.getVfmt = function () {
        return vfmtPosUvUv;
    };
    SpriteMaskedAvatarAssembler.prototype.getBuffer = function () {
        //@ts-ignore
        return cc.renderer._handle.getBuffer("mesh", this.getVfmt());
    };
    SpriteMaskedAvatarAssembler.prototype.updateColor = function (comp, color) {
        // do nothing
    };
    SpriteMaskedAvatarAssembler.prototype.updateUVs = function (sprite) {
        _super.prototype.updateUVs.call(this, sprite);
        var maskUvOffset = this.maskUvOffset;
        var floatsPerVert = this.floatsPerVert;
        var verts = this._renderData.vDatas[0];
        var maskUv = sprite._mask.uv;
        for (var i = 0; i < 4; i++) {
            var srcOffset = i * 2;
            var dstOffset = floatsPerVert * i + maskUvOffset;
            verts[dstOffset] = maskUv[srcOffset];
            verts[dstOffset + 1] = maskUv[srcOffset + 1];
        }
    };
    return SpriteMaskedAvatarAssembler;
}(GTAutoFitSpriteAssembler2D_1.default));
exports.default = SpriteMaskedAvatarAssembler;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TaGFkZXIvU3ByaXRlTWFza2VkQXZhdGFyL1Nwcml0ZU1hc2tlZEF2YXRhckFzc2VtYmxlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsZ0RBQWdEO0FBQ2hELDRCQUE0QjtBQUM1QiwrQ0FBK0M7QUFDL0MsZ0VBQWdFOzs7Ozs7Ozs7Ozs7Ozs7QUFFaEU7Ozs7RUFJRTtBQUVGLDRFQUF1RTtBQUV2RSxZQUFZO0FBQ1osSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQztBQUNqQixJQUFJLFdBQVcsR0FBRyxJQUFJLEdBQUcsQ0FBQyxZQUFZLENBQUM7SUFDbkMsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLGFBQWEsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLGlCQUFpQixFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQUU7SUFDaEUsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLGlCQUFpQixFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQUU7SUFDM0QsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsaUJBQWlCLEVBQUUsR0FBRyxFQUFFLENBQUMsRUFBRTtDQUM3RCxDQUFDLENBQUM7QUFFSDtJQUF5RCwrQ0FBMEI7SUFBbkY7UUFBQSxxRUFtREM7UUFsREcsa0JBQVksR0FBRyxDQUFDLENBQUM7UUFDakIsbUJBQWEsR0FBRyxDQUFDLENBQUM7O0lBaUR0QixDQUFDO0lBL0NHLHdCQUF3QjtJQUN4Qiw4Q0FBUSxHQUFSO1FBQ0ksSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQztRQUM1QixvQ0FBb0M7UUFDcEMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBRTlFLGtDQUFrQztRQUNsQyxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzdCLElBQUksS0FBSyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQy9CLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEdBQUcsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNyQyxJQUFJLFNBQVMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3RCLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLFNBQVMsQ0FBQztZQUMzQixPQUFPLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxTQUFTLEdBQUMsQ0FBQyxDQUFDO1lBQzdCLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLFNBQVMsR0FBQyxDQUFDLENBQUM7WUFDN0IsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsU0FBUyxHQUFDLENBQUMsQ0FBQztZQUM3QixPQUFPLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxTQUFTLEdBQUMsQ0FBQyxDQUFDO1lBQzdCLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLFNBQVMsR0FBQyxDQUFDLENBQUM7U0FDaEM7SUFDTCxDQUFDO0lBRUQsNkNBQU8sR0FBUDtRQUNJLE9BQU8sV0FBVyxDQUFDO0lBQ3ZCLENBQUM7SUFFRCwrQ0FBUyxHQUFUO1FBQ0ksWUFBWTtRQUNaLE9BQU8sRUFBRSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBRUQsaURBQVcsR0FBWCxVQUFZLElBQUksRUFBRSxLQUFLO1FBQ25CLGFBQWE7SUFDakIsQ0FBQztJQUVELCtDQUFTLEdBQVQsVUFBVSxNQUFNO1FBQ1osaUJBQU0sU0FBUyxZQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRXhCLElBQUksWUFBWSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7UUFDckMsSUFBSSxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUN2QyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2QyxJQUFJLE1BQU0sR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztRQUM3QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3hCLElBQUksU0FBUyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDdEIsSUFBSSxTQUFTLEdBQUcsYUFBYSxHQUFHLENBQUMsR0FBRyxZQUFZLENBQUM7WUFDakQsS0FBSyxDQUFDLFNBQVMsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNyQyxLQUFLLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDaEQ7SUFDTCxDQUFDO0lBQ0wsa0NBQUM7QUFBRCxDQW5EQSxBQW1EQyxDQW5Ed0Qsb0NBQTBCLEdBbURsRiIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIENvcHlyaWdodCAyMDIwIENhbyBHYW90aW5nPGNhb2d0YWFAZ21haWwuY29tPlxuLy8gaHR0cHM6Ly9jYW9ndGFhLmdpdGh1Yi5pb1xuLy8gVGhpcyBmaWxlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS5cbi8vIExpY2Vuc2UgdGV4dCBhdmFpbGFibGUgYXQgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVRcblxuLypcbiAqIERhdGU6IDIwMjAtMDctMjIgMjA6MTk6MTZcbiAqIExhc3RFZGl0b3JzOiBHVDxjYW9ndGFhQGdtYWlsLmNvbT5cbiAqIExhc3RFZGl0VGltZTogMjAyMC0wNy0yMyAxNjo0NTozMVxuKi8gXG5cbmltcG9ydCBHVEF1dG9GaXRTcHJpdGVBc3NlbWJsZXIyRCBmcm9tIFwiLi4vR1RBdXRvRml0U3ByaXRlQXNzZW1ibGVyMkRcIjtcblxuLy9AdHMtaWdub3JlXG5sZXQgZ2Z4ID0gY2MuZ2Z4O1xudmFyIHZmbXRQb3NVdlV2ID0gbmV3IGdmeC5WZXJ0ZXhGb3JtYXQoW1xuICAgIHsgbmFtZTogZ2Z4LkFUVFJfUE9TSVRJT04sIHR5cGU6IGdmeC5BVFRSX1RZUEVfRkxPQVQzMiwgbnVtOiAyIH0sXG4gICAgeyBuYW1lOiBnZnguQVRUUl9VVjAsIHR5cGU6IGdmeC5BVFRSX1RZUEVfRkxPQVQzMiwgbnVtOiAyIH0sXG4gICAgeyBuYW1lOiBcImFfbWFza191dlwiLCB0eXBlOiBnZnguQVRUUl9UWVBFX0ZMT0FUMzIsIG51bTogMiB9XG5dKTtcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgU3ByaXRlTWFza2VkQXZhdGFyQXNzZW1ibGVyIGV4dGVuZHMgR1RBdXRvRml0U3ByaXRlQXNzZW1ibGVyMkQge1xuICAgIG1hc2tVdk9mZnNldCA9IDQ7XG4gICAgZmxvYXRzUGVyVmVydCA9IDY7XG5cbiAgICAvLyB0b2RvOiBtaXhpbiB0aGlzIHBhcnRcbiAgICBpbml0RGF0YSgpIHtcbiAgICAgICAgbGV0IGRhdGEgPSB0aGlzLl9yZW5kZXJEYXRhO1xuICAgICAgICAvLyBjcmVhdGVGbGV4RGF0YeaUr+aMgeWIm+W7uuaMh+WumuagvOW8j+eahHJlbmRlckRhdGFcbiAgICAgICAgZGF0YS5jcmVhdGVGbGV4RGF0YSgwLCB0aGlzLnZlcnRpY2VzQ291bnQsIHRoaXMuaW5kaWNlc0NvdW50LCB0aGlzLmdldFZmbXQoKSk7XG5cbiAgICAgICAgLy8gY3JlYXRlRmxleERhdGHkuI3kvJrloavlhYXpobbngrnntKLlvJXkv6Hmga/vvIzmiYvliqjooaXlhYXkuIDkuItcbiAgICAgICAgbGV0IGluZGljZXMgPSBkYXRhLmlEYXRhc1swXTtcbiAgICAgICAgbGV0IGNvdW50ID0gaW5kaWNlcy5sZW5ndGggLyA2O1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgaWR4ID0gMDsgaSA8IGNvdW50OyBpKyspIHtcbiAgICAgICAgICAgIGxldCB2ZXJ0ZXh0SUQgPSBpICogNDtcbiAgICAgICAgICAgIGluZGljZXNbaWR4KytdID0gdmVydGV4dElEO1xuICAgICAgICAgICAgaW5kaWNlc1tpZHgrK10gPSB2ZXJ0ZXh0SUQrMTtcbiAgICAgICAgICAgIGluZGljZXNbaWR4KytdID0gdmVydGV4dElEKzI7XG4gICAgICAgICAgICBpbmRpY2VzW2lkeCsrXSA9IHZlcnRleHRJRCsxO1xuICAgICAgICAgICAgaW5kaWNlc1tpZHgrK10gPSB2ZXJ0ZXh0SUQrMztcbiAgICAgICAgICAgIGluZGljZXNbaWR4KytdID0gdmVydGV4dElEKzI7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBnZXRWZm10KCkge1xuICAgICAgICByZXR1cm4gdmZtdFBvc1V2VXY7XG4gICAgfVxuXG4gICAgZ2V0QnVmZmVyKCkge1xuICAgICAgICAvL0B0cy1pZ25vcmVcbiAgICAgICAgcmV0dXJuIGNjLnJlbmRlcmVyLl9oYW5kbGUuZ2V0QnVmZmVyKFwibWVzaFwiLCB0aGlzLmdldFZmbXQoKSk7XG4gICAgfVxuXG4gICAgdXBkYXRlQ29sb3IoY29tcCwgY29sb3IpIHtcbiAgICAgICAgLy8gZG8gbm90aGluZ1xuICAgIH1cblxuICAgIHVwZGF0ZVVWcyhzcHJpdGUpIHtcbiAgICAgICAgc3VwZXIudXBkYXRlVVZzKHNwcml0ZSk7XG5cbiAgICAgICAgbGV0IG1hc2tVdk9mZnNldCA9IHRoaXMubWFza1V2T2Zmc2V0O1xuICAgICAgICBsZXQgZmxvYXRzUGVyVmVydCA9IHRoaXMuZmxvYXRzUGVyVmVydDtcbiAgICAgICAgbGV0IHZlcnRzID0gdGhpcy5fcmVuZGVyRGF0YS52RGF0YXNbMF07XG4gICAgICAgIGxldCBtYXNrVXYgPSBzcHJpdGUuX21hc2sudXY7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgNDsgaSsrKSB7XG4gICAgICAgICAgICBsZXQgc3JjT2Zmc2V0ID0gaSAqIDI7XG4gICAgICAgICAgICBsZXQgZHN0T2Zmc2V0ID0gZmxvYXRzUGVyVmVydCAqIGkgKyBtYXNrVXZPZmZzZXQ7XG4gICAgICAgICAgICB2ZXJ0c1tkc3RPZmZzZXRdID0gbWFza1V2W3NyY09mZnNldF07XG4gICAgICAgICAgICB2ZXJ0c1tkc3RPZmZzZXQgKyAxXSA9IG1hc2tVdltzcmNPZmZzZXQgKyAxXTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/Misc/NavigatorButton.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '58a22OqN5RI3plga6Z+CurZ', 'NavigatorButton');
// Scripts/Misc/NavigatorButton.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-13 02:48:43
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:01:23
*/
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NavigatorButton = /** @class */ (function (_super) {
    __extends(NavigatorButton, _super);
    function NavigatorButton() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.sceneName = "SceneWelcome";
        return _this;
    }
    NavigatorButton.prototype.onLoad = function () {
        var sceneName = this.sceneName;
        this.node.on(cc.Node.EventType.TOUCH_END, function () {
            cc.director.loadScene(sceneName);
        });
    };
    __decorate([
        property(cc.String)
    ], NavigatorButton.prototype, "sceneName", void 0);
    NavigatorButton = __decorate([
        ccclass
    ], NavigatorButton);
    return NavigatorButton;
}(cc.Component));
exports.default = NavigatorButton;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHRzL01pc2MvTmF2aWdhdG9yQnV0dG9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxnREFBZ0Q7QUFDaEQsNEJBQTRCO0FBQzVCLCtDQUErQztBQUMvQyxnRUFBZ0U7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVoRTs7OztFQUlFO0FBR0ksSUFBQSxLQUF3QixFQUFFLENBQUMsVUFBVSxFQUFuQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWtCLENBQUM7QUFHNUM7SUFBNkMsbUNBQVk7SUFBekQ7UUFBQSxxRUFVQztRQVJHLGVBQVMsR0FBVyxjQUFjLENBQUM7O0lBUXZDLENBQUM7SUFORyxnQ0FBTSxHQUFOO1FBQ0ksSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztRQUMvQixJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUU7WUFDdEMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDckMsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBUEQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQztzREFDZTtJQUZsQixlQUFlO1FBRG5DLE9BQU87T0FDYSxlQUFlLENBVW5DO0lBQUQsc0JBQUM7Q0FWRCxBQVVDLENBVjRDLEVBQUUsQ0FBQyxTQUFTLEdBVXhEO2tCQVZvQixlQUFlIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gQ29weXJpZ2h0IDIwMjAgQ2FvIEdhb3Rpbmc8Y2FvZ3RhYUBnbWFpbC5jb20+XG4vLyBodHRwczovL2Nhb2d0YWEuZ2l0aHViLmlvXG4vLyBUaGlzIGZpbGUgaXMgbGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLlxuLy8gTGljZW5zZSB0ZXh0IGF2YWlsYWJsZSBhdCBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVFxuXG4vKlxuICogRGF0ZTogMjAyMC0wNy0xMyAwMjo0ODo0M1xuICogTGFzdEVkaXRvcnM6IEdUPGNhb2d0YWFAZ21haWwuY29tPlxuICogTGFzdEVkaXRUaW1lOiAyMDIwLTA3LTIyIDE0OjAxOjIzXG4qLyBcblxuXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xuXG5AY2NjbGFzc1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTmF2aWdhdG9yQnV0dG9uIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcbiAgICBAcHJvcGVydHkoY2MuU3RyaW5nKVxuICAgIHNjZW5lTmFtZTogc3RyaW5nID0gXCJTY2VuZVdlbGNvbWVcIjtcblxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgbGV0IHNjZW5lTmFtZSA9IHRoaXMuc2NlbmVOYW1lO1xuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELCAoKSA9PiB7XG4gICAgICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoc2NlbmVOYW1lKTtcbiAgICAgICAgfSk7XG4gICAgfVxufVxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/Scene/SceneTestGraphics.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '7ec6envootE0LqAVSRT/P5s', 'SceneTestGraphics');
// Scripts/Scene/SceneTestGraphics.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-23 16:15:08
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-23 16:43:03
*/
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SceneTestGraphics = /** @class */ (function (_super) {
    __extends(SceneTestGraphics, _super);
    function SceneTestGraphics() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.graphics = null;
        return _this;
    }
    SceneTestGraphics.prototype.onLoad = function () {
        var ctx = this.graphics;
        ctx.clear();
        ctx.strokeColor = cc.Color.BLACK;
        ctx.fillColor = cc.Color.RED;
        ctx.lineWidth = 5;
        ctx.moveTo(0, 0);
        ctx.lineTo(100, 100);
        ctx.stroke();
        ctx.rect(20, 20, 80, 100);
        ctx.fill();
    };
    __decorate([
        property(cc.Graphics)
    ], SceneTestGraphics.prototype, "graphics", void 0);
    SceneTestGraphics = __decorate([
        ccclass
    ], SceneTestGraphics);
    return SceneTestGraphics;
}(cc.Component));
exports.default = SceneTestGraphics;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHRzL1NjZW5lL1NjZW5lVGVzdEdyYXBoaWNzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxnREFBZ0Q7QUFDaEQsNEJBQTRCO0FBQzVCLCtDQUErQztBQUMvQyxnRUFBZ0U7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVoRTs7OztFQUlFO0FBRUksSUFBQSxLQUF3QixFQUFFLENBQUMsVUFBVSxFQUFuQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWtCLENBQUM7QUFHNUM7SUFBK0MscUNBQVk7SUFBM0Q7UUFBQSxxRUFpQkM7UUFmRyxjQUFRLEdBQWdCLElBQUksQ0FBQzs7SUFlakMsQ0FBQztJQWJHLGtDQUFNLEdBQU47UUFDSSxJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDO1FBQ3hCLEdBQUcsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNaLEdBQUcsQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDakMsR0FBRyxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztRQUM3QixHQUFHLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQztRQUNsQixHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNqQixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNyQixHQUFHLENBQUMsTUFBTSxFQUFFLENBQUM7UUFFYixHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQzFCLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUNmLENBQUM7SUFkRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDO3VEQUNPO0lBRlosaUJBQWlCO1FBRHJDLE9BQU87T0FDYSxpQkFBaUIsQ0FpQnJDO0lBQUQsd0JBQUM7Q0FqQkQsQUFpQkMsQ0FqQjhDLEVBQUUsQ0FBQyxTQUFTLEdBaUIxRDtrQkFqQm9CLGlCQUFpQiIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIENvcHlyaWdodCAyMDIwIENhbyBHYW90aW5nPGNhb2d0YWFAZ21haWwuY29tPlxuLy8gaHR0cHM6Ly9jYW9ndGFhLmdpdGh1Yi5pb1xuLy8gVGhpcyBmaWxlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS5cbi8vIExpY2Vuc2UgdGV4dCBhdmFpbGFibGUgYXQgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVRcblxuLypcbiAqIERhdGU6IDIwMjAtMDctMjMgMTY6MTU6MDhcbiAqIExhc3RFZGl0b3JzOiBHVDxjYW9ndGFhQGdtYWlsLmNvbT5cbiAqIExhc3RFZGl0VGltZTogMjAyMC0wNy0yMyAxNjo0MzowM1xuKi9cblxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFNjZW5lVGVzdEdyYXBoaWNzIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcbiAgICBAcHJvcGVydHkoY2MuR3JhcGhpY3MpXG4gICAgZ3JhcGhpY3M6IGNjLkdyYXBoaWNzID0gbnVsbDtcblxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgbGV0IGN0eCA9IHRoaXMuZ3JhcGhpY3M7XG4gICAgICAgIGN0eC5jbGVhcigpO1xuICAgICAgICBjdHguc3Ryb2tlQ29sb3IgPSBjYy5Db2xvci5CTEFDSztcbiAgICAgICAgY3R4LmZpbGxDb2xvciA9IGNjLkNvbG9yLlJFRDtcbiAgICAgICAgY3R4LmxpbmVXaWR0aCA9IDU7XG4gICAgICAgIGN0eC5tb3ZlVG8oMCwgMCk7XG4gICAgICAgIGN0eC5saW5lVG8oMTAwLCAxMDApO1xuICAgICAgICBjdHguc3Ryb2tlKCk7XG5cbiAgICAgICAgY3R4LnJlY3QoMjAsIDIwLCA4MCwgMTAwKTtcbiAgICAgICAgY3R4LmZpbGwoKTsgICAgXG4gICAgfVxufVxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/Scene/SceneLayeredBatchingScrollView.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'a8e90q5ybRNipx0efwIGCPq', 'SceneLayeredBatchingScrollView');
// Scripts/Scene/SceneLayeredBatchingScrollView.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-13 02:44:17
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:01:40
*/
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SceneLayeredBatchingScrollView = /** @class */ (function (_super) {
    __extends(SceneLayeredBatchingScrollView, _super);
    function SceneLayeredBatchingScrollView() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.item = null;
        _this.content = null;
        return _this;
    }
    SceneLayeredBatchingScrollView.prototype.onLoad = function () {
        for (var i = 0; i < 100; ++i) {
            var newItem = cc.instantiate(this.item);
            newItem.parent = this.content;
        }
    };
    __decorate([
        property(cc.Node)
    ], SceneLayeredBatchingScrollView.prototype, "item", void 0);
    __decorate([
        property(cc.Node)
    ], SceneLayeredBatchingScrollView.prototype, "content", void 0);
    SceneLayeredBatchingScrollView = __decorate([
        ccclass
    ], SceneLayeredBatchingScrollView);
    return SceneLayeredBatchingScrollView;
}(cc.Component));
exports.default = SceneLayeredBatchingScrollView;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHRzL1NjZW5lL1NjZW5lTGF5ZXJlZEJhdGNoaW5nU2Nyb2xsVmlldy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsZ0RBQWdEO0FBQ2hELDRCQUE0QjtBQUM1QiwrQ0FBK0M7QUFDL0MsZ0VBQWdFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFaEU7Ozs7RUFJRTtBQUVJLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQTRELGtEQUFZO0lBQXhFO1FBQUEscUVBYUM7UUFYRyxVQUFJLEdBQVksSUFBSSxDQUFDO1FBR3JCLGFBQU8sR0FBWSxJQUFJLENBQUM7O0lBUTVCLENBQUM7SUFORywrQ0FBTSxHQUFOO1FBQ0ksS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsRUFBRSxFQUFFLENBQUMsRUFBRTtZQUMxQixJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUN4QyxPQUFPLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7U0FDakM7SUFDTCxDQUFDO0lBVkQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQztnRUFDRztJQUdyQjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDO21FQUNNO0lBTFAsOEJBQThCO1FBRGxELE9BQU87T0FDYSw4QkFBOEIsQ0FhbEQ7SUFBRCxxQ0FBQztDQWJELEFBYUMsQ0FiMkQsRUFBRSxDQUFDLFNBQVMsR0FhdkU7a0JBYm9CLDhCQUE4QiIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIENvcHlyaWdodCAyMDIwIENhbyBHYW90aW5nPGNhb2d0YWFAZ21haWwuY29tPlxuLy8gaHR0cHM6Ly9jYW9ndGFhLmdpdGh1Yi5pb1xuLy8gVGhpcyBmaWxlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS5cbi8vIExpY2Vuc2UgdGV4dCBhdmFpbGFibGUgYXQgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVRcblxuLypcbiAqIERhdGU6IDIwMjAtMDctMTMgMDI6NDQ6MTdcbiAqIExhc3RFZGl0b3JzOiBHVDxjYW9ndGFhQGdtYWlsLmNvbT5cbiAqIExhc3RFZGl0VGltZTogMjAyMC0wNy0yMiAxNDowMTo0MFxuKi8gXG5cbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XG5cbkBjY2NsYXNzXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBTY2VuZUxheWVyZWRCYXRjaGluZ1Njcm9sbFZpZXcgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxuICAgIGl0ZW06IGNjLk5vZGUgPSBudWxsO1xuXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXG4gICAgY29udGVudDogY2MuTm9kZSA9IG51bGw7XG5cbiAgICBvbkxvYWQoKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgMTAwOyArK2kpIHtcbiAgICAgICAgICAgIGxldCBuZXdJdGVtID0gY2MuaW5zdGFudGlhdGUodGhpcy5pdGVtKTtcbiAgICAgICAgICAgIG5ld0l0ZW0ucGFyZW50ID0gdGhpcy5jb250ZW50O1xuICAgICAgICB9XG4gICAgfVxufVxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/Scene/SceneSpriteMaskedAvatars.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e358arsN59DbZ0N3kUBhrCb', 'SceneSpriteMaskedAvatars');
// Scripts/Scene/SceneSpriteMaskedAvatars.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-22 02:50:07
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:02:05
*/
var SpriteMaskedAvatarSprite_1 = require("../../Shader/SpriteMaskedAvatar/SpriteMaskedAvatarSprite");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SceneSpriteMaskedAvatars = /** @class */ (function (_super) {
    __extends(SceneSpriteMaskedAvatars, _super);
    function SceneSpriteMaskedAvatars() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.board = null;
        _this._enableMask = true;
        return _this;
    }
    SceneSpriteMaskedAvatars.prototype.onLoad = function () {
    };
    SceneSpriteMaskedAvatars.prototype.onToggleMask = function () {
        var enable = this._enableMask = !this._enableMask;
        for (var _i = 0, _a = this.board.children; _i < _a.length; _i++) {
            var c = _a[_i];
            var comp = c.getComponent(SpriteMaskedAvatarSprite_1.default);
            comp.enableMask = enable;
        }
    };
    __decorate([
        property(cc.Node)
    ], SceneSpriteMaskedAvatars.prototype, "board", void 0);
    SceneSpriteMaskedAvatars = __decorate([
        ccclass
    ], SceneSpriteMaskedAvatars);
    return SceneSpriteMaskedAvatars;
}(cc.Component));
exports.default = SceneSpriteMaskedAvatars;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHRzL1NjZW5lL1NjZW5lU3ByaXRlTWFza2VkQXZhdGFycy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsZ0RBQWdEO0FBQ2hELDRCQUE0QjtBQUM1QiwrQ0FBK0M7QUFDL0MsZ0VBQWdFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFaEU7Ozs7RUFJRTtBQUVGLHFHQUFnRztBQUUxRixJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUc1QztJQUFzRCw0Q0FBWTtJQUFsRTtRQUFBLHFFQWtCQztRQWhCRyxXQUFLLEdBQVksSUFBSSxDQUFDO1FBRVosaUJBQVcsR0FBWSxJQUFJLENBQUM7O0lBYzFDLENBQUM7SUFaRyx5Q0FBTSxHQUFOO0lBRUEsQ0FBQztJQUVELCtDQUFZLEdBQVo7UUFDSSxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQztRQUVsRCxLQUFjLFVBQW1CLEVBQW5CLEtBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQW5CLGNBQW1CLEVBQW5CLElBQW1CLEVBQUU7WUFBOUIsSUFBSSxDQUFDLFNBQUE7WUFDTixJQUFJLElBQUksR0FBRyxDQUFDLENBQUMsWUFBWSxDQUFDLGtDQUF3QixDQUFDLENBQUM7WUFDcEQsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUM7U0FDNUI7SUFDTCxDQUFDO0lBZkQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzsyREFDSTtJQUZMLHdCQUF3QjtRQUQ1QyxPQUFPO09BQ2Esd0JBQXdCLENBa0I1QztJQUFELCtCQUFDO0NBbEJELEFBa0JDLENBbEJxRCxFQUFFLENBQUMsU0FBUyxHQWtCakU7a0JBbEJvQix3QkFBd0IiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDb3B5cmlnaHQgMjAyMCBDYW8gR2FvdGluZzxjYW9ndGFhQGdtYWlsLmNvbT5cbi8vIGh0dHBzOi8vY2FvZ3RhYS5naXRodWIuaW9cbi8vIFRoaXMgZmlsZSBpcyBsaWNlbnNlZCB1bmRlciB0aGUgTUlUIExpY2Vuc2UuXG4vLyBMaWNlbnNlIHRleHQgYXZhaWxhYmxlIGF0IGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlUXG5cbi8qXG4gKiBEYXRlOiAyMDIwLTA3LTIyIDAyOjUwOjA3XG4gKiBMYXN0RWRpdG9yczogR1Q8Y2FvZ3RhYUBnbWFpbC5jb20+XG4gKiBMYXN0RWRpdFRpbWU6IDIwMjAtMDctMjIgMTQ6MDI6MDVcbiovIFxuXG5pbXBvcnQgU3ByaXRlTWFza2VkQXZhdGFyU3ByaXRlIGZyb20gXCIuLi8uLi9TaGFkZXIvU3ByaXRlTWFza2VkQXZhdGFyL1Nwcml0ZU1hc2tlZEF2YXRhclNwcml0ZVwiO1xuXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xuXG5AY2NjbGFzc1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgU2NlbmVTcHJpdGVNYXNrZWRBdmF0YXJzIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcbiAgICBib2FyZDogY2MuTm9kZSA9IG51bGw7XG5cbiAgICBwcm90ZWN0ZWQgX2VuYWJsZU1hc2s6IGJvb2xlYW4gPSB0cnVlO1xuXG4gICAgb25Mb2FkKCkge1xuXG4gICAgfVxuXG4gICAgb25Ub2dnbGVNYXNrKCkge1xuICAgICAgICBsZXQgZW5hYmxlID0gdGhpcy5fZW5hYmxlTWFzayA9ICF0aGlzLl9lbmFibGVNYXNrO1xuXG4gICAgICAgIGZvciAobGV0IGMgb2YgdGhpcy5ib2FyZC5jaGlsZHJlbikge1xuICAgICAgICAgICAgbGV0IGNvbXAgPSBjLmdldENvbXBvbmVudChTcHJpdGVNYXNrZWRBdmF0YXJTcHJpdGUpO1xuICAgICAgICAgICAgY29tcC5lbmFibGVNYXNrID0gZW5hYmxlO1xuICAgICAgICB9XG4gICAgfVxufVxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/Scene/SceneTest.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '4d102k6wppNGIkjlgi8Oycw', 'SceneTest');
// Scripts/Scene/SceneTest.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-13 02:44:17
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-28 16:47:00
*/
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SceneTest = /** @class */ (function (_super) {
    __extends(SceneTest, _super);
    function SceneTest() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SceneTest.prototype.onLoad = function () {
    };
    SceneTest = __decorate([
        ccclass
    ], SceneTest);
    return SceneTest;
}(cc.Component));
exports.default = SceneTest;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHRzL1NjZW5lL1NjZW5lVGVzdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsZ0RBQWdEO0FBQ2hELDRCQUE0QjtBQUM1QiwrQ0FBK0M7QUFDL0MsZ0VBQWdFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFaEU7Ozs7RUFJRTtBQUNJLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQXVDLDZCQUFZO0lBQW5EOztJQUdBLENBQUM7SUFGRywwQkFBTSxHQUFOO0lBQ0EsQ0FBQztJQUZnQixTQUFTO1FBRDdCLE9BQU87T0FDYSxTQUFTLENBRzdCO0lBQUQsZ0JBQUM7Q0FIRCxBQUdDLENBSHNDLEVBQUUsQ0FBQyxTQUFTLEdBR2xEO2tCQUhvQixTQUFTIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gQ29weXJpZ2h0IDIwMjAgQ2FvIEdhb3Rpbmc8Y2FvZ3RhYUBnbWFpbC5jb20+XG4vLyBodHRwczovL2Nhb2d0YWEuZ2l0aHViLmlvXG4vLyBUaGlzIGZpbGUgaXMgbGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLlxuLy8gTGljZW5zZSB0ZXh0IGF2YWlsYWJsZSBhdCBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVFxuXG4vKlxuICogRGF0ZTogMjAyMC0wNy0xMyAwMjo0NDoxN1xuICogTGFzdEVkaXRvcnM6IEdUPGNhb2d0YWFAZ21haWwuY29tPlxuICogTGFzdEVkaXRUaW1lOiAyMDIwLTA3LTI4IDE2OjQ3OjAwXG4qLyBcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XG5cbkBjY2NsYXNzXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBTY2VuZVRlc3QgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xuICAgIG9uTG9hZCgpIHtcbiAgICB9XG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/Scene/SceneWelcome.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8efa3lyFNdPHJ6ND0fspcQz', 'SceneWelcome');
// Scripts/Scene/SceneWelcome.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-13 02:44:17
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:02:12
*/
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SceneTest = /** @class */ (function (_super) {
    __extends(SceneTest, _super);
    function SceneTest() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SceneTest.prototype.onLoad = function () {
    };
    SceneTest.prototype.onBtnClick = function (e) {
        var name = e.currentTarget.name;
        cc.director.loadScene(name);
    };
    SceneTest = __decorate([
        ccclass
    ], SceneTest);
    return SceneTest;
}(cc.Component));
exports.default = SceneTest;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHRzL1NjZW5lL1NjZW5lV2VsY29tZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsZ0RBQWdEO0FBQ2hELDRCQUE0QjtBQUM1QiwrQ0FBK0M7QUFDL0MsZ0VBQWdFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFaEU7Ozs7RUFJRTtBQUVJLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQXVDLDZCQUFZO0lBQW5EOztJQVFBLENBQUM7SUFQRywwQkFBTSxHQUFOO0lBQ0EsQ0FBQztJQUVELDhCQUFVLEdBQVYsVUFBVyxDQUFDO1FBQ1IsSUFBSSxJQUFJLEdBQUcsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUM7UUFDaEMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDaEMsQ0FBQztJQVBnQixTQUFTO1FBRDdCLE9BQU87T0FDYSxTQUFTLENBUTdCO0lBQUQsZ0JBQUM7Q0FSRCxBQVFDLENBUnNDLEVBQUUsQ0FBQyxTQUFTLEdBUWxEO2tCQVJvQixTQUFTIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gQ29weXJpZ2h0IDIwMjAgQ2FvIEdhb3Rpbmc8Y2FvZ3RhYUBnbWFpbC5jb20+XG4vLyBodHRwczovL2Nhb2d0YWEuZ2l0aHViLmlvXG4vLyBUaGlzIGZpbGUgaXMgbGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLlxuLy8gTGljZW5zZSB0ZXh0IGF2YWlsYWJsZSBhdCBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVFxuXG4vKlxuICogRGF0ZTogMjAyMC0wNy0xMyAwMjo0NDoxN1xuICogTGFzdEVkaXRvcnM6IEdUPGNhb2d0YWFAZ21haWwuY29tPlxuICogTGFzdEVkaXRUaW1lOiAyMDIwLTA3LTIyIDE0OjAyOjEyXG4qLyBcblxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFNjZW5lVGVzdCBleHRlbmRzIGNjLkNvbXBvbmVudCB7XG4gICAgb25Mb2FkKCkge1xuICAgIH1cblxuICAgIG9uQnRuQ2xpY2soZSkge1xuICAgICAgICBsZXQgbmFtZSA9IGUuY3VycmVudFRhcmdldC5uYW1lO1xuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUobmFtZSk7XG4gICAgfVxufVxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/Misc/SimpleDraggable.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '89871MxfkBJjJh0o236XNDC', 'SimpleDraggable');
// Scripts/Misc/SimpleDraggable.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-13 02:44:17
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:01:30
*/
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SimpleDraggable = /** @class */ (function (_super) {
    __extends(SimpleDraggable, _super);
    function SimpleDraggable() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._touchOffset = cc.Vec2.ZERO;
        _this._isDragging = false;
        _this._moveCallback = null;
        return _this;
    }
    SimpleDraggable.prototype.onLoad = function () {
        this.node.on(cc.Node.EventType.TOUCH_START, this.OnTouchStart.bind(this));
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.OnTouchMove.bind(this));
        this.node.on(cc.Node.EventType.TOUCH_END, this.OnTouchEnd.bind(this));
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.OnTouchEnd.bind(this));
    };
    SimpleDraggable.prototype.Setup = function (moveCallback) {
        this._moveCallback = moveCallback;
    };
    SimpleDraggable.prototype.OnTouchStart = function (e) {
        var touchWorldPos = e.getLocation();
        var nodeWorldPos = this.node.convertToWorldSpaceAR(cc.Vec2.ZERO);
        this._touchOffset = nodeWorldPos.sub(touchWorldPos);
        this._isDragging = true;
        this._moveCallback && this._moveCallback(this.node.position);
    };
    SimpleDraggable.prototype.OnTouchMove = function (e) {
        if (!this._isDragging)
            return;
        var touchWorldPos = e.getLocation();
        this.TraceTouchPos(touchWorldPos);
        this._moveCallback && this._moveCallback(this.node.position);
    };
    SimpleDraggable.prototype.OnTouchEnd = function (e) {
        if (!this._isDragging)
            return;
        this._isDragging = false;
    };
    SimpleDraggable.prototype.TraceTouchPos = function (worldPos) {
        var nodeWorldPos = worldPos.add(this._touchOffset);
        var localPos = this.node.parent.convertToNodeSpaceAR(nodeWorldPos);
        this.node.position = localPos;
    };
    SimpleDraggable = __decorate([
        ccclass
    ], SimpleDraggable);
    return SimpleDraggable;
}(cc.Component));
exports.default = SimpleDraggable;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHRzL01pc2MvU2ltcGxlRHJhZ2dhYmxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxnREFBZ0Q7QUFDaEQsNEJBQTRCO0FBQzVCLCtDQUErQztBQUMvQyxnRUFBZ0U7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVoRTs7OztFQUlFO0FBR0ksSUFBQSxLQUF3QixFQUFFLENBQUMsVUFBVSxFQUFuQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWtCLENBQUM7QUFHNUM7SUFBNkMsbUNBQVk7SUFBekQ7UUFBQSxxRUE2Q0M7UUE1Q2Esa0JBQVksR0FBWSxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztRQUNyQyxpQkFBVyxHQUFZLEtBQUssQ0FBQztRQUM3QixtQkFBYSxHQUEyQixJQUFJLENBQUM7O0lBMEMzRCxDQUFDO0lBeENHLGdDQUFNLEdBQU47UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUMxRSxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUN4RSxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUN0RSxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUM3RSxDQUFDO0lBRU0sK0JBQUssR0FBWixVQUFhLFlBQW9DO1FBQzdDLElBQUksQ0FBQyxhQUFhLEdBQUcsWUFBWSxDQUFDO0lBQ3RDLENBQUM7SUFFUyxzQ0FBWSxHQUF0QixVQUF1QixDQUFzQjtRQUN6QyxJQUFJLGFBQWEsR0FBRyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDcEMsSUFBSSxZQUFZLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2pFLElBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUNwRCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztRQUN4QixJQUFJLENBQUMsYUFBYSxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBRVMscUNBQVcsR0FBckIsVUFBc0IsQ0FBc0I7UUFDeEMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXO1lBQ2pCLE9BQU87UUFFWCxJQUFJLGFBQWEsR0FBRyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDcEMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUNsQyxJQUFJLENBQUMsYUFBYSxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBRVMsb0NBQVUsR0FBcEIsVUFBcUIsQ0FBc0I7UUFDdkMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXO1lBQ2pCLE9BQU87UUFFWCxJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztJQUM3QixDQUFDO0lBRVMsdUNBQWEsR0FBdkIsVUFBd0IsUUFBaUI7UUFDckMsSUFBSSxZQUFZLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDbkQsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsb0JBQW9CLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDbkUsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDO0lBQ2xDLENBQUM7SUE1Q2dCLGVBQWU7UUFEbkMsT0FBTztPQUNhLGVBQWUsQ0E2Q25DO0lBQUQsc0JBQUM7Q0E3Q0QsQUE2Q0MsQ0E3QzRDLEVBQUUsQ0FBQyxTQUFTLEdBNkN4RDtrQkE3Q29CLGVBQWUiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDb3B5cmlnaHQgMjAyMCBDYW8gR2FvdGluZzxjYW9ndGFhQGdtYWlsLmNvbT5cbi8vIGh0dHBzOi8vY2FvZ3RhYS5naXRodWIuaW9cbi8vIFRoaXMgZmlsZSBpcyBsaWNlbnNlZCB1bmRlciB0aGUgTUlUIExpY2Vuc2UuXG4vLyBMaWNlbnNlIHRleHQgYXZhaWxhYmxlIGF0IGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlUXG5cbi8qXG4gKiBEYXRlOiAyMDIwLTA3LTEzIDAyOjQ0OjE3XG4gKiBMYXN0RWRpdG9yczogR1Q8Y2FvZ3RhYUBnbWFpbC5jb20+XG4gKiBMYXN0RWRpdFRpbWU6IDIwMjAtMDctMjIgMTQ6MDE6MzBcbiovIFxuXG5cbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XG5cbkBjY2NsYXNzXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBTaW1wbGVEcmFnZ2FibGUgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xuICAgIHByb3RlY3RlZCBfdG91Y2hPZmZzZXQ6IGNjLlZlYzIgPSBjYy5WZWMyLlpFUk87XG4gICAgcHJvdGVjdGVkIF9pc0RyYWdnaW5nOiBib29sZWFuID0gZmFsc2U7XG4gICAgcHJvdGVjdGVkIF9tb3ZlQ2FsbGJhY2s6IChwb3M6IGNjLlZlYzIpID0+IHZvaWQgPSBudWxsO1xuICAgIFxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULCB0aGlzLk9uVG91Y2hTdGFydC5iaW5kKHRoaXMpKTtcbiAgICAgICAgdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX01PVkUsIHRoaXMuT25Ub3VjaE1vdmUuYmluZCh0aGlzKSk7XG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsIHRoaXMuT25Ub3VjaEVuZC5iaW5kKHRoaXMpKTtcbiAgICAgICAgdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0NBTkNFTCwgdGhpcy5PblRvdWNoRW5kLmJpbmQodGhpcykpO1xuICAgIH1cblxuICAgIHB1YmxpYyBTZXR1cChtb3ZlQ2FsbGJhY2s6IChwb3M6IGNjLlZlYzIpID0+IHZvaWQpIHtcbiAgICAgICAgdGhpcy5fbW92ZUNhbGxiYWNrID0gbW92ZUNhbGxiYWNrO1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBPblRvdWNoU3RhcnQoZTogY2MuRXZlbnQuRXZlbnRUb3VjaCkge1xuICAgICAgICBsZXQgdG91Y2hXb3JsZFBvcyA9IGUuZ2V0TG9jYXRpb24oKTtcbiAgICAgICAgbGV0IG5vZGVXb3JsZFBvcyA9IHRoaXMubm9kZS5jb252ZXJ0VG9Xb3JsZFNwYWNlQVIoY2MuVmVjMi5aRVJPKTtcbiAgICAgICAgdGhpcy5fdG91Y2hPZmZzZXQgPSBub2RlV29ybGRQb3Muc3ViKHRvdWNoV29ybGRQb3MpO1xuICAgICAgICB0aGlzLl9pc0RyYWdnaW5nID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5fbW92ZUNhbGxiYWNrICYmIHRoaXMuX21vdmVDYWxsYmFjayh0aGlzLm5vZGUucG9zaXRpb24pO1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBPblRvdWNoTW92ZShlOiBjYy5FdmVudC5FdmVudFRvdWNoKSB7XG4gICAgICAgIGlmICghdGhpcy5faXNEcmFnZ2luZylcbiAgICAgICAgICAgIHJldHVybjtcblxuICAgICAgICBsZXQgdG91Y2hXb3JsZFBvcyA9IGUuZ2V0TG9jYXRpb24oKTtcbiAgICAgICAgdGhpcy5UcmFjZVRvdWNoUG9zKHRvdWNoV29ybGRQb3MpO1xuICAgICAgICB0aGlzLl9tb3ZlQ2FsbGJhY2sgJiYgdGhpcy5fbW92ZUNhbGxiYWNrKHRoaXMubm9kZS5wb3NpdGlvbik7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIE9uVG91Y2hFbmQoZTogY2MuRXZlbnQuRXZlbnRUb3VjaCkge1xuICAgICAgICBpZiAoIXRoaXMuX2lzRHJhZ2dpbmcpXG4gICAgICAgICAgICByZXR1cm47XG5cbiAgICAgICAgdGhpcy5faXNEcmFnZ2luZyA9IGZhbHNlO1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBUcmFjZVRvdWNoUG9zKHdvcmxkUG9zOiBjYy5WZWMyKSB7XG4gICAgICAgIGxldCBub2RlV29ybGRQb3MgPSB3b3JsZFBvcy5hZGQodGhpcy5fdG91Y2hPZmZzZXQpO1xuICAgICAgICBsZXQgbG9jYWxQb3MgPSB0aGlzLm5vZGUucGFyZW50LmNvbnZlcnRUb05vZGVTcGFjZUFSKG5vZGVXb3JsZFBvcyk7XG4gICAgICAgIHRoaXMubm9kZS5wb3NpdGlvbiA9IGxvY2FsUG9zO1xuICAgIH1cbn1cbiJdfQ==
//------QC-SOURCE-SPLIT------
