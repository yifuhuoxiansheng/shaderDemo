"use strict";
cc._RF.push(module, '9b7db/QlVpNR6BkHD3PCH0u', 'LayeredBatchingAssembler');
// Shader/LayeredBatching/LayeredBatchingAssembler.ts

"use strict";
/****************************************************************************
 Author: GT <caogtaa@gmail.com>
 https://caogtaa.github.io
****************************************************************************/
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var GTSimpleSpriteAssembler2D_1 = require("../GTSimpleSpriteAssembler2D");
// RenderFlow遍历过程中，需要防止子节点进入的函数
var RENDER_MASK = cc.RenderFlow.FLAG_RENDER | cc.RenderFlow.FLAG_POST_RENDER;
var PROP_DIRTY_MASK = cc.RenderFlow.FLAG_OPACITY | cc.RenderFlow.FLAG_WORLD_TRANSFORM;
// 通过开关控制仅在拥有该Assembler的根节点开启合批优化
// 用于避免该Assembler被嵌套使用
var BATCH_OPTIMIZE_SWITCH = true;
var LayeredBatchingAssembler = /** @class */ (function (_super) {
    __extends(LayeredBatchingAssembler, _super);
    function LayeredBatchingAssembler() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    LayeredBatchingAssembler.prototype.fillBuffers = function (comp, renderer) {
        _super.prototype.fillBuffers.call(this, comp, renderer);
        if (CC_EDITOR || CC_NATIVERENDERER)
            return;
        if (!BATCH_OPTIMIZE_SWITCH)
            return;
        var layer = [];
        this._layers = [layer];
        // 当前节点是自定义渲染的根节点，worldDirtyFlag属性将被逐层传递
        // 此处的dirtyFlag包含世界坐标变化、透明度变化。（参考render-flow.js的_children函数）
        var worldTransformFlag = renderer.worldMatDirty ? cc.RenderFlow.FLAG_WORLD_TRANSFORM : 0;
        var worldOpacityFlag = renderer.parentOpacityDirty ? cc.RenderFlow.FLAG_OPACITY_COLOR : 0;
        var dirtyFlag = worldTransformFlag | worldOpacityFlag;
        comp.node["__gtDirtyFlag"] = dirtyFlag;
        // BFS过程
        var queue = [];
        queue.push(comp.node);
        var depth = 0;
        var end = 1;
        var iter = 0;
        var gtRenderFlag;
        while (iter < queue.length) {
            var node = queue[iter++];
            dirtyFlag = node["__gtDirtyFlag"];
            for (var _i = 0, _a = node.children; _i < _a.length; _i++) {
                var c = _a[_i];
                if (!c._activeInHierarchy || c._opacity === 0)
                    continue;
                gtRenderFlag = c._renderFlag & RENDER_MASK;
                if (gtRenderFlag > 0) {
                    // 移除子节点的renderFlag，使renderFlow不执行它的RENDER函数
                    c["__gtRenderFlag"] = gtRenderFlag;
                    c._renderFlag &= ~gtRenderFlag;
                    layer.push(c);
                }
                // 逐层传递父节点的dirtyFlag
                c["__gtDirtyFlag"] = dirtyFlag | (c._renderFlag & PROP_DIRTY_MASK);
                queue.push(c);
            }
            if (iter == end) {
                // 完成当前层遍历，开始下一层遍历
                ++depth;
                end = queue.length;
                layer = [];
                this._layers.push(layer);
            }
        }
    };
    LayeredBatchingAssembler.prototype.postFillBuffers = function (comp, renderer) {
        // 记录worldMatDirty，函数退出时重置回去
        var originWorldMatDirty = renderer.worldMatDirty;
        if (!BATCH_OPTIMIZE_SWITCH || !this._layers)
            return;
        // off优化开关，避免嵌套
        BATCH_OPTIMIZE_SWITCH = false;
        var gtRenderFlag;
        var gtDirtyFlag;
        // 按层级遍历所有子节点
        for (var _i = 0, _a = this._layers; _i < _a.length; _i++) {
            var layer = _a[_i];
            if (layer.length == 0)
                continue;
            for (var _b = 0, layer_1 = layer; _b < layer_1.length; _b++) {
                var c = layer_1[_b];
                gtRenderFlag = c["__gtRenderFlag"];
                gtDirtyFlag = c["__gtDirtyFlag"];
                // 设置worldMatDirty，在引擎默认fillBuffers()中该变量用于判断是否更新世界坐标
                renderer.worldMatDirty = gtDirtyFlag > 0 ? 1 : 0;
                c._renderFlag |= gtRenderFlag;
                // 调用子节点RenderFlow的剩余部分
                cc.RenderFlow.flows[gtRenderFlag]._func(c);
            }
        }
        this._layers = null;
        BATCH_OPTIMIZE_SWITCH = true;
        renderer.worldMatDirty = originWorldMatDirty;
    };
    return LayeredBatchingAssembler;
}(GTSimpleSpriteAssembler2D_1.default));
exports.default = LayeredBatchingAssembler;

cc._RF.pop();