"use strict";
cc._RF.push(module, 'da46czoLEBHc711TNBTITkZ', 'SpriteMaskedAvatarAssembler');
// Shader/SpriteMaskedAvatar/SpriteMaskedAvatarAssembler.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-22 20:19:16
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-23 16:45:31
*/
var GTAutoFitSpriteAssembler2D_1 = require("../GTAutoFitSpriteAssembler2D");
//@ts-ignore
var gfx = cc.gfx;
var vfmtPosUvUv = new gfx.VertexFormat([
    { name: gfx.ATTR_POSITION, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: gfx.ATTR_UV0, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: "a_mask_uv", type: gfx.ATTR_TYPE_FLOAT32, num: 2 }
]);
var SpriteMaskedAvatarAssembler = /** @class */ (function (_super) {
    __extends(SpriteMaskedAvatarAssembler, _super);
    function SpriteMaskedAvatarAssembler() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.maskUvOffset = 4;
        _this.floatsPerVert = 6;
        return _this;
    }
    // todo: mixin this part
    SpriteMaskedAvatarAssembler.prototype.initData = function () {
        var data = this._renderData;
        // createFlexData支持创建指定格式的renderData
        data.createFlexData(0, this.verticesCount, this.indicesCount, this.getVfmt());
        // createFlexData不会填充顶点索引信息，手动补充一下
        var indices = data.iDatas[0];
        var count = indices.length / 6;
        for (var i = 0, idx = 0; i < count; i++) {
            var vertextID = i * 4;
            indices[idx++] = vertextID;
            indices[idx++] = vertextID + 1;
            indices[idx++] = vertextID + 2;
            indices[idx++] = vertextID + 1;
            indices[idx++] = vertextID + 3;
            indices[idx++] = vertextID + 2;
        }
    };
    SpriteMaskedAvatarAssembler.prototype.getVfmt = function () {
        return vfmtPosUvUv;
    };
    SpriteMaskedAvatarAssembler.prototype.getBuffer = function () {
        //@ts-ignore
        return cc.renderer._handle.getBuffer("mesh", this.getVfmt());
    };
    SpriteMaskedAvatarAssembler.prototype.updateColor = function (comp, color) {
        // do nothing
    };
    SpriteMaskedAvatarAssembler.prototype.updateUVs = function (sprite) {
        _super.prototype.updateUVs.call(this, sprite);
        var maskUvOffset = this.maskUvOffset;
        var floatsPerVert = this.floatsPerVert;
        var verts = this._renderData.vDatas[0];
        var maskUv = sprite._mask.uv;
        for (var i = 0; i < 4; i++) {
            var srcOffset = i * 2;
            var dstOffset = floatsPerVert * i + maskUvOffset;
            verts[dstOffset] = maskUv[srcOffset];
            verts[dstOffset + 1] = maskUv[srcOffset + 1];
        }
    };
    return SpriteMaskedAvatarAssembler;
}(GTAutoFitSpriteAssembler2D_1.default));
exports.default = SpriteMaskedAvatarAssembler;

cc._RF.pop();