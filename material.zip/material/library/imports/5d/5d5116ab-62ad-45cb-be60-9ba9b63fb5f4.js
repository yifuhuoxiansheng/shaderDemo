"use strict";
cc._RF.push(module, '5d511arYq1Fy75gm6m2P7X0', 'SceneMetaBalls');
// Scripts/Scene/SceneMetaBalls.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-13 02:44:16
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:01:57
*/
var MetaBallsRenderer_1 = require("../../Shader/MetaBalls/MetaBallsRenderer");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SceneMetaBalls = /** @class */ (function (_super) {
    __extends(SceneMetaBalls, _super);
    function SceneMetaBalls() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.waterRendererCamera = null;
        _this.waterRenderer = null;
        _this.waterRendererPass2 = null;
        _this.metaBallsRenderer = null;
        _this.particleBox = null;
        _this._world = null;
        _this._particles = null;
        _this._particleGroup = null;
        return _this;
    }
    SceneMetaBalls.prototype.onLoad = function () {
        if (!CC_EDITOR) {
            this.SetupWorld();
        }
        var texture = new cc.RenderTexture();
        var size = this.waterRendererPass2.node.getContentSize();
        texture.initWithSize(size.width, size.height);
        var spriteFrame = new cc.SpriteFrame();
        spriteFrame.setTexture(texture);
        this.waterRendererCamera.targetTexture = texture;
        this.waterRendererPass2.spriteFrame = spriteFrame;
    };
    SceneMetaBalls.prototype.SetupWorld = function () {
        // enable physics manager
        var physicsManager = cc.director.getPhysicsManager();
        physicsManager.enabled = true;
        var world = this._world = physicsManager._world; // new b2.World(new b2.Vec2(0, -15.0));
        var psd = new b2.ParticleSystemDef();
        psd.radius = 0.35;
        // psd.dampingStrength = 1.5;
        psd.viscousStrength = 0;
        this._particles = world.CreateParticleSystem(psd);
    };
    SceneMetaBalls.prototype.CreateParticlesGroup = function () {
        var PTM_RATIO = cc.PhysicsManager.PTM_RATIO;
        var boxSize = this.particleBox.getContentSize();
        var boxPos = this.particleBox.getPosition();
        var size = cc.winSize;
        var box = new b2.PolygonShape();
        // https://google.github.io/liquidfun/API-Ref/html/classb2_polygon_shape.html#a890690250115483da6c7d69829be087e
        // Build vertices to represent an oriented box.
        // box的大小影响粒子的数量
        box.SetAsBox(boxSize.width / 2 / PTM_RATIO, boxSize.height / 2 / PTM_RATIO);
        var particleGroupDef = new b2.ParticleGroupDef();
        particleGroupDef.shape = box;
        particleGroupDef.flags = b2.waterParticle;
        particleGroupDef.position.Set((boxPos.x + size.width / 2) / PTM_RATIO, (boxPos.y + size.height / 2) / PTM_RATIO);
        this._particleGroup = this._particles.CreateParticleGroup(particleGroupDef);
        this.metaBallsRenderer.SetParticles(this._particles);
        var vertsCount = this._particles.GetParticleCount();
        console.log(vertsCount);
    };
    SceneMetaBalls.prototype.GenerateWater = function () {
        this.ResetParticleGroup();
        // re-create particles in next tick
        // otherwise old particle system is not correctly released
        // this is a non-repeat schedule
        var that = this;
        cc.director.getScheduler().schedule(function () {
            that.CreateParticlesGroup();
        }, this.node, 0, 0, 0, false);
    };
    SceneMetaBalls.prototype.ResetParticleGroup = function () {
        if (this._particleGroup != null) {
            this._particleGroup.DestroyParticles(false);
            this._particles.DestroyParticleGroup(this._particleGroup);
            this._particleGroup = null;
        }
    };
    __decorate([
        property(cc.Camera)
    ], SceneMetaBalls.prototype, "waterRendererCamera", void 0);
    __decorate([
        property(cc.Node)
    ], SceneMetaBalls.prototype, "waterRenderer", void 0);
    __decorate([
        property(cc.Sprite)
    ], SceneMetaBalls.prototype, "waterRendererPass2", void 0);
    __decorate([
        property(MetaBallsRenderer_1.default)
    ], SceneMetaBalls.prototype, "metaBallsRenderer", void 0);
    __decorate([
        property(cc.Node)
    ], SceneMetaBalls.prototype, "particleBox", void 0);
    SceneMetaBalls = __decorate([
        ccclass
    ], SceneMetaBalls);
    return SceneMetaBalls;
}(cc.Component));
exports.default = SceneMetaBalls;
var enableLowLevelOptimize = true;
if (enableLowLevelOptimize) {
    cc.game.once(cc.game.EVENT_ENGINE_INITED, function () {
        // b2ParticleSystem.prototype.FindContacts_Reference = function (contacts) {
        //@ts-ignore
        b2.ParticleSystem.prototype.FindContacts_Reference = function (contacts) {
            if (!this.m_flagsBuffer.data) {
                throw new Error();
            }
            if (!this.m_positionBuffer.data) {
                throw new Error();
            }
            var pos_data = this.m_positionBuffer.data;
            var squaredDiameter = this.m_squaredDiameter;
            var inverseDiameter = this.m_inverseDiameter;
            // DEBUG: b2Assert(contacts === this.m_contactBuffer);
            var beginProxy = 0;
            var endProxy = this.m_proxyBuffer.count;
            this.m_contactBuffer.count = 0;
            // let contactBuffer = this.m_contactBuffer;
            var proxyData = this.m_proxyBuffer.data;
            //@ts-ignore
            var computeRelativeTag = b2.ParticleSystem.computeRelativeTag;
            // var AddContact = this.AddContact2.bind(this);
            var dataA;
            var tagA = 0;
            var indexA = 0;
            var rightTag = 0;
            var dataB;
            var pos_data = this.m_positionBuffer.data;
            var flagBufferData = this.m_flagsBuffer.data;
            var flagBufferDataA;
            var indexB = 0;
            var pos_dataA;
            var pos_dataB;
            var ax = 0, ay = 0, bx = 0, by = 0, dx = 0, dy = 0;
            var distBtParticlesSq = 0;
            var bottomLeftTag = 0;
            var bottomRightTag = 0;
            var isFin = isFinite;
            for (var a = beginProxy, c = beginProxy; a < endProxy; ++a) {
                dataA = proxyData[a];
                tagA = dataA.tag;
                indexA = dataA.index;
                pos_dataA = pos_data[indexA];
                flagBufferDataA = flagBufferData[indexA];
                rightTag = computeRelativeTag(tagA, 1, 0);
                for (var b = a + 1; b < endProxy; ++b) {
                    dataB = proxyData[b];
                    if (rightTag < dataB.tag) {
                        break;
                    }
                    // ------- AddContact(indexA, proxyData[b].index, contactBuffer);
                    indexB = dataB.index;
                    // pos_dataA = pos_data[indexA];
                    pos_dataB = pos_data[indexB];
                    // DEBUG: b2Assert(contacts === this.m_contactBuffer);
                    ///b2Vec2 d = m_positionBuffer.data[b] - m_positionBuffer.data[a];
                    bx = pos_dataB.x;
                    by = pos_dataB.y;
                    ax = pos_dataA.x;
                    ay = pos_dataA.y;
                    dx = bx - ax;
                    dy = by - ay;
                    // var d = b2.Vec2.SubVV(pos_data[b], pos_data[a], s_d);
                    distBtParticlesSq = dx * dx + dy * dy;
                    // var distBtParticlesSq = b2.Vec2.DotVV(d, d);
                    if (distBtParticlesSq < squaredDiameter) {
                        var invD = 1 / Math.sqrt(distBtParticlesSq);
                        // var invD = b2.InvSqrt(distBtParticlesSq);
                        if (!isFin(invD)) {
                            invD = 1.98177537e+019;
                        }
                        ///b2ParticleContact& contact = contacts.Append();
                        var contact = this.m_contactBuffer.data[this.m_contactBuffer.Append()];
                        contact.indexA = indexA;
                        contact.indexB = indexB;
                        contact.flags = flagBufferDataA | flagBufferData[indexB];
                        contact.weight = 1 - distBtParticlesSq * invD * inverseDiameter;
                        ///contact.SetNormal(invD * d);
                        contact.normal.x = invD * dx;
                        contact.normal.y = invD * dy;
                        // b2.Vec2.MulSV(invD, d, contact.normal);
                    }
                    // end ------- AddContact(indexA, proxyData[b].index, contactBuffer);
                }
                bottomLeftTag = computeRelativeTag(tagA, -1, 1);
                for (; c < endProxy; ++c) {
                    if (bottomLeftTag <= proxyData[c].tag) {
                        break;
                    }
                }
                bottomRightTag = computeRelativeTag(tagA, 1, 1);
                for (var b = c; b < endProxy; ++b) {
                    dataB = proxyData[b];
                    if (bottomRightTag < dataB.tag) {
                        break;
                    }
                    // ------- AddContact(indexA, proxyData[b].index, contactBuffer);
                    indexB = dataB.index;
                    // pos_dataA = pos_data[indexA];
                    pos_dataB = pos_data[indexB];
                    // DEBUG: b2Assert(contacts === this.m_contactBuffer);
                    ///b2Vec2 d = m_positionBuffer.data[b] - m_positionBuffer.data[a];
                    bx = pos_dataB.x;
                    by = pos_dataB.y;
                    ax = pos_dataA.x;
                    ay = pos_dataA.y;
                    dx = bx - ax;
                    dy = by - ay;
                    // var d = b2.Vec2.SubVV(pos_data[b], pos_data[a], s_d);
                    distBtParticlesSq = dx * dx + dy * dy;
                    // var distBtParticlesSq = b2.Vec2.DotVV(d, d);
                    if (distBtParticlesSq < squaredDiameter) {
                        var invD = 1 / Math.sqrt(distBtParticlesSq);
                        // var invD = b2.InvSqrt(distBtParticlesSq);
                        if (!isFin(invD)) {
                            invD = 1.98177537e+019;
                        }
                        ///b2ParticleContact& contact = contacts.Append();
                        var contact = this.m_contactBuffer.data[this.m_contactBuffer.Append()];
                        contact.indexA = indexA;
                        contact.indexB = indexB;
                        contact.flags = flagBufferDataA | flagBufferData[indexB];
                        contact.weight = 1 - distBtParticlesSq * invD * inverseDiameter;
                        ///contact.SetNormal(invD * d);
                        contact.normal.x = invD * dx;
                        contact.normal.y = invD * dy;
                        // b2.Vec2.MulSV(invD, d, contact.normal);
                    }
                    // end ------- AddContact(indexA, proxyData[b].index, contactBuffer);
                }
            }
        };
    });
}

cc._RF.pop();