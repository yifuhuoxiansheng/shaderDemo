"use strict";
cc._RF.push(module, '7ec6envootE0LqAVSRT/P5s', 'SceneTestGraphics');
// Scripts/Scene/SceneTestGraphics.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-23 16:15:08
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-23 16:43:03
*/
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SceneTestGraphics = /** @class */ (function (_super) {
    __extends(SceneTestGraphics, _super);
    function SceneTestGraphics() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.graphics = null;
        return _this;
    }
    SceneTestGraphics.prototype.onLoad = function () {
        var ctx = this.graphics;
        ctx.clear();
        ctx.strokeColor = cc.Color.BLACK;
        ctx.fillColor = cc.Color.RED;
        ctx.lineWidth = 5;
        ctx.moveTo(0, 0);
        ctx.lineTo(100, 100);
        ctx.stroke();
        ctx.rect(20, 20, 80, 100);
        ctx.fill();
    };
    __decorate([
        property(cc.Graphics)
    ], SceneTestGraphics.prototype, "graphics", void 0);
    SceneTestGraphics = __decorate([
        ccclass
    ], SceneTestGraphics);
    return SceneTestGraphics;
}(cc.Component));
exports.default = SceneTestGraphics;

cc._RF.pop();