"use strict";
cc._RF.push(module, '7e264FDcplMY5rNb2sCjRtf', 'LayeredBatchingRootRenderer');
// Shader/LayeredBatching/LayeredBatchingRootRenderer.ts

"use strict";
/****************************************************************************
 Author: GT <caogtaa@gmail.com>
 https://caogtaa.github.io
****************************************************************************/
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var LayeredBatchingAssembler_1 = require("./LayeredBatchingAssembler");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var LayeredBatchingRootRenderer = /** @class */ (function (_super) {
    __extends(LayeredBatchingRootRenderer, _super);
    function LayeredBatchingRootRenderer() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    LayeredBatchingRootRenderer.prototype.onEnable = function () {
        _super.prototype.onEnable.call(this);
        if (!CC_EDITOR && !CC_NATIVERENDERER)
            this.node._renderFlag |= cc.RenderFlow.FLAG_POST_RENDER;
        // this.node._renderFlag |= cc.RenderFlow.FLAG_RENDER;
    };
    LayeredBatchingRootRenderer.prototype._resetAssembler = function () {
        this.setVertsDirty();
        var assembler = this._assembler = new LayeredBatchingAssembler_1.default();
        assembler.init(this);
    };
    LayeredBatchingRootRenderer = __decorate([
        ccclass
    ], LayeredBatchingRootRenderer);
    return LayeredBatchingRootRenderer;
}(cc.Sprite));
exports.default = LayeredBatchingRootRenderer;

cc._RF.pop();