"use strict";
cc._RF.push(module, 'e1c35wY/WtDI4NVp88fW7Kq', 'MovingBGAssembler');
// Shader/MovingBG/MovingBGAssembler.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-13 02:44:17
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:03:25
*/
var GTSimpleSpriteAssembler2D_1 = require("../GTSimpleSpriteAssembler2D");
// 自定义顶点格式，在vfmtPosUvColor基础上，加入gfx.ATTR_UV1，去掉gfx.ATTR_COLOR
// 20200703 增加了uv2, uv3用于处理uv在图集里的映射
//@ts-ignore
var gfx = cc.gfx;
var vfmtCustom = new gfx.VertexFormat([
    { name: gfx.ATTR_POSITION, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: gfx.ATTR_UV0, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: gfx.ATTR_UV1, type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: "a_p", type: gfx.ATTR_TYPE_FLOAT32, num: 2 },
    { name: "a_q", type: gfx.ATTR_TYPE_FLOAT32, num: 2 } // 同上
]);
var VEC2_ZERO = cc.Vec2.ZERO;
var MovingBGAssembler = /** @class */ (function (_super) {
    __extends(MovingBGAssembler, _super);
    function MovingBGAssembler() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // 根据自定义顶点格式，调整下述常量
        _this.verticesCount = 4;
        _this.indicesCount = 6;
        _this.uvOffset = 2;
        _this.uv1Offset = 4;
        _this.uv2Offset = 6;
        _this.uv3Offset = 8;
        _this.floatsPerVert = 10;
        // 自定义数据，将被写入uv1的位置
        _this.moveSpeed = VEC2_ZERO;
        return _this;
    }
    MovingBGAssembler.prototype.initData = function () {
        var data = this._renderData;
        // createFlexData支持创建指定格式的renderData
        data.createFlexData(0, this.verticesCount, this.indicesCount, this.getVfmt());
        // createFlexData不会填充顶点索引信息，手动补充一下
        var indices = data.iDatas[0];
        var count = indices.length / 6;
        for (var i = 0, idx = 0; i < count; i++) {
            var vertextID = i * 4;
            indices[idx++] = vertextID;
            indices[idx++] = vertextID + 1;
            indices[idx++] = vertextID + 2;
            indices[idx++] = vertextID + 1;
            indices[idx++] = vertextID + 3;
            indices[idx++] = vertextID + 2;
        }
    };
    // 自定义格式以getVfmt()方式提供出去，除了当前assembler，render-flow的其他地方也会用到
    MovingBGAssembler.prototype.getVfmt = function () {
        return vfmtCustom;
    };
    // 重载getBuffer(), 返回一个能容纳自定义顶点数据的buffer
    // 默认fillBuffers()方法中会调用到
    MovingBGAssembler.prototype.getBuffer = function () {
        //@ts-ignore
        return cc.renderer._handle.getBuffer("mesh", this.getVfmt());
    };
    // pos数据没有变化，不用重载
    // updateVerts(sprite) {
    // }
    MovingBGAssembler.prototype.updateColor = function (sprite, color) {
        // 由于已经去掉了color字段，这里重载原方法，并且不做任何事
    };
    MovingBGAssembler.prototype.updateUVs = function (sprite) {
        _super.prototype.updateUVs.call(this, sprite);
        var uv = sprite._spriteFrame.uv;
        var uvOffset = this.uvOffset;
        var floatsPerVert = this.floatsPerVert;
        var verts = this._renderData.vDatas[0];
        var dstOffset;
        var l = uv[0], r = uv[2], t = uv[5], b = uv[1];
        // px, qx用于x轴的uv映射
        // py, qy同理，公式推导过程略...
        var px = 1.0 / (r - l), qx = -l * px; // l / (l-r);
        var py = 1.0 / (b - t), qy = -t * py; // t / (t-b);
        var sx = this.moveSpeed.x;
        var sy = this.moveSpeed.y;
        for (var i = 0; i < 4; ++i) {
            dstOffset = floatsPerVert * i + uvOffset;
            // fill uv1
            verts[dstOffset + 2] = sx;
            verts[dstOffset + 3] = sy;
            // fill uv2
            verts[dstOffset + 4] = px;
            verts[dstOffset + 5] = py;
            // fill uv3
            verts[dstOffset + 6] = qx;
            verts[dstOffset + 7] = qy;
        }
    };
    return MovingBGAssembler;
}(GTSimpleSpriteAssembler2D_1.default));
exports.default = MovingBGAssembler;

cc._RF.pop();