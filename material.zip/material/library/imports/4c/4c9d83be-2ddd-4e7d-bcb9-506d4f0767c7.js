"use strict";
cc._RF.push(module, '4c9d8O+Ld1Ofby5UG1PB2fH', 'SpriteMaskedAvatarSprite');
// Shader/SpriteMaskedAvatar/SpriteMaskedAvatarSprite.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-22 01:42:00
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:04:11
*/
var SpriteMaskedAvatarAssembler_1 = require("./SpriteMaskedAvatarAssembler");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SpriteMaskedAvatarSprite = /** @class */ (function (_super) {
    __extends(SpriteMaskedAvatarSprite, _super);
    function SpriteMaskedAvatarSprite() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._mask = null;
        _this._enableMask = true;
        return _this;
    }
    Object.defineProperty(SpriteMaskedAvatarSprite.prototype, "mask", {
        get: function () {
            return this._mask;
        },
        set: function (value) {
            this._mask = value;
            this.setVertsDirty();
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(SpriteMaskedAvatarSprite.prototype, "enableMask", {
        get: function () {
            return this._enableMask;
        },
        set: function (value) {
            this._enableMask = value;
            var mat = this.getMaterial(0);
            if (mat)
                mat.setProperty("enableMask", value ? 1.0 : 0.0);
        },
        enumerable: false,
        configurable: true
    });
    SpriteMaskedAvatarSprite.prototype._resetAssembler = function () {
        this.setVertsDirty();
        var assembler = this._assembler = new SpriteMaskedAvatarAssembler_1.default();
        assembler.init(this);
        var mask = this._mask;
        var mat = this.getMaterial(0);
        if (mat && mask) {
            mat.setProperty("mask", mask.getTexture());
            mat.setProperty("enableMask", this._enableMask ? 1.0 : 0.0);
        }
    };
    // 注意事项：业务上保证
    // 1. mask spriteFrame在使用前已经加载完毕，此处不会监听texture loaded
    // 2. mask 预先合图，此处不会监听动态合图事件
    SpriteMaskedAvatarSprite.prototype._validateRender = function () {
        //@ts-ignore
        _super.prototype._validateRender.call(this);
        var mask = this._mask;
        if (mask && mask.textureLoaded()) {
            return;
        }
        this.disableRender();
    };
    __decorate([
        property(cc.SpriteFrame)
    ], SpriteMaskedAvatarSprite.prototype, "mask", null);
    __decorate([
        property(cc.SpriteFrame)
    ], SpriteMaskedAvatarSprite.prototype, "_mask", void 0);
    __decorate([
        property(cc.Boolean)
    ], SpriteMaskedAvatarSprite.prototype, "enableMask", null);
    __decorate([
        property(cc.Boolean)
    ], SpriteMaskedAvatarSprite.prototype, "_enableMask", void 0);
    SpriteMaskedAvatarSprite = __decorate([
        ccclass
    ], SpriteMaskedAvatarSprite);
    return SpriteMaskedAvatarSprite;
}(cc.Sprite));
exports.default = SpriteMaskedAvatarSprite;

cc._RF.pop();