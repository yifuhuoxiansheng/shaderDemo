"use strict";
cc._RF.push(module, 'e54e38Lmk1LtatjNGNMggDD', 'EqualScalingAssembler');
// Shader/EqualScallingSprite/EqualScalingAssembler.ts

"use strict";
// Copyright 2020 Cao Gaoting<caogtaa@gmail.com>
// https://caogtaa.github.io
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Date: 2020-07-21 16:23:10
 * LastEditors: GT<caogtaa@gmail.com>
 * LastEditTime: 2020-07-22 14:00:52
*/
var GTSimpleSpriteAssembler2D_1 = require("../GTSimpleSpriteAssembler2D");
var EqualScalingAssembler = /** @class */ (function (_super) {
    __extends(EqualScalingAssembler, _super);
    function EqualScalingAssembler() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._uv = [];
        return _this;
    }
    EqualScalingAssembler.prototype.updateUVs = function (sprite) {
        var rect = sprite._spriteFrame.getRect();
        var node = sprite.node;
        if (!rect.width || !rect.height || !node.width || !node.height) {
            _super.prototype.updateUVs.call(this, sprite);
            return;
        }
        Object.assign(this._uv, sprite._spriteFrame.uv);
        var uv = this._uv;
        var wscale = rect.width / node.width;
        var hscale = rect.height / node.height;
        var ratio = 1.0;
        if (wscale > hscale) {
            // fit height
            ratio = hscale / wscale;
            var ro = sprite._spriteFrame.isRotated() ? 1 : 0;
            var l = uv[0 + ro], r = uv[2 + ro];
            var c = (l + r) * 0.5;
            var half = (r - l) * 0.5 * ratio;
            uv[0 + ro] = uv[4 + ro] = c - half;
            uv[2 + ro] = uv[6 + ro] = c + half;
        }
        else {
            // fit width
            ratio = wscale / hscale;
            var ro = sprite._spriteFrame.isRotated() ? -1 : 0;
            var b = uv[1 + ro], t = uv[5 + ro];
            var c = (b + t) * 0.5;
            var half = (b - t) * 0.5 * ratio;
            uv[1 + ro] = uv[3 + ro] = c + half;
            uv[5 + ro] = uv[7 + ro] = c - half;
        }
        var uvOffset = this.uvOffset;
        var floatsPerVert = this.floatsPerVert;
        var verts = this._renderData.vDatas[0];
        for (var i = 0; i < 4; i++) {
            var srcOffset = i * 2;
            var dstOffset = floatsPerVert * i + uvOffset;
            verts[dstOffset] = uv[srcOffset];
            verts[dstOffset + 1] = uv[srcOffset + 1];
        }
    };
    return EqualScalingAssembler;
}(GTSimpleSpriteAssembler2D_1.default));
exports.default = EqualScalingAssembler;

cc._RF.pop();