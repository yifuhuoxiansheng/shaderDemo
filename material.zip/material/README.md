## 简介
工程收录了个人使用Cocos Creator时积累的开发技巧</br>
请使用Cocos Creator 2.4.0或以上版本打开

### 合批系列
* 自定义顶点格式</br>
https://forum.cocos.org/t/topic/95087

* 自动分层合批</br>
https://forum.cocos.org/t/postrender-demo/95201

* 自定义渲染应用——图片遮罩合批</br>
https://forum.cocos.org/t/topic/95986

### shader系列，英文对应工程内场景名
* 螺旋形变，`SceneSpiralZoom`
* 过场动画，`SceneEnterEShop`

### 其他
* liquidfun + metaballs流体效果</br>
https://forum.cocos.org/t/topic/97137</br>
优化后调试模式下华为P9手机浏览器1000+个粒子可在60fps下运行


## Attributions
https://opengameart.org/content/buttons-with-hover</br>
https://opengameart.org/content/sprite-fonts-64x64-abblv-by-raid


## License
[MIT](https://opensource.org/licenses/MIT)
