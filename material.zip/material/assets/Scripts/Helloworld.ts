const {ccclass, property} = cc._decorator;

@ccclass
export default class Helloworld extends cc.Component {

   
    @property(cc.Sprite)
    sp: cc.Sprite = null;

    @property(cc.Material)
    material: cc.Material[] = [];

    private curTime = 0;
    start () {
        // init logic

    }

    changeProperty(time){
        this.material[0].setProperty("time", time , 0 , true);
    }


    update(dt){
        this.curTime += dt;
        this.changeProperty(this.curTime);
    }
}
